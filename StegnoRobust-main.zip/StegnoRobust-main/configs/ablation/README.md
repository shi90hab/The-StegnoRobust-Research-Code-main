# Ablation grid

Every row removes or changes **exactly one** component. An ablation that changes
two things at once explains nothing, so each file below differs from
`full_model.yaml` in a single field, and the field is named in the file.

Run the whole grid as one command:

```bash
python scripts/train_detectors.py -m \
    ablation=full_model,no_paired_batching,frozen_srm,no_zero_init,no_curriculum,no_augment \
    seed=0,1,2,3,4,5,6,7 env=colab_gpu
```

Attack-side ablations are separate because they need trained detectors:

```bash
python scripts/run_attack.py -m \
    ablation=committee_mean,committee_minmax,committee_logit,no_quantize \
    seed=0,1,2,3 env=colab_gpu
```

These are not decoration. Three of them test claims this revision makes in
writing, and a reviewer is entitled to the run that proves each:

| Ablation | Claim it tests |
|---|---|
| `no_paired_batching` | That unpaired batching is why XuNet collapsed to a constant prediction. If XuNet converges with paired batching and collapses without it, the diagnosis is demonstrated rather than asserted. |
| `no_curriculum` | That the payload curriculum is what lifts SRNet off chance, as opposed to the longer schedule alone. |
| `committee_minmax` | That the manuscript's mean-of-losses objective (Eq. 1) understates a committee attack, because a mean can be driven down by collapsing one member. |
| `no_quantize` | The cost of the threat model being realistic. An attack evaluated in float32 is not one an evader could deliver as a PNG. |
