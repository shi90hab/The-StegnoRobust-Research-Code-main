"""Install SteganoGAN 0.1.3 on a modern Python. Run once per environment.

    python tools/install_steganogan.py

Why this script has to exist. `pip install steganogan==0.1.3` fails on any pip
>= 24.1 with "No matching distribution found" -- while listing 0.1.3 among the
available versions, which is what makes the message so misleading. The cause is
neither the network nor the Python version: the published wheel's metadata
contains a malformed requirement,

    Requires-Dist: numpy (>=1.15.4<1.16.0)
                            ^ missing comma

and pip 24.1 tightened metadata validation from a warning to a hard error. pip
says so itself, in a line that is easy to miss: "Please use pip<24.1 if you need
to use this version."

This script fetches the wheel from the PyPI JSON API with urllib -- no pip, no
virtualenv, nothing to go wrong on a machine where `python3 -m venv` ships
without ensurepip (Debian and Colab split it into python3-venv, and an earlier
version of this script fell over exactly there). The downloaded file is verified
against the sha256 PyPI publishes, then the malformed character is repaired in
METADATA, the RECORD hash is recomputed so the archive stays internally
consistent, and the result is installed with --no-deps.

--no-deps is deliberate and not a shortcut: the declared pins are torch==1.0.0,
torchvision==0.2.1, scipy<1.2 and numpy<1.16, all from 2019. Honouring them would
destroy the environment. The package needs only `imageio`, `reedsolo`, `tqdm` and
`Pillow` at runtime, which are installed here explicitly.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

PACKAGE, VERSION = "steganogan", "0.1.3"
WHEEL = f"{PACKAGE}-{VERSION}-py2.py3-none-any.whl"
DIST_INFO = f"{PACKAGE}-{VERSION}.dist-info"
BAD = "numpy (>=1.15.4<1.16.0)"
GOOD = "numpy (>=1.15.4,<1.16.0)"
RUNTIME_DEPS = ["imageio", "reedsolo", "tqdm", "Pillow"]
PYPI_JSON = f"https://pypi.org/pypi/{PACKAGE}/{VERSION}/json"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download_wheel(cache: Path) -> Path:
    """Fetch the wheel via the PyPI API and verify the published digest."""
    cache.mkdir(parents=True, exist_ok=True)
    dst = cache / WHEEL

    with urllib.request.urlopen(PYPI_JSON, timeout=60) as r:
        meta = json.load(r)
    entry = next(u for u in meta["urls"] if u["filename"] == WHEEL)
    want = entry["digests"]["sha256"]

    if dst.exists() and _sha256(dst) == want:
        print(f"[steganogan] cached wheel verified ({want[:16]}...)")
        return dst

    print(f"[steganogan] downloading {WHEEL} ({entry['size'] / 1e6:.1f} MB)")
    tmp = dst.with_suffix(".part")
    urllib.request.urlretrieve(entry["url"], tmp)
    got = _sha256(tmp)
    if got != want:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"sha256 mismatch\n  expected {want}\n  actual   {got}")
    tmp.replace(dst)
    print(f"[steganogan] sha256 verified against PyPI ({want[:16]}...)")
    return dst


def repair_wheel(src: Path, out_dir: Path) -> Path:
    """Fix the one malformed character, keeping RECORD consistent.

    The output keeps the canonical wheel filename: pip parses
    name-version-build-python-abi-platform, so a suffix like '-fixed' is read as
    a build tag and rejected outright.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / WHEEL
    with zipfile.ZipFile(src) as zin:
        meta_name, rec_name = f"{DIST_INFO}/METADATA", f"{DIST_INFO}/RECORD"
        meta = zin.read(meta_name).decode()
        if BAD not in meta:
            print("[steganogan] metadata already well-formed; installing as published")
            shutil.copy(src, dst)
            return dst
        meta = meta.replace(BAD, GOOD)
        digest = base64.urlsafe_b64encode(hashlib.sha256(meta.encode()).digest()).rstrip(b"=").decode()
        rec = "\n".join(
            f"{meta_name},sha256={digest},{len(meta.encode())}"
            if line.startswith(meta_name + ",") else line
            for line in zin.read(rec_name).decode().splitlines()
        ) + "\n"
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename == meta_name:
                    data = meta.encode()
                elif item.filename == rec_name:
                    data = rec.encode()
                zout.writestr(item, data)
    print(f"[steganogan] repaired metadata: '{BAD}' -> '{GOOD}'")
    return dst


def install(wheel: Path, extra: list[str]) -> None:
    """Install, surfacing pip's full output when it fails.

    Truncating pip's output is how the original cause stayed hidden for two
    rounds: the decisive line ("Please use pip<24.1") is the LAST one, and a
    `| tail -2` in a notebook cell cut it off.
    """
    for args, label in (
        (["--no-deps", *extra, str(wheel)], "steganogan"),
        (["-q", *extra, *RUNTIME_DEPS], "runtime deps"),
    ):
        r = subprocess.run([sys.executable, "-m", "pip", "install", *args],
                           text=True, capture_output=True)
        if r.returncode != 0:
            raise RuntimeError(f"pip failed installing {label}:\n{r.stdout}\n{r.stderr}")
    print(f"[steganogan] installed with --no-deps; runtime deps: {', '.join(RUNTIME_DEPS)}")


def verify() -> None:
    """Import in a FRESH interpreter.

    Importing in this process would pass on a stale sys.modules entry and tell us
    nothing about whether the next kernel will find it.
    """
    code = (
        "import steganogan, pathlib, sys;"
        "p = pathlib.Path(steganogan.__file__).parent;"
        "w = sorted(f.name for f in (p / 'pretrained').glob('*.steg'));"
        "print(p); print(w);"
        "sys.exit(0 if len(w) == 3 else 1)"
    )
    r = subprocess.run([sys.executable, "-c", code], text=True, capture_output=True)
    if r.returncode != 0:
        raise RuntimeError(f"verification failed:\n{r.stdout}\n{r.stderr}")
    location, weights = r.stdout.strip().splitlines()
    print(f"[steganogan] verified in a fresh interpreter: {location}")
    print(f"[steganogan] pretrained weights: {weights}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cache", type=Path, default=Path.home() / ".cache" / "stegorobust")
    ap.add_argument("--break-system-packages", action="store_true")
    args = ap.parse_args()

    extra = ["--break-system-packages"] if args.break_system_packages else []
    wheel = download_wheel(args.cache)
    install(repair_wheel(wheel, args.cache / "repaired"), extra)
    verify()
    print("\nDone. Use it through src.models.embedding.deep.SteganoGANWrapper, which "
          "applies the runtime shims (torch.load, legacy optimizer pickles, bool bits).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
