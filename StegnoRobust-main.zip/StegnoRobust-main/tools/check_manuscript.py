"""Manuscript consistency checker: acronyms and numeric claims.

Three of Reviewer 1's points are mechanical and should never have survived to
review. They are mechanical, so they are checked mechanically:

  R1-1  "The authors should not use acronym without explanation. All acronyms
         must be defined before use."
        -> `audit_acronyms` finds every all-caps token and reports the first use
           and whether a definition of the form "Full Name (ACRONYM)" precedes it.

  R1-3  "The manuscript states PSNR >= 37 dB, but Table 3 reports 36.9 dB."
        -> `audit_numeric_claims` extracts every "PSNR <cmp> <n> dB" statement in
           the prose and compares it against the minimum in the PSNR column of
           the tables, at printed precision.

  R1-4  "Table 2 reports XuNet AUC = 0.489, while Table 3 shows 0.000."
        -> `audit_auc_consistency` cross-checks each detector's clean AUC in the
           benchmark table against its eps = 0 row in the evasion table, which
           must be the same number, and flags any sub-0.5 AUC as requiring an
           explicit polarity statement.

Usage:
    python tools/check_manuscript.py "Shihab et al..docx"
    python tools/check_manuscript.py paper.docx --json report.json
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

# Acronyms a steganography/forensics reader is assumed to know, or which are
# defined by convention. Everything else must be defined on first use.
WHITELIST = {
    "IEEE", "ACM", "IJIES", "PDF", "USA", "UK", "3D", "2D", "1D", "ID", "OK",
    "RGB", "DOI", "ISBN", "URL", "HTTP", "HTTPS", "I", "A", "AND", "OR", "THE",
    "RQ1", "RQ2", "RQ3", "NTIRE", "ICCV", "CVPR", "ECCV", "ICLR", "NIPS",
}

# Recognised expansions, so "Peak Signal-to-Noise Ratio (PSNR)" counts as a
# definition even when the acronym also appears in an earlier table caption.
KNOWN_EXPANSIONS = {
    "PSNR": "Peak Signal-to-Noise Ratio",
    "SSIM": "Structural Similarity Index Measure",
    "LPIPS": "Learned Perceptual Image Patch Similarity",
    "AUC": "Area Under the (ROC) Curve",
    "ROC": "Receiver Operating Characteristic",
    "GAN": "Generative Adversarial Network",
    "CNN": "Convolutional Neural Network",
    "PGD": "Projected Gradient Descent",
    "SRM": "Spatial Rich Model",
    "KV": "Ker-Vaudenay (high-pass kernel)",
    "BPP": "bits per pixel",
    "FPR": "False Positive Rate",
    "FNR": "False Negative Rate",
    "INN": "Invertible Neural Network",
    "DCT": "Discrete Cosine Transform",
    "HDR": "High Dynamic Range",
    "LSB": "Least Significant Bit",
    "SGD": "Stochastic Gradient Descent",
    "TLU": "Truncated Linear Unit",
    "MSE": "Mean Squared Error",
    "ECC": "Elliptic Curve Cryptography",
    "ECG": "Electrocardiogram",
    "UAV": "Unmanned Aerial Vehicle",
    "JPEG": "Joint Photographic Experts Group",
    "BSDS": "Berkeley Segmentation Data Set",
    "COCO": "Common Objects in Context",
    "SRNet": "Steganalysis Residual Network",
    "FGSM": "Fast Gradient Sign Method",
    "NAA": "Neuron Attribution-based Attack",
    "ASR": "Attack Success Rate",
    "MD": "Missed Detection",
    "FA": "False Alarm",
}

ACRONYM_RE = re.compile(r"\b([A-Z][A-Z0-9\-]{1,9})\b")
DEFINITION_RE = re.compile(r"\(\s*([A-Z][A-Za-z0-9\-]{1,9})s?\s*\)")
PSNR_CLAIM_RE = re.compile(
    r"PSNR[^.;]{0,40}?(?P<cmp>>=|≥|>|at least|no less than|above)\s*(?P<val>\d+(?:\.\d+)?)\s*dB",
    re.IGNORECASE,
)
NUMBER_RE = re.compile(r"^-?\d+(?:\.\d+)?$")


@dataclass
class Finding:
    rule: str
    severity: str
    location: str
    detail: str
    suggestion: str

    def as_row(self):
        return asdict(self)


# ------------------------------------------------------------------ docx I/O


def read_docx(path: Path) -> Tuple[List[str], List[List[List[str]]]]:
    import docx

    d = docx.Document(str(path))
    paras = [p.text for p in d.paragraphs]
    tables = [[[c.text.strip() for c in r.cells] for r in t.rows] for t in d.tables]
    return paras, tables


# --------------------------------------------------------------- acronym rule


REFERENCE_HEADING_RE = re.compile(r"^\s*(references?|bibliography)\s*$", re.IGNORECASE)


def body_paragraphs(paragraphs: Sequence[str]) -> List[str]:
    """Everything before the reference list.

    Titles inside bibliography entries are set in the source paper's own casing
    and are not the author's acronyms; scanning them produces noise like
    'APPROACHES' from an all-caps journal title. The rule applies to the body.
    """
    for i, t in enumerate(paragraphs):
        if REFERENCE_HEADING_RE.match(t.strip()):
            return list(paragraphs[:i])
    return list(paragraphs)


def audit_acronyms(paragraphs: Sequence[str]) -> List[Finding]:
    paragraphs = body_paragraphs(paragraphs)
    findings: List[Finding] = []
    defined: Dict[str, int] = {}
    first_use: Dict[str, Tuple[int, str]] = {}

    for i, text in enumerate(paragraphs):
        for m in DEFINITION_RE.finditer(text):
            defined.setdefault(m.group(1).upper(), i)
        for m in ACRONYM_RE.finditer(text):
            tok = m.group(1).rstrip("-")   # 'GAN-based' yields 'GAN', not 'GAN-'
            if tok in WHITELIST or NUMBER_RE.match(tok) or len(tok) < 2:
                continue
            # A token that is a whole sentence's first word in a heading is not
            # necessarily an acronym; require at least two capitals and no
            # lowercase neighbours.
            if not tok.isupper():
                continue
            first_use.setdefault(tok, (i, text[max(0, m.start() - 60) : m.start() + 60].strip()))

    for tok, (idx, ctx) in sorted(first_use.items()):
        if tok in defined and defined[tok] <= idx:
            continue
        expansion = KNOWN_EXPANSIONS.get(tok)
        findings.append(
            Finding(
                rule="R1-1 undefined acronym",
                severity="medium",
                location=f"paragraph {idx}",
                detail=f"'{tok}' first appears without a preceding definition: ...{ctx}...",
                suggestion=(
                    f"write '{expansion} ({tok})' at this first occurrence"
                    if expansion
                    else f"expand '{tok}' at this first occurrence, then use the acronym thereafter"
                ),
            )
        )
    return findings


# ------------------------------------------------------------- numeric claims


def _table_column(table: List[List[str]], header_match: str) -> List[float]:
    if not table:
        return []
    header = [h.lower() for h in table[0]]
    idx = next((i for i, h in enumerate(header) if header_match.lower() in h), None)
    if idx is None:
        return []
    vals = []
    for row in table[1:]:
        if idx < len(row):
            m = re.search(r"-?\d+(?:\.\d+)?", row[idx])
            if m:
                vals.append(float(m.group()))
    return vals


def audit_numeric_claims(paragraphs, tables) -> List[Finding]:
    paragraphs = body_paragraphs(paragraphs)
    findings: List[Finding] = []
    psnr_values: List[float] = []
    for t in tables:
        psnr_values.extend(_table_column(t, "psnr"))
    if not psnr_values:
        return findings
    worst = min(psnr_values)

    for i, text in enumerate(paragraphs):
        for m in PSNR_CLAIM_RE.finditer(text):
            claimed = float(m.group("val"))
            if worst + 1e-9 < claimed:
                findings.append(
                    Finding(
                        rule="R1-3 PSNR claim inconsistent with table",
                        severity="high",
                        location=f"paragraph {i}",
                        detail=(
                            f"text claims PSNR {m.group('cmp')} {claimed:g} dB, but the smallest "
                            f"PSNR printed in any table is {worst:g} dB"
                        ),
                        suggestion=(
                            f"restate as 'PSNR >= {int(worst)} dB' (true for every row), or scope "
                            f"the claim to the budgets where it holds, or report the value to a "
                            f"precision that makes it true. Do not round 36.9 up to 37 silently."
                        ),
                    )
                )
    return findings


def audit_auc_consistency(tables) -> List[Finding]:
    """Clean AUCs in the benchmark table must equal the eps = 0 row of the sweep."""
    findings: List[Finding] = []
    clean: Dict[str, float] = {}
    for t in tables:
        if not t or len(t[0]) < 2:
            continue
        header = [h.lower() for h in t[0]]
        if any("auc" in h for h in header) and any("detector" in h for h in header):
            di = next(i for i, h in enumerate(header) if "detector" in h)
            ai = next(i for i, h in enumerate(header) if "auc" in h)
            for row in t[1:]:
                if di < len(row) and ai < len(row):
                    m = re.search(r"-?\d+(?:\.\d+)?", row[ai])
                    if m and row[di]:
                        clean[row[di].strip().lower()] = float(m.group())

    for t in tables:
        if not t:
            continue
        header = [h.lower() for h in t[0]]
        if not any("gap" in h for h in header):
            continue
        zero_rows = [r for r in t[1:] if r and re.match(r"^0(\.0+)?$", r[0].strip())]
        if not zero_rows:
            continue
        row = zero_rows[0]
        for j, h in enumerate(header):
            key = h.strip().lower()
            if key in clean and j < len(row):
                m = re.search(r"-?\d+(?:\.\d+)?", row[j])
                if m and abs(float(m.group()) - clean[key]) > 5e-4:
                    findings.append(
                        Finding(
                            rule="R1-4 AUC disagreement between tables",
                            severity="high",
                            location=f"detector '{key}'",
                            detail=(
                                f"clean-benchmark table reports AUC {clean[key]:.3f}, but the "
                                f"evasion table at eps = 0 reports {float(m.group()):.3f}"
                            ),
                            suggestion=(
                                "generate both tables from the same results JSON "
                                "(src/evaluation/tables.py) so they cannot drift apart"
                            ),
                        )
                    )

    for det, auc in clean.items():
        if auc < 0.5:
            findings.append(
                Finding(
                    rule="R1-4 sub-chance AUC needs an explicit polarity statement",
                    severity="high",
                    location=f"detector '{det}'",
                    detail=(
                        f"AUC {auc:.3f} < 0.5 indicates an inverted ranking; the reader cannot "
                        "tell whether this is a real inversion or a flipped score column"
                    ),
                    suggestion=(
                        "state the score convention explicitly (this repo fixes "
                        "s = z_stego - z_cover in src/evaluation/metrics.py::canonical_score), "
                        "report 1 - AUC alongside, and flag the detector as non-converged rather "
                        "than reporting it as a committee member"
                    ),
                )
            )
    return findings


def audit_hedging(paragraphs) -> List[Finding]:
    """Reviewer 2, comment 7: claims that outrun the evidence.

    Flags strong claim verbs occurring in the same sentence as the words the
    reviewers disputed (transferability, committee, defence, deployment), so the
    author can check each one against src/evaluation/significance.py.
    """
    paragraphs = body_paragraphs(paragraphs)
    strong = re.compile(
        r"\b(demonstrates?|proves?|confirms?|establishes?|shows? that|indicates? that|"
        r"is a practical defen[cs]e|does not transfer|non-transferab)",
        re.IGNORECASE,
    )
    topic = re.compile(r"transfer|committee|defen[cs]e|deploy|architecture-diverse", re.IGNORECASE)
    out = []
    for i, text in enumerate(paragraphs):
        for sent in re.split(r"(?<=[.!?])\s+", text):
            if strong.search(sent) and topic.search(sent):
                out.append(
                    Finding(
                        rule="R2-7 claim strength",
                        severity="medium",
                        location=f"paragraph {i}",
                        detail=sent.strip()[:220],
                        suggestion=(
                            "downgrade to a hypothesis unless the claim passes "
                            "src/evaluation/significance.py::claim_supported with a converged "
                            "held-out detector and >= 5 seeds"
                        ),
                    )
                )
    return out


def run(path: Path) -> List[Finding]:
    paragraphs, tables = read_docx(path)
    return (
        audit_acronyms(paragraphs)
        + audit_numeric_claims(paragraphs, tables)
        + audit_auc_consistency(tables)
        + audit_hedging(paragraphs)
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("docx", type=Path)
    ap.add_argument("--json", type=Path, default=None)
    args = ap.parse_args()

    findings = run(args.docx)
    order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda f: (order.get(f.severity, 3), f.rule))

    by_rule: Dict[str, int] = {}
    for f in findings:
        by_rule[f.rule] = by_rule.get(f.rule, 0) + 1

    print(f"\n{args.docx.name}: {len(findings)} finding(s)\n" + "=" * 72)
    for rule, n in sorted(by_rule.items()):
        print(f"  {n:>3}  {rule}")
    print("=" * 72)
    for f in findings:
        print(f"\n[{f.severity.upper()}] {f.rule}  ({f.location})\n  {f.detail}\n  -> {f.suggestion}")

    if args.json:
        args.json.write_text(json.dumps([f.as_row() for f in findings], indent=2))
        print(f"\nwrote {args.json}")
    return 1 if any(f.severity == "high" for f in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
