"""The intervention log.

This file is the answer to "how did you arrive at this architecture." It is
append-only JSONL, committed with the run, and it stays accurate even when it is
unflattering -- an intervention log that only records the successful edits is
worse than none, because it implies a design process that did not happen.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

LOG_PATH = "outputs/agent_interventions.jsonl"


@dataclass
class Intervention:
    ts: str
    round: int
    trigger: str
    rule: str
    category: str                 # "mechanical" | "method_altering"
    files: List[str]
    diff_summary: str
    val_before: Optional[float]
    val_after: Optional[float] = None
    wandb_run: Optional[str] = None
    commit: Optional[str] = None
    patch_sha256: Optional[str] = None
    applied: bool = False
    detector: Optional[str] = None

    @staticmethod
    def now(**kwargs: Any) -> "Intervention":
        return Intervention(ts=datetime.now(timezone.utc).isoformat(), **kwargs)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def append(entry: Intervention, path: str | Path = LOG_PATH) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry.as_dict(), default=str) + "\n")
    return p


def read(path: str | Path = LOG_PATH) -> List[Intervention]:
    p = Path(path)
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(Intervention(**json.loads(line)))
    return out


def update_outcome(
    patch_sha256: str, val_after: float, applied: bool = True, path: str | Path = LOG_PATH
) -> None:
    """Rewrite the matching entry with the outcome once the next evaluation lands.

    Append-only in spirit: the file is rewritten in place rather than appended to
    a second time, so one intervention is one line and `val_after` is not left
    null in the record a reviewer reads.
    """
    entries = read(path)
    for e in entries:
        if e.patch_sha256 == patch_sha256:
            e.val_after, e.applied = val_after, applied
    p = Path(path)
    p.write_text("\n".join(json.dumps(e.as_dict(), default=str) for e in entries) + "\n")


def method_altering_diff_summary(path: str | Path = LOG_PATH) -> str:
    """Consolidated summary of every method-altering edit, for the methods section.

    Surface this BEFORE the user writes the methods section. The manuscript
    describes what the author designed; after autonomous edits it may not describe
    what actually ran, and that mismatch is caught at writing time or not at all.
    """
    entries = [e for e in read(path) if e.category == "method_altering" and e.applied]
    if not entries:
        return "No method-altering interventions were applied. The methods section describes what ran."
    lines = [
        f"{len(entries)} method-altering intervention(s) were applied automatically during training.",
        "The methods section must describe the code as it ran, not as it was written:",
        "",
    ]
    for e in entries:
        delta = ""
        if e.val_before is not None and e.val_after is not None:
            delta = f"  [{e.val_before:.4f} -> {e.val_after:.4f}]"
        lines.append(f"  round {e.round} ({e.trigger}): {e.diff_summary}{delta}")
        lines.append(f"    files: {', '.join(e.files)}   commit: {e.commit or 'uncommitted'}")
    return "\n".join(lines)
