"""Autonomous training supervisor.

Architecture (skill §12). The supervisor runs OUTSIDE the runtime. It polls W&B
for the live run, decides, and pushes a patch to an `agent/patches` branch. It
does not apply anything itself: it cannot reach into a Colab VM, and anything
claiming to restart a Colab runtime from outside is fiction. A thin in-notebook
stub (`patch_stub.py`) polls that branch between epochs and applies what it finds.
Watcher decides, stub applies.

Split isolation is structural, not advisory. `assert_no_test_split` inspects the
namespace the supervisor is given and raises if anything test-shaped is present.
An agent that iterates against a metric is a search procedure, and any split it
can observe stops being evaluation and becomes fitting.

The revision budget is persisted inside the checkpoint rather than held in
memory, because a Colab reconnect would otherwise silently reset the counter and
the cap would mean nothing.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from ..utils.git_provenance import CommitProvenance, git
from . import log as ilog
from .triggers import TriggerConfig, TriggerEvent, evaluate_triggers

PATCH_BRANCH = "agent/patches"
PATCH_DIR = "agent_patches"

# Delivery channel per target. The decision logic above is shared; this table is
# the only thing that differs between a local run and a hosted one.
DELIVERY_FOR = {"local": "direct", "colab_cpu": "branch", "colab_gpu": "branch"}

# Anything matching these is a test-split artefact and must never be visible to
# the supervisor. Names are matched case-insensitively against keys and attributes.
# Boundaries include "/" and "." because W&B keys are namespaced (`srnet/test_auc`)
# and config keys are dotted (`data.test_split`). An underscore-only boundary let
# every prefixed test metric through the guard -- which is the one place it must
# not fail, since this regex is what stops the supervisor seeing the test split.
_TEST_PATTERNS = re.compile(
    r"(?:^|[_/.\-])(?:test|testing|holdout_test)(?:[_/.\-]|$)"
    r"|test_loader|test_set|test_ds|X_test|y_test",
    re.I,
)


class TestSplitVisible(RuntimeError):
    # pytest would otherwise try to collect this as a test class because of the
    # "Test" prefix; the name is the right one for the error, so opt out instead.
    __test__ = False


def assert_no_test_split(scope: Mapping[str, Any], *, where: str = "supervisor scope") -> None:
    """Raise if anything test-shaped is reachable from the supervisor.

    Enforced structurally rather than by prompt: a reviewer's question is "could
    the agent have seen the test set", and the answer needs to be a line of code,
    not an intention.
    """
    offenders = [k for k in scope.keys() if _TEST_PATTERNS.search(str(k))]
    for k, v in scope.items():
        if isinstance(v, Mapping):
            offenders += [f"{k}.{kk}" for kk in v.keys() if _TEST_PATTERNS.search(str(kk))]
    if offenders:
        raise TestSplitVisible(
            f"test-split artefacts are reachable from the {where}: {sorted(set(offenders))}. "
            "The supervisor sees validation only. Remove these from the scope rather than "
            "relying on the agent not to read them -- an agent that can observe a split is "
            "fitting to it."
        )


# --------------------------------------------------------------------------
# Patch representation
# --------------------------------------------------------------------------


@dataclass
class Patch:
    """A proposed edit. `body` is a unified diff or a YAML override document."""

    kind: str                      # "config_override" | "unified_diff"
    body: str
    category: str                  # "mechanical" | "method_altering"
    summary: str
    files: List[str] = field(default_factory=list)
    trigger: Optional[str] = None
    round: int = 0

    @property
    def sha256(self) -> str:
        return hashlib.sha256((self.kind + self.body).encode()).hexdigest()

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind, "body": self.body, "category": self.category,
            "summary": self.summary, "files": self.files, "trigger": self.trigger,
            "round": self.round, "sha256": self.sha256,
        }


# Mechanical remedies. Applied silently -- these change how the model is fitted,
# not what the model is.
MECHANICAL_REMEDIES: Dict[str, Callable[[Dict[str, Any]], Patch]] = {}


def _override_patch(overrides: Dict[str, Any], summary: str, category: str, trigger: str) -> Patch:
    body = json.dumps(overrides, indent=2, sort_keys=True)
    return Patch(
        kind="config_override", body=body, category=category, summary=summary,
        files=["configs/ (runtime override)"], trigger=trigger,
    )


def propose_patch(event: TriggerEvent, state: Dict[str, Any]) -> Optional[Patch]:
    """Map a trip condition to a bounded, reversible edit.

    The mapping is deliberately conservative and enumerable: an agent with an
    open-ended edit space cannot be audited, and the intervention log would stop
    being a record anyone can check.
    """
    lr = float(state.get("lr", 1e-3))
    if event.name == "divergence":
        return _override_patch(
            {"detector.optim.lr": lr / 10, "detector.optim.grad_clip": 1.0},
            f"divergence: learning rate {lr:g} -> {lr/10:g}, gradient clipping enabled at 1.0",
            "mechanical", event.name,
        )
    if event.name == "overfitting":
        wd = float(state.get("weight_decay", 5e-4))
        return _override_patch(
            {"detector.optim.weight_decay": wd * 5, "hparams.augment": True, "hparams.label_smoothing": 0.05},
            f"overfitting: weight decay {wd:g} -> {wd*5:g}, D4 augmentation on, label smoothing 0.05",
            "mechanical", event.name,
        )
    if event.name == "plateau":
        return _override_patch(
            {"detector.optim.lr": lr / 3, "detector.optim.scheduler": "plateau"},
            f"plateau: learning rate {lr:g} -> {lr/3:g}, switch to ReduceLROnPlateau",
            "mechanical", event.name,
        )
    if event.name == "underperformance":
        # Domain-specific and method-altering: for a steganalysis detector stuck
        # at chance, the fix is the front end and the batching, not the step size.
        return _override_patch(
            {
                "detector.paired_batching": True,
                "detector.yenet.arch.trainable_srm": False,
                "detector.srnet.curriculum.enabled": True,
                "detector.optim.warmup_epochs": 5,
            },
            "underperformance at chance: enforce paired batching, freeze the SRM front end, "
            "enable the payload curriculum, add warmup",
            "method_altering", event.name,
        )
    return None


# --------------------------------------------------------------------------
# Budget, persisted in the checkpoint
# --------------------------------------------------------------------------


@dataclass
class SupervisorState:
    """Persisted inside the checkpoint under extra['supervisor']."""

    round: int = 0
    max_rounds: int = 3
    last_intervention_epoch: Optional[int] = None
    applied_patch_hashes: List[str] = field(default_factory=list)
    halted: bool = False
    halt_reason: str = ""

    @staticmethod
    def from_checkpoint(ckpt: Mapping[str, Any]) -> "SupervisorState":
        raw = (ckpt.get("extra") or {}).get("supervisor") or {}
        return SupervisorState(**raw) if raw else SupervisorState()

    def to_checkpoint_extra(self) -> Dict[str, Any]:
        return {
            "round": self.round, "max_rounds": self.max_rounds,
            "last_intervention_epoch": self.last_intervention_epoch,
            "applied_patch_hashes": list(self.applied_patch_hashes),
            "halted": self.halted, "halt_reason": self.halt_reason,
        }

    def can_intervene(self) -> tuple[bool, str]:
        if self.halted:
            return False, self.halt_reason or "supervisor halted"
        if self.round >= self.max_rounds:
            return False, (
                f"revision budget exhausted ({self.round}/{self.max_rounds}). An unbounded "
                "agent optimising validation overfits it exactly as a human would, only faster. "
                "Halting and notifying."
            )
        return True, "within budget"

    def already_tried(self, patch: Patch) -> bool:
        return patch.sha256 in self.applied_patch_hashes


# --------------------------------------------------------------------------
# The watcher
# --------------------------------------------------------------------------


class Supervisor:
    def __init__(
        self,
        repo: str | Path,
        trigger_cfg: TriggerConfig,
        *,
        wandb_run_path: Optional[str] = None,
        metric_key: str = "val_auc",
        detector: Optional[str] = None,
        log_path: str | Path = ilog.LOG_PATH,
        dry_run: bool = False,
    ):
        self.repo = Path(repo)
        self.cfg = trigger_cfg
        self.wandb_run_path = wandb_run_path
        self.metric_key = metric_key
        self.detector = detector
        self.log_path = Path(log_path)
        self.dry_run = dry_run

    # -- W&B polling -------------------------------------------------------
    @staticmethod
    def parse_history(
        raw_rows, detector: Optional[str] = None
    ) -> List[Dict[str, float]]:
        """Turn W&B history rows into the per-epoch records the triggers expect.

        Two filters, in this order.

        **Detector scoping.** The trainer logs every detector into ONE run under
        its own prefix (`xunet/val_auc`, `yenet/val_auc`, `srnet/val_auc`).
        Stripping the prefix unconditionally would merge all three into a single
        `val_auc` series, and a supervisor watching SRNet would be making
        decisions on YeNet's curve. So when a detector is named, only its keys are
        kept, and only its prefix is stripped. Unprefixed keys (`epoch`,
        `_step`) are shared and kept for every detector.

        **Test-split exclusion.** Any key that looks like a test metric is dropped
        here rather than raising later, so a stray `test_auc` logged by mistake
        cannot reach a decision.
        """
        prefix = f"{detector}/" if detector else None
        rows: List[Dict[str, float]] = []
        for r in raw_rows:
            row: Dict[str, float] = {}
            for k, v in r.items():
                key = str(k)
                if not isinstance(v, (int, float)) or isinstance(v, bool):
                    continue
                if _TEST_PATTERNS.search(key):
                    continue
                if "/" in key:
                    owner, _, short = key.partition("/")
                    if prefix is None:
                        # No detector named: keep the full key. Stripping here
                        # would let three series collide into one and the last
                        # one written would win -- silently, and differently
                        # depending on dict ordering.
                        row[key] = float(v)
                    elif owner == detector:
                        row[short] = float(v)
                    # else: another detector's series, skipped
                else:
                    row[key.lstrip("_")] = float(v)
            # A row with only bookkeeping (step/runtime) is not an epoch record.
            if any(k not in {"step", "runtime", "timestamp"} for k in row):
                rows.append(row)
        return rows

    def fetch_history(self) -> List[Dict[str, float]]:
        """Pull the live run's validation history from W&B."""
        if not self.wandb_run_path:
            return []
        import wandb

        api = wandb.Api()
        run = api.run(self.wandb_run_path)
        rows = self.parse_history(run.scan_history(), detector=self.detector)
        if rows:
            assert_no_test_split(
                {f"row{i}": r for i, r in enumerate(rows[:1])}, where="W&B history"
            )
        return rows

    # -- decide ------------------------------------------------------------
    def decide(
        self, history: Sequence[Dict[str, float]], state: SupervisorState, run_state: Dict[str, Any]
    ) -> tuple[Optional[TriggerEvent], Optional[Patch], str]:
        assert_no_test_split(run_state, where="supervisor run state")

        event = evaluate_triggers(
            history, self.cfg, metric_key=self.metric_key,
            last_intervention_epoch=state.last_intervention_epoch,
        )
        if event is None:
            return None, None, "no trigger fired"

        ok, why = state.can_intervene()
        if not ok and event.severity != "immediate":
            return event, None, why
        if not ok and event.severity == "immediate":
            return event, None, f"{why} (divergence detected but budget exhausted -- notify the user)"

        patch = propose_patch(event, run_state)
        if patch is None:
            return event, None, f"no bounded remedy is defined for trigger '{event.name}'"
        patch.round = state.round + 1
        if state.already_tried(patch):
            return event, None, (
                "suppressed: an equivalent patch was already applied "
                f"(sha {patch.sha256[:8]}); re-applying it would be thrash"
            )
        return event, patch, "patch proposed"

    # -- publish -----------------------------------------------------------
    def publish(
        self, patch: Patch, *, seed: int, config_hash: str, wandb_run: Optional[str],
        target: str = "colab_gpu", relaunch: Optional[Callable[[Patch], None]] = None,
    ) -> Optional[str]:
        """Deliver the patch through whichever channel the target requires.

        Hosted -> commit to agent/patches; the in-notebook stub applies it.
        Local  -> write the patch beside the run and call `relaunch`, because the
                  supervisor is a process on the same machine and does not need a
                  branch to reach the trainer.

        The decision that produced `patch` is identical in both cases; only the
        delivery differs. The patch is still committed on the local path, so the
        history records the intervention either way.
        """
        if self.dry_run:
            print(f"[supervisor] DRY RUN ({target}), not publishing:\n{patch.summary}")
            return None

        if DELIVERY_FOR.get(target, "branch") == "direct":
            return self._publish_local(patch, seed=seed, config_hash=config_hash,
                                       wandb_run=wandb_run, relaunch=relaunch)

        current = git("rev-parse", "--abbrev-ref", "HEAD", repo=self.repo).stdout.strip()
        git("checkout", "-B", PATCH_BRANCH, repo=self.repo, check=False)
        pdir = self.repo / PATCH_DIR
        pdir.mkdir(parents=True, exist_ok=True)
        fname = f"{patch.round:02d}_{patch.trigger}_{patch.sha256[:8]}.json"
        (pdir / fname).write_text(json.dumps(patch.as_dict(), indent=2))

        from ..utils.git_provenance import commit_and_push

        prov = CommitProvenance(
            metric_name=self.metric_key, metric_value=float("nan"), previous_best=None,
            epoch=-1, seed=seed, config_hash=config_hash, wandb_run=wandb_run,
            trigger="agent_patch", agent_revision=f"{patch.round}/{self.cfg.max_rounds}",
            detector=self.detector,
        )
        sha = commit_and_push(self.repo, [f"{PATCH_DIR}/{fname}"], prov, branch=PATCH_BRANCH)
        git("checkout", current, repo=self.repo, check=False)
        return sha

    def _publish_local(
        self, patch: Patch, *, seed: int, config_hash: str, wandb_run: Optional[str],
        relaunch: Optional[Callable[[Patch], None]] = None,
    ) -> Optional[str]:
        """Direct channel: same machine, so patch and relaunch without a branch.

        The three-round budget is NOT relaxed here even though restarts are cheap
        locally. The cap bounds validation overfitting; it is not a compute-saving
        measure, and cheap restarts make over-iterating easier, not more defensible.
        """
        from ..utils.git_provenance import commit_and_push

        pdir = self.repo / PATCH_DIR
        pdir.mkdir(parents=True, exist_ok=True)
        fname = f"{patch.round:02d}_{patch.trigger}_{patch.sha256[:8]}.json"
        (pdir / fname).write_text(json.dumps(patch.as_dict(), indent=2))

        prov = CommitProvenance(
            metric_name=self.metric_key, metric_value=float("nan"), previous_best=None,
            epoch=-1, seed=seed, config_hash=config_hash, wandb_run=wandb_run,
            trigger="agent_patch", agent_revision=f"{patch.round}/{self.cfg.max_rounds}",
            detector=self.detector,
        )
        sha = commit_and_push(self.repo, [f"{PATCH_DIR}/{fname}"], prov, push=False)
        if relaunch is not None:
            print(f"[supervisor/local] applying and relaunching: {patch.summary}")
            relaunch(patch)
        else:
            print(f"[supervisor/local] patch written to {pdir / fname}; no relaunch callback "
                  "was supplied, so the trainer must pick it up on its next epoch poll")
        return sha

    # -- one full cycle ----------------------------------------------------
    def step(
        self, history: Sequence[Dict[str, float]], state: SupervisorState, run_state: Dict[str, Any],
        *, seed: int, config_hash: str, wandb_run: Optional[str] = None,
        target: str = "colab_gpu", relaunch: Optional[Callable[[Patch], None]] = None,
    ) -> tuple[SupervisorState, Optional[Patch], str]:
        event, patch, reason = self.decide(history, state, run_state)
        if event is None or patch is None:
            if event is not None:
                print(f"[supervisor] {event.name} fired but no patch: {reason}")
                if "budget exhausted" in reason:
                    state.halted, state.halt_reason = True, reason
            return state, None, reason

        val_before = max(
            (h.get(self.metric_key) for h in history if h.get(self.metric_key) is not None),
            default=None,
        )
        sha = self.publish(patch, seed=seed, config_hash=config_hash, wandb_run=wandb_run,
                           target=target, relaunch=relaunch)
        ilog.append(
            ilog.Intervention.now(
                round=patch.round, trigger=event.name, rule=event.rule, category=patch.category,
                files=patch.files, diff_summary=patch.summary, val_before=val_before,
                wandb_run=wandb_run, commit=sha, patch_sha256=patch.sha256, applied=False,
                detector=self.detector,
            ),
            self.log_path,
        )
        state.round = patch.round
        state.last_intervention_epoch = event.epoch
        state.applied_patch_hashes.append(patch.sha256)
        tag = " [METHOD-ALTERING]" if patch.category == "method_altering" else ""
        print(f"[supervisor] round {patch.round}/{state.max_rounds}{tag} {event.name}: {patch.summary}")
        return state, patch, reason

    def watch(
        self, state_getter: Callable[[], SupervisorState], run_state_getter: Callable[[], Dict[str, Any]],
        *, seed: int, config_hash: str, poll_seconds: int = 120, max_polls: int = 10_000,
    ) -> None:
        """Polling loop, run from outside the training runtime."""
        for _ in range(max_polls):
            history = self.fetch_history()
            state = state_getter()
            if state.halted:
                print(f"[supervisor] halted: {state.halt_reason}")
                return
            self.step(history, state, run_state_getter(), seed=seed, config_hash=config_hash,
                      wandb_run=self.wandb_run_path)
            time.sleep(poll_seconds)
