"""In-notebook patch stub: the half of the supervisor that runs inside Colab.

The watcher cannot reach into the VM, so it publishes to `agent/patches` and this
stub polls that branch between epochs and applies what it finds. Keep it thin --
it makes no decisions, it only fetches, verifies and applies. Every judgment
lives in supervisor.py, where it can be tested without a GPU.

Applying a patch mutates the run. Three safeguards, all of which have to hold:

  1. The patch hash must not already be in the checkpoint's applied list.
  2. The budget in the checkpoint must not be exhausted.
  3. `config_override` patches may only touch an allow-listed set of keys, so a
     malformed or unexpected patch cannot silently redefine the experiment.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..utils.git_provenance import git
from .supervisor import PATCH_BRANCH, PATCH_DIR, Patch, SupervisorState

# Keys a patch is permitted to override. Anything else is refused and logged.
ALLOWED_OVERRIDE_PREFIXES = (
    "detector.optim.",
    "detector.paired_batching",
    "detector.batch_size",
    "detector.xunet.arch.",
    "detector.yenet.arch.",
    "detector.srnet.arch.",
    "detector.srnet.curriculum.",
    "hparams.augment",
    "hparams.label_smoothing",
    "attack.",
)


class PatchRefused(RuntimeError):
    pass


def _branch_exists(repo: Path, branch: str) -> bool:
    res = git("rev-parse", "--verify", "--quiet", branch, repo=repo, check=False)
    return res.returncode == 0 and bool(res.stdout.strip())


def fetch_patches(repo: str | Path, branch: str = PATCH_BRANCH) -> List[Patch]:
    """Read the patch branch without switching the working tree away from the run.

    Tries the remote first, then falls back to the local branch. The fallback is
    not a convenience: when the supervisor and the notebook share one Drive clone
    there is no remote to fetch from, and requiring one would make the stub a
    no-op in exactly the setup people actually use.
    """
    repo = Path(repo)
    fetched = git("fetch", "origin", f"{branch}:{branch}", repo=repo,
                  use_credentials=True, check=False).returncode == 0
    if not fetched and not _branch_exists(repo, branch):
        return []
    listing = git("ls-tree", "--name-only", branch, f"{PATCH_DIR}/", repo=repo, check=False).stdout
    patches: List[Patch] = []
    for path in [l for l in listing.splitlines() if l.strip().endswith(".json")]:
        blob = git("show", f"{branch}:{path}", repo=repo, check=False).stdout
        try:
            d = json.loads(blob)
        except json.JSONDecodeError:
            continue
        patches.append(
            Patch(kind=d["kind"], body=d["body"], category=d["category"], summary=d["summary"],
                  files=d.get("files", []), trigger=d.get("trigger"), round=d.get("round", 0))
        )
    return sorted(patches, key=lambda p: p.round)


def validate_override(overrides: Dict[str, Any]) -> None:
    bad = [k for k in overrides if not k.startswith(ALLOWED_OVERRIDE_PREFIXES)]
    if bad:
        raise PatchRefused(
            f"patch attempts to override keys outside the allow-list: {bad}. "
            "A patch that can rewrite arbitrary configuration is not an intervention, "
            "it is a second experiment."
        )


def apply_patch(patch: Patch, cfg: Any, state: SupervisorState) -> Tuple[Any, str]:
    """Apply a patch to the live Hydra config. Returns (cfg, message)."""
    if patch.sha256 in state.applied_patch_hashes:
        return cfg, f"skipped: patch {patch.sha256[:8]} already applied"
    ok, why = state.can_intervene()
    if not ok:
        return cfg, f"refused: {why}"

    if patch.kind != "config_override":
        # Unified diffs edit source files; they are applied by git, not by us, and
        # only when the working tree is clean, so a half-applied patch cannot be
        # confused with an author edit.
        return cfg, "refused: unified_diff patches must be applied with `git apply` from a clean tree"

    overrides = json.loads(patch.body)
    validate_override(overrides)

    from omegaconf import OmegaConf

    for key, value in overrides.items():
        OmegaConf.update(cfg, key, value, merge=True)

    state.round = max(state.round, patch.round)
    state.applied_patch_hashes.append(patch.sha256)
    tag = " [METHOD-ALTERING]" if patch.category == "method_altering" else ""
    return cfg, f"applied round {patch.round}{tag}: {patch.summary}"


def poll_and_apply(
    repo: str | Path, cfg: Any, state: SupervisorState, *, enabled: bool = True
) -> Tuple[Any, SupervisorState, List[str]]:
    """Called by the trainer between epochs. Cheap and non-fatal by design."""
    messages: List[str] = []
    if not enabled:
        return cfg, state, messages
    try:
        patches = fetch_patches(repo)
    except Exception as e:
        return cfg, state, [f"patch poll failed (training continues): {e}"]

    for p in patches:
        try:
            cfg, msg = apply_patch(p, cfg, state)
        except PatchRefused as e:
            msg = f"refused: {e}"
        if not msg.startswith("skipped"):
            messages.append(msg)
    return cfg, state, messages


def rebuild_optimizer_if_needed(messages: List[str], model, recipe, optimizer):
    """A learning-rate or optimizer override only takes effect if the optimizer is
    rebuilt. Forgetting this is the classic way an 'applied' patch does nothing."""
    if not any(m.startswith("applied") for m in messages):
        return optimizer, False
    from ..training.optim import build_optimizer

    return build_optimizer(model, recipe), True
