"""Dual-target run registry: one supervisor, local and hosted runs together.

Skill §12, dual-target operation. One supervisor process manages every active
run. The decision logic is shared; only the delivery channel differs:

    local        -> patch the config and relaunch directly, same machine
    colab_cpu    -> push to agent/patches, in-notebook stub applies
    colab_gpu    -> same as colab_cpu

Two properties are easy to get wrong and are enforced here rather than assumed.

**The budget is shared across targets, not per target.** Three rounds belong to
the *experiment*, wherever those rounds happen to run. Keyed by process or by
target, a migration silently resets the counter and the cap stops meaning
anything — which is precisely the failure the cap exists to prevent.

**Migration invalidates timings, not metrics.** A run that spent part of its life
on a local CPU and the rest on a hosted T4 has a wall-clock figure describing
neither machine. The checkpoint carries full RNG state, so the metrics remain
valid and reportable; the speed numbers do not, and `timing_invalid` propagates
into the provenance record and the cost table.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .supervisor import SupervisorState

DELIVERY = {"local": "direct", "colab_cpu": "branch", "colab_gpu": "branch"}


@dataclass
class RunRecord:
    """One active run. `experiment_id` is the budget key, not the process id."""

    experiment_id: str
    target: str
    detector: Optional[str] = None
    seed: int = 0
    wandb_run: Optional[str] = None
    checkpoint: Optional[str] = None
    repo: Optional[str] = None
    hardware_label: str = "unknown"
    started: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    migrations: List[Dict[str, Any]] = field(default_factory=list)
    timing_invalid: bool = False
    timing_invalid_reason: str = ""

    @property
    def delivery(self) -> str:
        return DELIVERY.get(self.target, "branch")

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RunRegistry:
    """Active runs keyed by experiment ID, with the budget attached to the key."""

    def __init__(self, path: str | Path = "outputs/run_registry.json", max_rounds: int = 3):
        self.path = Path(path)
        self.max_rounds = max_rounds
        self.runs: Dict[str, RunRecord] = {}
        self.budgets: Dict[str, SupervisorState] = {}
        if self.path.exists():
            self.load()

    # -- persistence -------------------------------------------------------
    def load(self) -> None:
        blob = json.loads(self.path.read_text())
        self.runs = {k: RunRecord(**v) for k, v in blob.get("runs", {}).items()}
        self.budgets = {
            k: SupervisorState(**v) for k, v in blob.get("budgets", {}).items()
        }

    def save(self) -> Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(
                {
                    "runs": {k: v.as_dict() for k, v in self.runs.items()},
                    "budgets": {k: v.to_checkpoint_extra() for k, v in self.budgets.items()},
                },
                indent=2, default=str,
            )
        )
        return self.path

    # -- registry ----------------------------------------------------------
    def register(self, record: RunRecord) -> RunRecord:
        self.runs[record.experiment_id] = record
        self.budgets.setdefault(
            record.experiment_id, SupervisorState(max_rounds=self.max_rounds)
        )
        self.save()
        return record

    def budget(self, experiment_id: str) -> SupervisorState:
        """The shared counter. Same object regardless of which target is running."""
        return self.budgets.setdefault(
            experiment_id, SupervisorState(max_rounds=self.max_rounds)
        )

    def sync_budget_from_checkpoint(self, experiment_id: str, ckpt: Dict[str, Any]) -> SupervisorState:
        """Reconcile with the checkpoint, taking the HIGHER round count.

        The checkpoint is authoritative after a reconnect; the registry is
        authoritative after a migration. Taking the maximum means neither path
        can lose a round, and losing a round is how a three-round cap quietly
        becomes a five-round one.
        """
        from_ckpt = SupervisorState.from_checkpoint(ckpt)
        cur = self.budget(experiment_id)
        merged = SupervisorState(
            round=max(cur.round, from_ckpt.round),
            max_rounds=self.max_rounds,
            last_intervention_epoch=max(
                cur.last_intervention_epoch or -1, from_ckpt.last_intervention_epoch or -1
            ) or None,
            applied_patch_hashes=sorted(set(cur.applied_patch_hashes) | set(from_ckpt.applied_patch_hashes)),
            halted=cur.halted or from_ckpt.halted,
            halt_reason=cur.halt_reason or from_ckpt.halt_reason,
        )
        self.budgets[experiment_id] = merged
        self.save()
        return merged

    # -- migration ---------------------------------------------------------
    def migrate(
        self, experiment_id: str, to_target: str, reason: str, hardware_label: str = "unknown"
    ) -> RunRecord:
        rec = self.runs[experiment_id]
        rec.migrations.append(
            {
                "at": datetime.now(timezone.utc).isoformat(),
                "from": rec.target, "to": to_target, "reason": reason,
                "from_hardware": rec.hardware_label, "to_hardware": hardware_label,
            }
        )
        rec.target = to_target
        rec.hardware_label = hardware_label
        rec.timing_invalid = True
        rec.timing_invalid_reason = (
            f"run migrated {rec.migrations[-1]['from']} -> {to_target} at "
            f"{rec.migrations[-1]['at']}; wall-clock and latency describe neither machine. "
            "Metrics remain valid (the checkpoint carries full RNG state); re-run on fixed "
            "hardware if a timing is needed."
        )
        self.save()
        print(f"[registry] {experiment_id} migrated to {to_target}: {reason}")
        print(f"[registry] timings for this run are now INVALID -- {rec.timing_invalid_reason}")
        return rec

    def timing_valid(self, experiment_id: str) -> tuple[bool, str]:
        rec = self.runs.get(experiment_id)
        if rec is None:
            return True, ""
        return (not rec.timing_invalid), rec.timing_invalid_reason


# --------------------------------------------------------------------------
# Migration pressure: a number, never a subjective "busy"
# --------------------------------------------------------------------------


@dataclass
class PressureConfig:
    """Sustained pressure, defined numerically and over a window.

    A single spike is not pressure -- a preprocessing step that briefly pins the
    CPU would otherwise trigger a migration that costs more than it saves.
    """

    load_average_per_core: float = 2.0
    memory_percent: float = 90.0
    swap_percent: float = 25.0
    sustained_minutes: int = 10
    sample_seconds: int = 30

    @property
    def samples_required(self) -> int:
        return max(1, int(self.sustained_minutes * 60 / self.sample_seconds))


class PressureMonitor:
    """Rolling window over host pressure samples."""

    def __init__(self, cfg: PressureConfig):
        self.cfg = cfg
        self.samples: List[bool] = []

    @staticmethod
    def sample_host() -> Dict[str, float]:
        import os

        out = {"load_per_core": float("nan"), "memory_percent": float("nan"), "swap_percent": float("nan")}
        try:
            cores = os.cpu_count() or 1
            out["load_per_core"] = os.getloadavg()[1] / cores   # 5-minute average
        except (OSError, AttributeError):
            pass
        try:
            import psutil

            out["memory_percent"] = psutil.virtual_memory().percent
            out["swap_percent"] = psutil.swap_memory().percent
        except ImportError:
            pass
        return out

    def observe(self, sample: Optional[Dict[str, float]] = None) -> tuple[bool, str]:
        s = sample or self.sample_host()
        c = self.cfg

        def over(value: float, limit: float) -> bool:
            return value == value and value > limit    # NaN-safe

        breached = (
            over(s.get("load_per_core", float("nan")), c.load_average_per_core)
            or over(s.get("memory_percent", float("nan")), c.memory_percent)
            or over(s.get("swap_percent", float("nan")), c.swap_percent)
        )
        self.samples.append(breached)
        self.samples = self.samples[-c.samples_required :]

        if len(self.samples) >= c.samples_required and all(self.samples):
            return True, (
                f"host pressure above threshold for {c.sustained_minutes} consecutive minutes "
                f"(load/core {s.get('load_per_core', float('nan')):.2f} > {c.load_average_per_core}, "
                f"memory {s.get('memory_percent', float('nan')):.0f}% > {c.memory_percent}%, "
                f"swap {s.get('swap_percent', float('nan')):.0f}% > {c.swap_percent}%)"
            )
        return False, (
            f"{sum(self.samples)}/{c.samples_required} consecutive pressure samples; "
            "migration requires sustained pressure, not a spike"
        )
