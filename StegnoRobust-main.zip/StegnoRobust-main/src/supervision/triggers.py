"""Trip conditions for the training supervisor.

Every condition is a number, not a judgment call, so the same run always produces
the same decision and the decision can be quoted in the intervention log.

Domain note for this paper: the `underperformance` trigger is the one that
matters most here. The submitted study's failure was not a diverging loss -- it
was two detectors sitting at chance for a hundred epochs while training loss went
down. `baseline_metric` is therefore set to the convergence gate (0.75 AUC) for
steganalysis detectors, so a run that is quietly failing gets caught at
`warmup_epochs` instead of at the end.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional, Sequence

TRIGGER_ORDER = ["divergence", "underperformance", "overfitting", "plateau"]


@dataclass
class TriggerConfig:
    # divergence
    loss_median_multiple: float = 10.0
    divergence_min_epochs: int = 3
    # plateau
    min_delta: float = 1e-3
    patience: int = 8
    # overfitting
    gap_threshold: float = 0.15          # relative to train performance
    # underperformance
    baseline_metric: Optional[float] = 0.75
    baseline_name: str = "convergence gate (clean AUC 0.75)"
    warmup_epochs: int = 20
    # thrash suppression
    min_epochs_between_interventions: int = 10
    max_rounds: int = 3

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TriggerEvent:
    name: str
    rule: str                 # human-readable, quoted verbatim in the log
    epoch: int
    value: float
    severity: str             # "immediate" | "considered"
    suggested_category: str   # "mechanical" | "method_altering"
    detail: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _finite(xs: Sequence[float]) -> List[float]:
    return [x for x in xs if x is not None and math.isfinite(x)]


def evaluate_triggers(
    history: Sequence[Dict[str, float]],
    cfg: TriggerConfig,
    *,
    metric_key: str = "val_auc",
    loss_key: str = "train_loss",
    train_metric_key: Optional[str] = "train_auc",
    higher_is_better: bool = True,
    last_intervention_epoch: Optional[int] = None,
) -> Optional[TriggerEvent]:
    """Return the highest-priority trigger that has fired, or None.

    `history` is the same list the trainer accumulates: one dict per epoch. The
    supervisor sees validation only -- there is no test key in this structure and
    `assert_no_test_split` enforces that upstream.
    """
    if not history:
        return None
    epoch = int(history[-1].get("epoch", len(history) - 1))
    losses = _finite([h.get(loss_key) for h in history])
    metrics = _finite([h.get(metric_key) for h in history])

    # --- divergence: fires immediately, before the thrash guard ---------
    last_loss = history[-1].get(loss_key)
    if last_loss is None or not math.isfinite(float(last_loss)):
        return TriggerEvent(
            "divergence", f"{loss_key} is NaN or infinite", epoch, float("nan"),
            "immediate", "mechanical", "loss is not a finite number",
        )
    if len(losses) >= cfg.divergence_min_epochs:
        median = sorted(losses)[len(losses) // 2]
        if median > 0 and last_loss > cfg.loss_median_multiple * median:
            return TriggerEvent(
                "divergence",
                f"{loss_key} exceeds {cfg.loss_median_multiple:g}x its running median",
                epoch, float(last_loss), "immediate", "mechanical",
                f"loss {last_loss:.4g} vs median {median:.4g}",
            )

    # --- thrash suppression --------------------------------------------
    if (
        last_intervention_epoch is not None
        and epoch - last_intervention_epoch < cfg.min_epochs_between_interventions
    ):
        return None

    # --- underperformance vs a named baseline --------------------------
    if cfg.baseline_metric is not None and epoch >= cfg.warmup_epochs and metrics:
        best = max(metrics) if higher_is_better else min(metrics)
        below = best < cfg.baseline_metric if higher_is_better else best > cfg.baseline_metric
        if below:
            return TriggerEvent(
                "underperformance",
                f"best {metric_key} below {cfg.baseline_name} after {cfg.warmup_epochs} epochs",
                epoch, float(best), "considered", "method_altering",
                f"best {metric_key} {best:.4f} vs baseline {cfg.baseline_metric:.4f}",
            )

    # --- overfitting ----------------------------------------------------
    if train_metric_key:
        tr = history[-1].get(train_metric_key)
        va = history[-1].get(metric_key)
        if tr is not None and va is not None and math.isfinite(tr) and math.isfinite(va) and tr > 0:
            gap = (tr - va) / abs(tr)
            if gap > cfg.gap_threshold:
                return TriggerEvent(
                    "overfitting",
                    f"train-validation gap exceeds {cfg.gap_threshold:.0%} of train performance",
                    epoch, float(gap), "considered", "mechanical",
                    f"train {tr:.4f} vs val {va:.4f} (gap {gap:.1%})",
                )

    # --- plateau ---------------------------------------------------------
    if len(metrics) > cfg.patience:
        window = metrics[-cfg.patience :]
        best_before = max(metrics[: -cfg.patience]) if higher_is_better else min(metrics[: -cfg.patience])
        gain = (max(window) - best_before) if higher_is_better else (best_before - min(window))
        if gain < cfg.min_delta:
            return TriggerEvent(
                "plateau",
                f"no {metric_key} gain > {cfg.min_delta:g} for {cfg.patience} epochs",
                epoch, float(gain), "considered", "mechanical",
                f"best before window {best_before:.4f}, best in window {max(window):.4f}",
            )
    return None
