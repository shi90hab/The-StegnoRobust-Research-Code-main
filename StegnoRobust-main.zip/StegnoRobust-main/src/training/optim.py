"""Per-detector optimiser and schedule recipes.

Reviewer 1, comment 8 asks for XuNet to be stabilised and Reviewer 2, comment 3
for SRNet to be trained to convergence. Using one learning rate and one epoch
budget for three architectures with radically different depths and front ends --
which is what the submitted study did -- is the direct cause of the failure. The
recipes below are the published ones for each detector, not tuned by us on the
test set.

  XuNet   Adam/SGD-momentum, lr 1e-4 with cosine decay, gradient clipping.
          The KV kernel is fixed, so there is no front-end LR group.
  YeNet   Adadelta in the original paper; Adam 1e-3 here for comparability, with
          the SRM bank on a 10x lower LR so the prior is not destroyed early.
  SRNet   Adamax 1e-3 for the long phase then 1e-4, per Boroumand et al.; this is
          the single change most likely to move SRNet off chance.

`no_weight_decay` excludes BatchNorm affine parameters and biases from decay --
decaying BN gamma toward zero in a collapsed network accelerates the collapse.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import torch
import torch.nn as nn


@dataclass
class OptimRecipe:
    optimizer: str = "adam"
    lr: float = 1e-3
    weight_decay: float = 5e-4
    momentum: float = 0.9
    scheduler: str = "cosine"          # cosine | step | plateau | none
    warmup_epochs: int = 0
    milestones: Tuple[int, ...] = (100, 150)
    gamma: float = 0.1
    grad_clip: Optional[float] = 5.0
    frontend_lr_scale: float = 0.1     # applies to YeNet's SRM bank
    epochs: int = 100
    early_stop_patience: Optional[int] = 25


# Published-recipe defaults per detector. Overridable from configs/detector/*.yaml.
RECIPES: Dict[str, OptimRecipe] = {
    "xunet": OptimRecipe(
        optimizer="sgd", lr=1e-3, weight_decay=5e-4, momentum=0.9,
        scheduler="cosine", warmup_epochs=5, grad_clip=1.0, epochs=150,
        early_stop_patience=30,
    ),
    "yenet": OptimRecipe(
        optimizer="adam", lr=1e-3, weight_decay=5e-4, scheduler="cosine",
        warmup_epochs=2, grad_clip=5.0, frontend_lr_scale=0.1, epochs=120,
        early_stop_patience=25,
    ),
    "srnet": OptimRecipe(
        optimizer="adamax", lr=1e-3, weight_decay=2e-4, scheduler="step",
        milestones=(300, 400), gamma=0.1, grad_clip=None, epochs=450,
        early_stop_patience=None,   # SRNet improves late; do not stop it early
    ),
}


def no_weight_decay(model: nn.Module) -> List[str]:
    names = []
    for n, p in model.named_parameters():
        if p.ndim <= 1 or n.endswith(".bias") or "bn" in n.lower() or ".b1." in n or ".b2." in n:
            names.append(n)
    return names


def param_groups(model: nn.Module, recipe: OptimRecipe) -> List[Dict[str, Any]]:
    nd = set(no_weight_decay(model))
    front, front_nd, body, body_nd = [], [], [], []
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        is_front = n.startswith("srm.") or n.startswith("hpf.")
        bucket = (front_nd if n in nd else front) if is_front else (body_nd if n in nd else body)
        bucket.append(p)
    groups = []
    if body:
        groups.append({"params": body, "lr": recipe.lr, "weight_decay": recipe.weight_decay})
    if body_nd:
        groups.append({"params": body_nd, "lr": recipe.lr, "weight_decay": 0.0})
    if front:
        groups.append({"params": front, "lr": recipe.lr * recipe.frontend_lr_scale, "weight_decay": 0.0})
    if front_nd:
        groups.append({"params": front_nd, "lr": recipe.lr * recipe.frontend_lr_scale, "weight_decay": 0.0})
    return groups


def build_optimizer(model: nn.Module, recipe: OptimRecipe) -> torch.optim.Optimizer:
    groups = param_groups(model, recipe)
    o = recipe.optimizer.lower()
    if o == "adam":
        return torch.optim.Adam(groups, lr=recipe.lr)
    if o == "adamw":
        return torch.optim.AdamW(groups, lr=recipe.lr)
    if o == "adamax":
        return torch.optim.Adamax(groups, lr=recipe.lr)
    if o == "sgd":
        return torch.optim.SGD(groups, lr=recipe.lr, momentum=recipe.momentum, nesterov=True)
    if o == "adadelta":
        return torch.optim.Adadelta(groups, lr=recipe.lr)
    raise ValueError(f"unknown optimizer '{recipe.optimizer}'")


def build_scheduler(optimizer: torch.optim.Optimizer, recipe: OptimRecipe, steps_per_epoch: int):
    """Warmup + main schedule as a SINGLE LambdaLR.

    torch's SequentialLR calls the child scheduler with an explicit `epoch`
    argument, which emits a deprecation warning on every step and uses the
    closed-form path rather than the chainable one. Composing the two phases into
    one lambda avoids that entirely and makes the resulting learning-rate curve a
    pure function of the epoch index -- which is what makes a resumed run
    reproduce an uninterrupted one.
    """
    import math

    from torch.optim.lr_scheduler import LambdaLR, ReduceLROnPlateau

    s = recipe.scheduler.lower()
    if s == "none":
        return None
    if s == "plateau":
        return ReduceLROnPlateau(optimizer, mode="max", factor=recipe.gamma, patience=10)

    warm = max(int(recipe.warmup_epochs), 0)
    total = max(int(recipe.epochs), 1)
    milestones = sorted(int(m) for m in recipe.milestones)

    def factor(epoch: int) -> float:
        if warm and epoch < warm:
            return (epoch + 1) / warm
        if s == "cosine":
            t = (epoch - warm) / max(total - warm, 1)
            return 0.5 * (1.0 + math.cos(math.pi * min(t, 1.0)))
        # step
        return recipe.gamma ** sum(1 for m in milestones if epoch >= m)

    return LambdaLR(optimizer, lr_lambda=factor)
