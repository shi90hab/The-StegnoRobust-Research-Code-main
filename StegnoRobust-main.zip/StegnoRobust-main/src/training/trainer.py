"""Detector training loop with best-validation checkpointing and auto-resume.

Directly answers Reviewer 1, comment 8 items (i)-(iv) and Reviewer 2, comments
3-4 and 6:

  (i)   model selection on best VALIDATION AUC, never the last epoch. The
        submitted study reported XuNet's final epoch while acknowledging its
        validation AUC "oscillates between 0.5 and 0.9" -- that is a selection
        bug, and `best_val_auc` fixes it.
  (ii)  XuNet stabilised: lower LR, warmup, gradient clipping, early stopping
        (see src/training/optim.py::RECIPES).
  (iii) SRNet trained on its established longer schedule with the Adamax step
        policy, optionally warm-started from a higher-payload curriculum stage.
  (iv)  a convergence guard: `TrainResult.converged` is set by the same
        `ConvergenceGate` used downstream, so a chance-level detector is excluded
        from the committee and from the held-out role automatically rather than
        by hand.

The test set is never loaded in this file. Selection touches validation only.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from ..evaluation.metrics import (
    ConvergenceGate,
    DetectionReport,
    detection_report,
    roc_auc,
    canonical_score,
)
from ..supervision.patch_stub import poll_and_apply, rebuild_optimizer_if_needed
from ..supervision.supervisor import SupervisorState
from ..utils.checkpoint import find_resume, load_checkpoint, save_checkpoint
from ..utils.git_provenance import CommitProvenance, commit_and_push
from .optim import OptimRecipe, build_optimizer, build_scheduler


@dataclass
class GitPolicy:
    """Commit-on-new-best, per skill §11.

    Not every epoch and not every checkpoint: a commit is made when validation
    improves on the previous best, so the history contains one entry per result
    that could appear in the paper. `commit_evaluation_artifacts` handles the
    single end-of-run commit separately.
    """

    enabled: bool = False
    repo: Optional[str] = None
    branch: str = "main"
    push: bool = True
    seed: int = 0
    config_hash: str = "unknown"
    wandb_run: Optional[str] = None
    metric_name: str = "val_auc"


@dataclass
class SupervisionPolicy:
    """Poll the agent/patches branch between epochs, per skill §12."""

    enabled: bool = False
    repo: Optional[str] = None
    max_rounds: int = 3


@dataclass
class TrainResult:
    detector: str
    best_val_auc: float
    best_epoch: int
    final_val_auc: float
    # Total epochs the model has completed, ACROSS resumes -- this is what the
    # convergence curves and the paper's schedule refer to.
    epochs_run: int
    converged: bool
    convergence_reason: str
    # Epochs completed in THIS invocation only. It differs from epochs_run after a
    # Colab reconnect, and conflating the two makes a resumed run look like it
    # trained twice as long as it did.
    epochs_this_session: int = 0
    resumed_from_epoch: Optional[int] = None
    history: List[Dict[str, float]] = field(default_factory=list)
    wall_clock_s: float = 0.0
    peak_vram_bytes: int = 0
    best_ckpt: Optional[str] = None
    commits: List[str] = field(default_factory=list)
    supervisor: Optional[Dict[str, Any]] = None
    supervisor_messages: List[str] = field(default_factory=list)


@torch.no_grad()
def evaluate_logits(
    model: nn.Module, loader: DataLoader, device: str, amp: bool = False
) -> Tuple[np.ndarray, np.ndarray]:
    model.eval()
    all_logits, all_labels = [], []
    for batch in loader:
        x, y = batch[0].to(device, non_blocking=True), batch[1]
        with torch.autocast(device_type="cuda", enabled=amp and device.startswith("cuda")):
            z = model(x)
        all_logits.append(z.float().cpu().numpy())
        all_labels.append(y.numpy())
    return np.concatenate(all_logits), np.concatenate(all_labels)


def train_detector(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    recipe: OptimRecipe,
    *,
    detector_name: str,
    device: str = "cuda",
    ckpt_dir: str | Path = "outputs/ckpt",
    gate: Optional[ConvergenceGate] = None,
    amp: bool = True,
    log_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
    resume: bool = True,
    label_smoothing: float = 0.0,
    save_every_epochs: int = 10,
    git_policy: Optional[GitPolicy] = None,
    supervision: Optional[SupervisionPolicy] = None,
    cfg: Any = None,
    epoch_callback: Optional[Callable[[int, float], None]] = None,
) -> TrainResult:
    gate = gate or ConvergenceGate()
    device_t = torch.device(device if torch.cuda.is_available() or device == "cpu" else "cpu")
    model = model.to(device_t)

    optimizer = build_optimizer(model, recipe)
    steps = max(len(train_loader), 1)
    scheduler = build_scheduler(optimizer, recipe, steps)
    scaler = torch.amp.GradScaler("cuda", enabled=amp and device_t.type == "cuda")

    ckpt_dir = Path(ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    last_ckpt = ckpt_dir / f"{detector_name}_last.pt"
    best_ckpt = ckpt_dir / f"{detector_name}_best.pt"

    git_policy = git_policy or GitPolicy()
    supervision = supervision or SupervisionPolicy()

    start_epoch, best_auc, best_epoch = 0, -1.0, -1
    history: List[Dict[str, float]] = []
    # The revision budget lives in the checkpoint, not in memory: a Colab
    # reconnect would otherwise reset the counter and the cap would mean nothing.
    sup_state = SupervisorState(max_rounds=supervision.max_rounds)
    commits: List[str] = []
    sup_messages: List[str] = []

    if resume and find_resume(last_ckpt):
        ck = load_checkpoint(
            last_ckpt, model=model, optimizer=optimizer, scheduler=scheduler,
            scaler=scaler, map_location=str(device_t),
        )
        start_epoch = int(ck["epoch"]) + 1
        best_auc = float(ck.get("best_metric", -1.0))
        history = ck.get("extra", {}).get("history", [])
        best_epoch = ck.get("extra", {}).get("best_epoch", -1)
        sup_state = SupervisorState.from_checkpoint(ck)
        sup_state.max_rounds = supervision.max_rounds
        print(f"[{detector_name}] resumed at epoch {start_epoch} (best val AUC {best_auc:.4f}, "
              f"agent round {sup_state.round}/{sup_state.max_rounds})")

    if device_t.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    epochs_no_improve = 0
    final_auc = float("nan")

    for epoch in range(start_epoch, recipe.epochs):
        # --- supervisor: apply any patch published since the last epoch ------
        if supervision.enabled and supervision.repo and cfg is not None:
            cfg, sup_state, msgs = poll_and_apply(supervision.repo, cfg, sup_state)
            for m in msgs:
                print(f"[supervisor/stub] {m}")
                sup_messages.append(f"epoch {epoch}: {m}")
            if msgs:
                # A learning-rate override does nothing unless the optimizer is
                # rebuilt; forgetting this is how an "applied" patch quietly
                # has no effect.
                try:
                    recipe = OptimRecipe(**dict(cfg.detector[detector_name].optim))
                except Exception:
                    pass
                optimizer, rebuilt = rebuild_optimizer_if_needed(msgs, model, recipe, optimizer)
                if rebuilt:
                    scheduler = build_scheduler(optimizer, recipe, steps)

        sampler = getattr(train_loader, "batch_sampler", None)
        if hasattr(sampler, "set_epoch"):
            sampler.set_epoch(epoch)

        model.train()
        running, nb = 0.0, 0
        for x, y, *_ in train_loader:
            x = x.to(device_t, non_blocking=True)
            y = y.to(device_t, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", enabled=scaler.is_enabled()):
                loss = F.cross_entropy(model(x), y, label_smoothing=label_smoothing)
            scaler.scale(loss).backward()
            if recipe.grad_clip:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), recipe.grad_clip)
            scaler.step(optimizer)
            scaler.update()
            running += float(loss.detach())
            nb += 1

        logits, labels = evaluate_logits(model, val_loader, str(device_t), amp=scaler.is_enabled())
        val_auc = roc_auc(labels, canonical_score(logits))
        final_auc = val_auc
        train_loss = running / max(nb, 1)

        if scheduler is not None:
            scheduler.step(val_auc) if recipe.scheduler == "plateau" else scheduler.step()

        rec = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_auc": val_auc,
            "lr": optimizer.param_groups[0]["lr"],
        }
        history.append(rec)
        if log_fn:
            log_fn({f"{detector_name}/{k}": v for k, v in rec.items()})

        # Integration point for Optuna pruning. The callback raises TrialPruned,
        # which propagates out of the loop -- so a pruned trial exits through the
        # normal exception path rather than crashing mid-epoch with a half-written
        # checkpoint. The checkpoint below has already been written for the epochs
        # that did complete, so a pruned trial is still resumable if you want it.
        if epoch_callback is not None:
            epoch_callback(epoch, val_auc)

        def _extra() -> Dict[str, Any]:
            return {
                "history": history,
                "best_epoch": best_epoch,
                "recipe": recipe.__dict__,
                "supervisor": sup_state.to_checkpoint_extra(),
            }

        improved = val_auc > best_auc
        if improved:
            previous_best = best_auc if best_auc >= 0 else None
            best_auc, best_epoch, epochs_no_improve = val_auc, epoch, 0
            save_checkpoint(
                best_ckpt, epoch=epoch, model=model, optimizer=optimizer,
                scheduler=scheduler, scaler=scaler, best_metric=best_auc, extra=_extra(),
            )
            # Commit policy: on new best only. The message carries seed, config
            # hash and run id so any number in the manuscript traces to a state.
            if git_policy.enabled and git_policy.repo:
                prov = CommitProvenance(
                    metric_name=git_policy.metric_name, metric_value=best_auc,
                    previous_best=previous_best, epoch=epoch, seed=git_policy.seed,
                    config_hash=git_policy.config_hash, wandb_run=git_policy.wandb_run,
                    trigger="new_best_val",
                    agent_revision=(f"{sup_state.round}/{sup_state.max_rounds}" if sup_state.round else None),
                    detector=detector_name,
                )
                try:
                    sha = commit_and_push(
                        git_policy.repo,
                        ["configs", "src", str(best_ckpt), "outputs/agent_interventions.jsonl"],
                        prov, push=git_policy.push, branch=git_policy.branch,
                    )
                    if sha:
                        commits.append(sha)
                except Exception as e:
                    # Version control must never take down a training run.
                    print(f"[git] commit skipped ({e})")
        else:
            epochs_no_improve += 1

        # `last.pt` is the resume point, and it is ~29 MB for SRNet. Writing it to
        # mounted Drive on EVERY epoch is 13 GB per seed over a 450-epoch run --
        # enough to slow training measurably and to starve a second Colab session
        # trying to mount the same Drive. Write it every N epochs instead, plus
        # unconditionally on the final epoch so a completed run is always
        # resumable-as-finished. The cost is losing at most N epochs on a crash.
        is_last_epoch = epoch == recipe.epochs - 1
        if save_every_epochs <= 1 or epoch % save_every_epochs == 0 or is_last_epoch:
            save_checkpoint(
                last_ckpt, epoch=epoch, model=model, optimizer=optimizer, scheduler=scheduler,
                scaler=scaler, best_metric=best_auc, extra=_extra(),
            )

        if recipe.early_stop_patience and epochs_no_improve >= recipe.early_stop_patience:
            print(f"[{detector_name}] early stop at epoch {epoch} (no val gain for "
                  f"{epochs_no_improve} epochs; best {best_auc:.4f} @ {best_epoch})")
            break

    wall = time.time() - t0
    epochs_this_session = max(0, len(history) - start_epoch)
    peak = torch.cuda.max_memory_allocated() if device_t.type == "cuda" else 0

    # Restore the SELECTED model, not the last one. Everything downstream --
    # clean benchmarking, the attack, the transferability sweep -- uses this.
    if best_ckpt.exists():
        load_checkpoint(best_ckpt, model=model, map_location=str(device_t), restore_rng=False)

    logits, labels = evaluate_logits(model, val_loader, str(device_t))
    rep = detection_report(detector_name, labels, logits)
    ok, why = gate.admits(rep)

    return TrainResult(
        detector=detector_name,
        best_val_auc=best_auc,
        best_epoch=best_epoch,
        final_val_auc=final_auc,
        epochs_run=len(history),
        epochs_this_session=epochs_this_session,
        resumed_from_epoch=(start_epoch if start_epoch > 0 else None),
        converged=ok,
        convergence_reason=why,
        history=history,
        wall_clock_s=wall,
        peak_vram_bytes=int(peak),
        best_ckpt=str(best_ckpt),
        commits=commits,
        supervisor=sup_state.to_checkpoint_extra(),
        supervisor_messages=sup_messages,
    )
