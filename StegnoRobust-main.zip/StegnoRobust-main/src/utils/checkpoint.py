"""Colab-safe full-state checkpointing with auto-resume.

Design assumption: the session WILL disconnect. Local disk (/content) dies with
the VM, so checkpoints are written to Drive. Writes go to a temp path followed by
os.replace, so a disconnect mid-write cannot corrupt the only checkpoint.

RNG state is part of the checkpoint. Without it a resumed run is *restartable*
but not *reproducible*, and those are different properties -- Reviewer 2 asked
for the second one.
"""
from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch


def save_checkpoint(
    path: str | Path,
    *,
    epoch: int,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Optional[Any] = None,
    scaler: Optional[Any] = None,
    best_metric: float = float("-inf"),
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict() if scheduler is not None else None,
        "scaler_state_dict": scaler.state_dict() if scaler is not None else None,
        "best_metric": best_metric,
        "rng_state": torch.get_rng_state(),
        "cuda_rng_state": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
        "numpy_rng_state": np.random.get_state(),
        "python_rng_state": random.getstate(),
        "extra": extra or {},
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, tmp)
    os.replace(tmp, path)


def load_checkpoint(
    path: str | Path,
    *,
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer] = None,
    scheduler: Optional[Any] = None,
    scaler: Optional[Any] = None,
    map_location: str = "cpu",
    restore_rng: bool = True,
) -> Dict[str, Any]:
    ckpt = torch.load(path, map_location=map_location, weights_only=False)
    model.load_state_dict(ckpt["model_state_dict"])
    if optimizer is not None and ckpt.get("optimizer_state_dict"):
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
    if scheduler is not None and ckpt.get("scheduler_state_dict"):
        scheduler.load_state_dict(ckpt["scheduler_state_dict"])
    if scaler is not None and ckpt.get("scaler_state_dict"):
        scaler.load_state_dict(ckpt["scaler_state_dict"])
    if restore_rng:
        if ckpt.get("rng_state") is not None:
            torch.set_rng_state(ckpt["rng_state"].cpu().to(torch.uint8))
        if ckpt.get("cuda_rng_state") is not None and torch.cuda.is_available():
            torch.cuda.set_rng_state_all([s.cpu().to(torch.uint8) for s in ckpt["cuda_rng_state"]])
        if ckpt.get("numpy_rng_state") is not None:
            np.random.set_state(ckpt["numpy_rng_state"])
        if ckpt.get("python_rng_state") is not None:
            random.setstate(ckpt["python_rng_state"])
    return ckpt


def find_resume(path: str | Path) -> Optional[Path]:
    p = Path(path)
    return p if p.exists() else None


def stage_dataset(drive_archive: str | Path, local_root: str | Path) -> Path:
    """Copy+unpack a dataset archive from Drive to local disk exactly once.

    Reading images directly from mounted Drive dominates epoch wall-clock on
    Colab. The guard means a resumed session does not re-download.
    """
    import shutil

    local_root = Path(local_root)
    if local_root.exists() and any(local_root.iterdir()):
        return local_root
    local_root.mkdir(parents=True, exist_ok=True)
    tmp_zip = Path("/content") / Path(drive_archive).name
    if not tmp_zip.exists():
        shutil.copy(drive_archive, tmp_zip)
    shutil.unpack_archive(str(tmp_zip), str(local_root))
    return local_root
