"""Git provenance: authentication, commit policy, and traceable commit messages.

One repository per paper. The history is the record of how the result was
reached, so every commit that carries a number must also carry the state that
produced it.

Security posture (this is the part that goes wrong in practice):

  * The fine-grained PAT is never accepted in conversation, never hardcoded,
    never committed, and never written into the remote URL. `git remote set-url`
    persists credentials in `.git/config`, which is trivially leaked by sharing a
    repository directory or a Colab VM image.
  * The token is read at runtime from Colab Secrets and passed per-invocation
    through a `credential.helper` that exists only for the duration of that one
    git process.
  * `assert_token_not_persisted` scans `.git/config` and the remote URL and
    raises if a token is found there, so a mistake made once is caught before the
    next push rather than after the repository is public.

Commit policy (skill §11): commit when validation improves on the previous best,
not every epoch and not every checkpoint, plus exactly one end-of-run commit
carrying evaluation artifacts, which are produced after training stops and would
otherwise never land.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

# Weight files: only best_model.pt is tracked, and only through LFS. Intermediate
# checkpoints stay on Drive and are referenced by path. Free-tier LFS quotas are
# small enough that one careless glob exhausts them.
GITATTRIBUTES = "*_best.pt filter=lfs diff=lfs merge=lfs -text\nbest_model.pt filter=lfs diff=lfs merge=lfs -text\n"

GITIGNORE_REQUIRED = [
    "outputs/",
    "wandb/",
    "data/",
    "*.pt",
    "!best_model.pt",
    "!*_best.pt",
    ".env",
    "*.pem",
]

TOKEN_PATTERN = re.compile(r"(gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})")


class TokenLeak(RuntimeError):
    pass


# --------------------------------------------------------------------------
# Authentication
# --------------------------------------------------------------------------


def load_pat(env_var: str = "GITHUB_PAT", required: bool = False) -> Optional[str]:
    """Read the PAT from Colab Secrets, falling back to the environment.

    Never takes the token as a function argument, so it cannot end up in a
    traceback, a notebook output cell, or a log line.
    """
    tok = os.environ.get(env_var)
    if not tok:
        try:
            from google.colab import userdata  # type: ignore

            tok = userdata.get(env_var)
            if tok:
                os.environ[env_var] = tok
        except Exception:
            tok = None
    if not tok and required:
        raise RuntimeError(
            f"{env_var} is not set. Store a fine-grained PAT in Colab Secrets "
            f"(scoped to this repository, Contents: read/write only, expiry <= 90 days) "
            f"and read it with `from google.colab import userdata`. Do not paste the "
            f"token into a chat or a notebook cell -- a token in message history "
            f"cannot be reliably retracted."
        )
    return tok


def _credential_helper() -> str:
    """A helper that reads the token from the environment of this git process only."""
    return "!f(){ echo username=x-access-token; echo password=$GITHUB_PAT; };f"


def git(
    *args: str,
    repo: str | Path = ".",
    use_credentials: bool = False,
    check: bool = True,
    capture: bool = True,
) -> subprocess.CompletedProcess:
    cmd: List[str] = ["git", "-C", str(repo)]
    if use_credentials:
        cmd += ["-c", f"credential.helper={_credential_helper()}"]
    cmd += list(args)
    return subprocess.run(
        cmd, check=check, text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT if capture else None,
    )


def assert_token_not_persisted(repo: str | Path = ".") -> None:
    """Fail loudly if a token has been written into git config or a remote URL."""
    cfg = Path(repo) / ".git" / "config"
    if cfg.exists():
        m = TOKEN_PATTERN.search(cfg.read_text(errors="ignore"))
        if m:
            raise TokenLeak(
                f"A GitHub token is stored in {cfg}. Remove it "
                f"(`git remote set-url origin https://github.com/<owner>/<repo>.git`), "
                f"then REVOKE the token -- it must be assumed compromised."
            )
    try:
        url = git("remote", "get-url", "origin", repo=repo, check=False).stdout or ""
    except Exception:
        url = ""
    if TOKEN_PATTERN.search(url) or "@github.com" in url and "x-access-token" in url:
        raise TokenLeak(
            "The origin remote URL embeds a credential. Reset it to the plain HTTPS "
            "URL and pass the token per-invocation instead."
        )


# --------------------------------------------------------------------------
# Repository setup
# --------------------------------------------------------------------------


def ensure_repo(repo: str | Path, remote: Optional[str] = None, branch: str = "main") -> Path:
    repo = Path(repo)
    repo.mkdir(parents=True, exist_ok=True)
    if not (repo / ".git").exists():
        git("init", "-b", branch, repo=repo)
    (repo / ".gitattributes").write_text(GITATTRIBUTES)

    gi = repo / ".gitignore"
    existing = gi.read_text().splitlines() if gi.exists() else []
    for line in GITIGNORE_REQUIRED:
        if line not in existing:
            existing.append(line)
    gi.write_text("\n".join(existing) + "\n")

    if remote:
        current = git("remote", "get-url", "origin", repo=repo, check=False).stdout.strip()
        if not current:
            git("remote", "add", "origin", remote, repo=repo)
        elif current != remote:
            git("remote", "set-url", "origin", remote, repo=repo)
    assert_token_not_persisted(repo)
    return repo


def config_hash(config: Any) -> str:
    """Stable short hash of the fully resolved config; goes in every commit message."""
    try:
        from omegaconf import OmegaConf

        if OmegaConf.is_config(config):
            config = OmegaConf.to_container(config, resolve=True)
    except Exception:
        pass
    blob = json.dumps(config, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode()).hexdigest()[:7]


# --------------------------------------------------------------------------
# Commit messages carrying provenance
# --------------------------------------------------------------------------


@dataclass
class CommitProvenance:
    """Every field here is something a reviewer might ask us to produce."""

    metric_name: str
    metric_value: float
    previous_best: Optional[float]
    epoch: int
    seed: int
    config_hash: str
    wandb_run: Optional[str]
    trigger: str                      # new_best_val | end_of_run | agent_patch
    agent_revision: Optional[str] = None   # "2/3" when an autonomous edit is in effect
    detector: Optional[str] = None

    def message(self) -> str:
        import math

        prev = f" (prev {self.previous_best:.4f})" if self.previous_best is not None else " (first)"
        who = f"[{self.detector}] " if self.detector else ""
        if self.trigger == "new_best_val":
            subject = f"best: {who}{self.metric_name} {self.metric_value:.4f}{prev} @ epoch {self.epoch}"
        elif not math.isfinite(self.metric_value) or self.epoch < 0:
            # An agent patch or an artifact commit has no epoch and no metric of
            # its own; printing "nan @ epoch -1" would be noise in the history.
            subject = f"{self.trigger}: {who}{self.metric_name} pending"
        else:
            subject = f"{self.trigger}: {who}{self.metric_name} {self.metric_value:.4f} @ epoch {self.epoch}"
        body = [
            "",
            f"seed: {self.seed}",
            f"config_hash: {self.config_hash}",
            f"wandb_run: {self.wandb_run or 'n/a'}",
            f"trigger: {self.trigger}",
        ]
        if self.agent_revision:
            body.append(f"agent_revision: {self.agent_revision}")
        return subject + "\n" + "\n".join(body) + "\n"

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def commit_and_push(
    repo: str | Path,
    paths: Sequence[str | Path],
    prov: CommitProvenance,
    *,
    push: bool = True,
    branch: str = "main",
    allow_empty: bool = False,
) -> Optional[str]:
    """Stage `paths`, commit with a provenance message, optionally push.

    Returns the commit SHA, or None when there was nothing to commit -- which is
    the normal case for a run that produced no new best.
    """
    repo = Path(repo)
    assert_token_not_persisted(repo)

    for p in paths:
        git("add", "--", str(p), repo=repo, check=False)

    staged = git("diff", "--cached", "--name-only", repo=repo, check=False).stdout.strip()
    if not staged and not allow_empty:
        return None

    args = ["commit", "-m", prov.message()]
    if allow_empty:
        args.insert(1, "--allow-empty")
    git(*args, repo=repo)
    sha = git("rev-parse", "HEAD", repo=repo).stdout.strip()

    if push:
        if not load_pat():
            print("[git] no GITHUB_PAT available; committed locally, skipping push")
            return sha
        res = git("push", "origin", branch, repo=repo, use_credentials=True, check=False)
        if res.returncode != 0:
            # A failed push must not kill a training run that is otherwise fine.
            print(f"[git] push failed (commit {sha[:7]} is safe locally):\n{res.stdout}")
    return sha


def commit_evaluation_artifacts(
    repo: str | Path, prov: CommitProvenance, artifact_dirs: Iterable[str | Path] = ("outputs/tables", "outputs/figures"),
) -> Optional[str]:
    """The single end-of-run commit for .tex tables, vector plots, profiling.

    These are produced after training stops, so the commit-on-new-best rule would
    never capture them. `outputs/` is gitignored, so paths are force-added.
    """
    repo = Path(repo)
    added: List[str] = []
    for d in artifact_dirs:
        p = Path(repo) / d
        if p.exists():
            git("add", "-f", "--", str(d), repo=repo, check=False)
            added.append(str(d))
    for extra in ("outputs/agent_interventions.jsonl", "outputs/metrics"):
        if (repo / extra).exists():
            git("add", "-f", "--", extra, repo=repo, check=False)
            added.append(extra)
    if not added:
        return None
    return commit_and_push(repo, added, prov)
