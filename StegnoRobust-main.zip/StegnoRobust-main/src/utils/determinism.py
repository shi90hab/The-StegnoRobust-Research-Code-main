"""Seed locking and determinism.

Reviewer 2, comment 6 ("Reproducibility is weak") requires that every reported
number be regenerable bit-for-bit. `set_seed` MUST be the first call in every
entry point, before any CUDA context is created, because CUBLAS_WORKSPACE_CONFIG
is read by cuBLAS at initialisation time and ignored if set afterwards.
"""
from __future__ import annotations

import os
import random
import subprocess
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional

import numpy as np


def set_seed(seed: int, deterministic: bool = True) -> None:
    """Lock every source of randomness. Call at the top of the entry point."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    random.seed(seed)
    np.random.seed(seed)

    import torch

    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        # warn_only=True: adaptive_avg_pool2d_backward (used by SRNet's global
        # pooling head) has no deterministic CUDA kernel as of torch 2.3. The
        # exception is documented in README.md section "Determinism exceptions"
        # rather than silently disabled.
        torch.use_deterministic_algorithms(True, warn_only=True)


def seed_worker(worker_id: int) -> None:
    """DataLoader worker_init_fn. Workers reseed per epoch without this."""
    import torch

    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def make_generator(seed: int):
    import torch

    g = torch.Generator()
    g.manual_seed(seed)
    return g


def git_commit() -> str:
    try:
        return (
            subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL)
            .decode()
            .strip()
        )
    except Exception:
        return "unavailable"


@dataclass
class Provenance:
    """Attached to every metrics record so no number is orphaned from its origin.

    `threads` and `thread_mode` are part of this record, not an afterthought:
    BLAS reduction order depends on the thread count, so the same seed at a
    different thread setting produces different floats. Seed alone does not
    reproduce a CPU run.
    """

    seed: int
    git_commit: str
    torch_version: str
    cuda_version: Optional[str]
    gpu_name: Optional[str]
    hostname: str
    timestamp: str
    threads: Optional[int] = None
    thread_mode: Optional[str] = None
    target: Optional[str] = None
    hardware: Optional[str] = None
    timing_reportable: Optional[bool] = None

    @staticmethod
    def capture(seed: int, fingerprint: Optional[Any] = None) -> "Provenance":
        import socket
        from datetime import datetime, timezone

        import torch

        gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
        return Provenance(
            seed=seed,
            git_commit=git_commit(),
            torch_version=torch.__version__,
            cuda_version=torch.version.cuda,
            gpu_name=gpu,
            hostname=socket.gethostname(),
            timestamp=datetime.now(timezone.utc).isoformat(),
            threads=(fingerprint.threads if fingerprint else None),
            thread_mode=(fingerprint.thread_mode if fingerprint else None),
            target=(fingerprint.target if fingerprint else None),
            hardware=(fingerprint.label() if fingerprint else None),
            timing_reportable=(fingerprint.timing_reportable if fingerprint else None),
        )

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)
