"""Execution target, thread pinning, and hardware fingerprinting.

Skill §13. The governing idea: a run that silently changes hardware is a run
whose timings mean nothing. So the target is declared, never inferred, and the
hardware that produced each number is recorded next to the number.

Why local is the default for CPU work here, concretely. This project has two
kinds of compute:

  * Detector training (XuNet/YeNet/SRNet, 256x256, SRNet for 450 epochs) -- GPU
    work; `env=colab_gpu`.
  * The embedding comparison (HILL and S-UNIWARD cost maps, the ternary
    payload-constrained simulator, LSB variants) -- pure NumPy/SciPy, entirely
    CPU-bound, and the single largest CPU cost in the repository. That is §13's
    "classical, CPU-bound preprocessing" case exactly; it runs `env=local`.

A hosted runtime allocates a different VM each session, so its CPU model varies
run to run. Numerics survive once threads are pinned; timings do not.

One project-specific consequence worth stating. The determinism exception
documented in the README -- `adaptive_avg_pool2d_backward` has no deterministic
CUDA kernel, reached through SRNet's pooling head -- does not exist on CPU. A
fully deterministic SRNet reference run is therefore possible at `env=local`,
slowly. That is §13's "an op has no deterministic CUDA kernel and determinism
matters more than speed" routing rule applied to this codebase.
"""
from __future__ import annotations

import os
import platform
import subprocess
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

# Declared targets. `env` is a Hydra group, not a runtime guess.
TARGETS = ("local", "colab_cpu", "colab_gpu")

# Modes. Pinned runs are reproducible and slow; exploration runs are fast and
# must never contribute a number to a table.
THREAD_MODES = ("pinned", "exploration")


class UnreportableTiming(RuntimeError):
    """Raised when a timing would be reported from hardware that cannot support it."""


def pin_threads(n: int = 1) -> Dict[str, str]:
    """Pin BLAS thread counts. Must run before numpy/torch import their backends.

    Seeding alone is insufficient on CPU: BLAS reduction order changes with the
    thread count, so the same seed at a different thread setting produces
    different floats. The thread count is part of the reproducibility contract
    and is recorded alongside the seed.
    """
    env = {
        "OMP_NUM_THREADS": str(n),
        "MKL_NUM_THREADS": str(n),
        "OPENBLAS_NUM_THREADS": str(n),
        "NUMEXPR_NUM_THREADS": str(n),
        "VECLIB_MAXIMUM_THREADS": str(n),   # Accelerate, on macOS
    }
    os.environ.update(env)
    try:
        import torch

        torch.set_num_threads(n)
        torch.set_num_interop_threads(1)
    except (ImportError, RuntimeError):
        # set_num_interop_threads raises if the pool already started; harmless.
        pass
    return env


def sklearn_n_jobs(cfg_value: Optional[int], mode: str) -> int:
    """Resolve n_jobs explicitly. `-1` is never allowed for a reported run.

    `n_jobs=-1` makes the result depend on the machine's core count, so a figure
    produced with it is not reproducible on another host.
    """
    if mode == "pinned":
        if cfg_value in (None, -1):
            return 1
        return int(cfg_value)
    return int(cfg_value) if cfg_value not in (None,) else 1


def _cpu_model() -> str:
    try:
        if platform.system() == "Darwin":
            return subprocess.check_output(
                ["sysctl", "-n", "machdep.cpu.brand_string"], text=True
            ).strip()
        if platform.system() == "Linux":
            for line in open("/proc/cpuinfo"):
                if line.startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return platform.processor() or platform.machine() or "unknown"


def _is_colab() -> bool:
    try:
        import google.colab  # type: ignore  # noqa: F401

        return True
    except ImportError:
        return "COLAB_GPU" in os.environ or "COLAB_RELEASE_TAG" in os.environ


@dataclass
class HardwareFingerprint:
    """Recorded with every metric. A latency without this is not interpretable."""

    target: str
    device: str                 # "cpu" | "cuda" | "mps"
    device_name: str
    cpu_model: str
    cpu_count: int
    threads: int
    thread_mode: str
    total_ram_gb: float
    platform: str
    is_hosted: bool
    timing_reportable: bool
    timing_note: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def label(self) -> str:
        """Short string for the hardware column of a results table."""
        if self.device == "cuda":
            return self.device_name
        return f"CPU {self.cpu_model.split('@')[0].strip()} ({self.threads}t)"


def _total_ram_gb() -> float:
    try:
        import psutil

        return round(psutil.virtual_memory().total / 1e9, 1)
    except ImportError:
        try:
            return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1e9, 1)
        except (ValueError, OSError, AttributeError):
            return float("nan")


def resolve_device(target: str, allow_mps: bool = False) -> tuple[str, str]:
    """Return (device, device_name). MPS is refused for reported runs.

    Apple Silicon: operator coverage is incomplete and unsupported ops fall back
    to CPU silently, which makes a latency figure meaningless. CPU is the
    defensible target on a Mac.
    """
    import torch

    if target == "colab_gpu":
        if not torch.cuda.is_available():
            raise RuntimeError(
                "env=colab_gpu but no CUDA device is visible. Either switch the runtime "
                "type, or set env=colab_cpu / env=local explicitly -- do not let a GPU "
                "run silently become a CPU run, because the timings will not be comparable."
            )
        return "cuda", torch.cuda.get_device_name(0)

    if allow_mps and getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps", "Apple MPS (exploration only)"
    return "cpu", _cpu_model()


def configure(
    target: str,
    *,
    threads: int = 1,
    thread_mode: str = "pinned",
    allow_mps: bool = False,
) -> HardwareFingerprint:
    """Declare the execution target and pin the machine to match it.

    Call immediately after `set_seed` and before any tensor is created.
    """
    if target not in TARGETS:
        raise ValueError(f"env target must be one of {TARGETS}, got '{target}'")
    if thread_mode not in THREAD_MODES:
        raise ValueError(f"thread_mode must be one of {THREAD_MODES}, got '{thread_mode}'")

    hosted = _is_colab()
    if target == "local" and hosted:
        raise RuntimeError(
            "env=local but this process is running on a hosted runtime. Set "
            "env=colab_cpu or env=colab_gpu so the recorded hardware matches reality."
        )

    n = threads if thread_mode == "pinned" else max(threads, os.cpu_count() or 1)
    pin_threads(n)
    device, device_name = resolve_device(target, allow_mps=allow_mps)

    # Timing reportability. Three independent ways a number becomes unusable.
    reportable, note = True, ""
    if thread_mode != "pinned":
        reportable = False
        note = (
            "thread_mode=exploration: BLAS reduction order and parallelism vary, so "
            "wall-clock is not comparable. Metrics are fine; timings are not."
        )
    elif device == "mps":
        reportable = False
        note = (
            "MPS: unsupported operators fall back to CPU silently, so latency measures "
            "an unknown mixture of devices. Label it and never mix with CUDA or CPU rows."
        )
    elif hosted and device == "cpu":
        reportable = False
        note = (
            "hosted CPU runtime: the VM's CPU model varies between sessions, so wall-clock "
            "is not comparable across runs. Use env=local for any timing that will be "
            "reported; this target is for memory-heavy exploration and the demo notebook."
        )

    fp = HardwareFingerprint(
        target=target, device=device, device_name=device_name, cpu_model=_cpu_model(),
        cpu_count=os.cpu_count() or 0, threads=n, thread_mode=thread_mode,
        total_ram_gb=_total_ram_gb(), platform=platform.platform(), is_hosted=hosted,
        timing_reportable=reportable, timing_note=note,
    )
    if not reportable:
        print(f"[env] timings from this run are NOT reportable -- {note}")
    return fp


def assert_timing_reportable(fp: HardwareFingerprint, what: str = "this measurement") -> None:
    if not fp.timing_reportable:
        raise UnreportableTiming(f"{what} cannot enter a results table: {fp.timing_note}")


def low_ram_guard(
    fp: HardwareFingerprint, n_jobs: int, dataset_bytes: int, *, fraction: float = 0.5
) -> tuple[int, str]:
    """Cap joblib parallelism on a memory-constrained host.

    Joblib copies the dataset into every worker, so the peak is (n_jobs + 1)
    copies -- the workers plus the parent, which is the term people forget. A
    1 GB frame at n_jobs=6 therefore costs 7 GB before the estimator allocates
    anything.

    This fails badly rather than cleanly: on a machine that cannot hold the
    copies, the symptom is swap thrash and a run that appears merely slow, not an
    OOM. So the cap is applied up front against *available* memory (not total,
    which the OS and other processes are already using), and the reason is
    printed so the ceiling is visible before it is hit.
    """
    if fp.total_ram_gb != fp.total_ram_gb:  # NaN
        return n_jobs, "RAM unknown; n_jobs left unchanged"

    available = None
    try:
        import psutil

        available = psutil.virtual_memory().available
    except ImportError:
        pass
    if available is None:
        # Without psutil, assume ~60% of total is actually free. Deliberately
        # pessimistic: over-estimating free memory is the expensive mistake here.
        available = fp.total_ram_gb * 1e9 * 0.6

    budget = available * fraction
    per_copy = max(dataset_bytes, 1)
    safe = max(1, int(budget // per_copy) - 1)   # -1 for the parent's own copy
    if safe < n_jobs:
        return safe, (
            f"n_jobs reduced {n_jobs} -> {safe}: joblib copies the dataset per worker "
            f"({per_copy/1e9:.2f} GB each, plus the parent's copy), and only "
            f"{available/1e9:.1f} GB is available on this {fp.total_ram_gb:.0f} GB host. "
            f"Exceeding it degrades into swap thrash rather than a clean error."
        )
    return n_jobs, "within the memory budget"
