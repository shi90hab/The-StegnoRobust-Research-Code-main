"""Feature-level transferable attacks: FIA and NAA.

Reviewer 2, comment 2 names this family directly -- "closely related recent work
such as neuron-attribution-based transferable adversarial steganography". These
attacks do not maximise the surrogate's output loss (which is what overfits to
the surrogate); they corrupt the *intermediate features* that every architecture
in the family must compute, which is why they transfer.

FIA -- Feature Importance-Aware attack (Wang et al., ICCV 2021)
    Estimate a per-channel importance map by aggregating gradients of the loss
    w.r.t. a mid-level feature map over randomly masked inputs, then minimise the
    inner product <importance, features>.

NAA -- Neuron Attribution-based Attack (Zhang et al., CVPR 2022)
    Replace FIA's gradient-magnitude proxy with an integrated-gradients
    attribution computed along the path from a baseline image to the input, and
    weight positive and negative attributions asymmetrically. This is the method
    the reviewer is pointing at.

Choosing the layer: for steganalysis the informative layer is the one just after
the high-pass front end has been non-linearly mixed -- `body.2` for YeNet, `g2`
for XuNet, `l3` for SRNet. Defaults live in configs/attack/naa.yaml so the
choice is a recorded experimental parameter, not a constant buried in code.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Dict, List, Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import Attack, AttackConfig, CommitteeLoss
from .common import clamp_to_image, linf_project, to_detector_input

DEFAULT_LAYERS = {"XuNet": "g2", "YeNet": "body.2", "SRNet": "l3"}


def _get_module(model: nn.Module, path: str) -> nn.Module:
    m = model
    for part in path.split("."):
        m = m[int(part)] if part.isdigit() else getattr(m, part)
    return m


class _FeatureTap:
    """Captures the output of one named layer, and its gradient."""

    def __init__(self, model: nn.Module, layer: str):
        self.model = model
        self.layer = layer
        self.features: Optional[torch.Tensor] = None
        self._handle = None

    @contextmanager
    def attached(self):
        mod = _get_module(self.model, self.layer)

        def hook(_m, _inp, out):
            out.retain_grad()
            self.features = out

        self._handle = mod.register_forward_hook(hook)
        try:
            yield self
        finally:
            self._handle.remove()
            self._handle = None


class FIA(Attack):
    def __init__(self, loss_fn: CommitteeLoss, cfg: AttackConfig, layers: Optional[Dict[str, str]] = None):
        super().__init__(loss_fn, cfg)
        self.layers = layers or DEFAULT_LAYERS
        self.n_ens = int(cfg.extra.get("fia_ensemble", 30))
        self.drop_prob = float(cfg.extra.get("fia_drop_prob", 0.3))
        self.decay = float(cfg.extra.get("decay", 1.0))

    def _importance(self, x: torch.Tensor, y_target: torch.Tensor) -> List[torch.Tensor]:
        """Aggregate feature gradients over randomly masked copies of the input."""
        maps: List[torch.Tensor] = []
        for model in self.loss_fn.models:
            layer = self.layers.get(getattr(model, "name", ""), None)
            if layer is None:
                maps.append(None)  # type: ignore[arg-type]
                continue
            tap = _FeatureTap(model, layer)
            acc = None
            with tap.attached():
                for _ in range(self.n_ens):
                    mask = (torch.rand_like(x) > self.drop_prob).float()
                    xm = (x * mask).detach().requires_grad_(True)
                    logits = model(to_detector_input(xm))
                    loss = F.cross_entropy(logits, y_target)
                    model.zero_grad(set_to_none=True)
                    grad = torch.autograd.grad(loss, tap.features, retain_graph=False)[0]
                    acc = grad.detach() if acc is None else acc + grad.detach()
            imp = acc / self.n_ens
            maps.append(imp / imp.norm(p=2, dim=(1, 2, 3), keepdim=True).clamp_min(1e-12))
        return maps

    def _feature_loss(self, x_adv: torch.Tensor, importance: List[torch.Tensor]) -> torch.Tensor:
        total = 0.0
        for model, imp in zip(self.loss_fn.models, importance):
            if imp is None:
                continue
            layer = self.layers[getattr(model, "name")]
            tap = _FeatureTap(model, layer)
            with tap.attached():
                model(to_detector_input(x_adv))
                total = total + (imp * tap.features).sum()
        return total

    def __call__(self, x, y_target):
        importance = self._importance(x, y_target)
        delta = self._init_delta(x)
        momentum = torch.zeros_like(x)
        for _ in range(self.cfg.steps):
            # Minimise the aggregate importance-weighted activation: suppress the
            # features the detector relies on, whatever the head then does.
            loss = self._feature_loss(x + delta, importance)
            (g,) = torch.autograd.grad(loss, delta)
            g = -g
            g = g / g.abs().flatten(1).mean(1).view(-1, 1, 1, 1).clamp_min(1e-12)
            momentum = self.decay * momentum + g
            delta = linf_project(delta.detach() + self.alpha * momentum.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)


class NAA(FIA):
    """Neuron Attribution-based Attack.

    Attribution for neuron a is approximated by integrated gradients along the
    straight path from a baseline x0 (a mid-grey image, which for a steganalyzer
    contains no residual at all -- the natural "absence of evidence" reference)
    to the input:

        A(a) = (F(x)_a - F(x0)_a) * (1/N) sum_k dL/dF_a evaluated at
               x0 + (k/N)(x - x0)

    Positive attributions push the decision toward "stego"; they are penalised
    with weight gamma_p. Negative attributions are rewarded with gamma_n, which
    is what makes the perturbation actively construct cover-like evidence rather
    than merely erase stego evidence.
    """

    def __init__(self, loss_fn, cfg, layers=None):
        super().__init__(loss_fn, cfg, layers)
        self.n_steps_ig = int(cfg.extra.get("naa_ig_steps", 30))
        self.gamma_pos = float(cfg.extra.get("naa_gamma_pos", 1.0))
        self.gamma_neg = float(cfg.extra.get("naa_gamma_neg", 1.0))
        self.baseline = str(cfg.extra.get("naa_baseline", "grey"))

    def _baseline_image(self, x: torch.Tensor) -> torch.Tensor:
        if self.baseline == "zero":
            return torch.zeros_like(x)
        if self.baseline == "blur":
            k = torch.ones(x.shape[1], 1, 5, 5, device=x.device, dtype=x.dtype) / 25.0
            return F.conv2d(x, k, padding=2, groups=x.shape[1])
        return torch.full_like(x, 0.5)  # mid-grey: no high-frequency residual

    def _attribution(self, x: torch.Tensor, y_target: torch.Tensor) -> List[torch.Tensor]:
        x0 = self._baseline_image(x)
        attrs: List[torch.Tensor] = []
        for model in self.loss_fn.models:
            layer = self.layers.get(getattr(model, "name", ""), None)
            if layer is None:
                attrs.append(None)  # type: ignore[arg-type]
                continue
            tap = _FeatureTap(model, layer)
            with tap.attached():
                model(to_detector_input(x0.detach()))
                f0 = tap.features.detach().clone()
                model(to_detector_input(x.detach()))
                fx = tap.features.detach().clone()

                acc = torch.zeros_like(fx)
                for k in range(1, self.n_steps_ig + 1):
                    xk = (x0 + (k / self.n_steps_ig) * (x - x0)).detach().requires_grad_(True)
                    logits = model(to_detector_input(xk))
                    # Attribution toward the STEGO logit: what evidence is the
                    # detector accumulating for "hidden payload present".
                    score = logits[:, 1].sum()
                    model.zero_grad(set_to_none=True)
                    grad = torch.autograd.grad(score, tap.features, retain_graph=False)[0]
                    acc = acc + grad.detach()
                ig_grad = acc / self.n_steps_ig
            attrs.append((fx - f0) * ig_grad)
        return attrs

    def _weighted_feature_loss(self, x_adv, attributions) -> torch.Tensor:
        total = 0.0
        for model, attr in zip(self.loss_fn.models, attributions):
            if attr is None:
                continue
            layer = self.layers[getattr(model, "name")]
            tap = _FeatureTap(model, layer)
            with tap.attached():
                model(to_detector_input(x_adv))
                f = tap.features
                pos = (attr.clamp_min(0) * f).sum()
                neg = (attr.clamp_max(0) * f).sum()
                total = total + self.gamma_pos * pos - self.gamma_neg * neg
        return total

    def __call__(self, x, y_target):
        attributions = self._attribution(x, y_target)
        delta = self._init_delta(x)
        momentum = torch.zeros_like(x)
        for _ in range(self.cfg.steps):
            obj = self._weighted_feature_loss(x + delta, attributions)
            (g,) = torch.autograd.grad(obj, delta)
            g = -g  # minimise stego-supporting attribution
            g = g / g.abs().flatten(1).mean(1).view(-1, 1, 1, 1).clamp_min(1e-12)
            momentum = self.decay * momentum + g
            delta = linf_project(delta.detach() + self.alpha * momentum.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)
