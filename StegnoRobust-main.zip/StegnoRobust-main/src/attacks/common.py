"""Shared attack primitives: luminance projection and the eps <-> PSNR contract.

Reviewer 1, comment 3 -- "The manuscript states that perturbations remain at
PSNR >= 37 dB, but Table 3 reports 36.9 dB at epsilon = 8/255. Please make the
threshold statement numerically consistent with the table."

The fix is not a rounding convention, it is a definition. Three distinct
quantities were being conflated:

  1. `psnr_worst_case(eps)` -- the algebraic floor if EVERY pixel moves by the
     full budget: 20*log10(255/eps_255). For eps = 8/255 this is 30.06 dB.
  2. `psnr_empirical(x, x_adv)` -- what the run actually measured: 36.9 dB,
     because PGD does not saturate every pixel.
  3. The claim in the abstract -- "PSNR >= 37 dB" -- which was neither.

`format_psnr` enforces one rounding rule (1 decimal, round-half-even) for every
PSNR printed anywhere in the paper, and `check_psnr_claim` fails loudly if a
manuscript claim is inconsistent with the measured table. tools/check_claims.py
runs it over the .docx before submission.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

import torch

# ITU-R BT.601 luma. MUST match src/data/pair_dataset.py::_load_gray.
LUMA_WEIGHTS = (0.299, 0.587, 0.114)


def to_luma(x_rgb: torch.Tensor) -> torch.Tensor:
    """Differentiable RGB -> luminance. Gradients flow to the RGB perturbation.

    x_rgb: (N,3,H,W) in [0,1]. Returns (N,1,H,W).
    """
    r, g, b = LUMA_WEIGHTS
    w = torch.tensor([r, g, b], dtype=x_rgb.dtype, device=x_rgb.device).view(1, 3, 1, 1)
    return (x_rgb * w).sum(dim=1, keepdim=True)


def to_detector_input(x: torch.Tensor, scale_255: bool = True) -> torch.Tensor:
    """Project to what the steganalyzers consume: single-channel, 0..255 floats."""
    y = to_luma(x) if x.shape[1] == 3 else x
    return y * 255.0 if scale_255 else y


# --------------------------------------------------------------------------
# Perceptual budget bookkeeping
# --------------------------------------------------------------------------

MAX_PIXEL = 255.0


def eps_from_level(level: int) -> float:
    """Budget expressed as level/255 in [0,1] image units. Config uses integers
    so that 'eps = 8/255' in the paper and `attack.eps_level: 8` in YAML cannot
    drift apart."""
    return level / MAX_PIXEL


def psnr_worst_case(eps_level: float) -> float:
    """Algebraic PSNR floor if every pixel moves by the full L_inf budget."""
    if eps_level <= 0:
        return float("inf")
    return 20.0 * math.log10(MAX_PIXEL / eps_level)


def psnr_empirical(x: torch.Tensor, x_adv: torch.Tensor, data_range: float = 1.0) -> float:
    """Measured PSNR between two batches, averaged per image (not over the
    pooled MSE, which would let one flat image dominate)."""
    diff = (x_adv - x).flatten(1)
    mse = diff.pow(2).mean(dim=1).clamp_min(1e-12)
    psnr = 20.0 * torch.log10(torch.as_tensor(data_range, device=x.device)) - 10.0 * torch.log10(mse)
    return float(psnr.mean().item())


def format_psnr(value: float, decimals: int = 1) -> str:
    """Single rounding rule for every PSNR in the paper: round-half-even, applied
    to the DECIMAL representation of the value.

    `round()` and f-string formatting both operate on the binary float, so
    round(36.95, 1) returns 37.0 -- because 36.95 is stored as 36.9500000000000028.
    That is a defensible answer, but it is not the rule a reader applies when
    checking a table by eye, and the mismatch is precisely the class of error
    Reviewer 1 flagged in comment 3. Decimal makes the printed value a function
    of the printed input, which is what a reader can verify.
    """
    from decimal import ROUND_HALF_EVEN, Decimal

    q = Decimal(1).scaleb(-decimals)
    return str(Decimal(repr(float(value))).quantize(q, rounding=ROUND_HALF_EVEN))


@dataclass
class PsnrClaim:
    """A textual claim of the form 'PSNR >= threshold dB' to be validated."""

    threshold_db: float
    comparator: str = ">="  # ">=" or ">"
    scope: str = "all budgets"


def check_psnr_claim(
    claim: PsnrClaim, measured: Sequence[float], decimals: int = 1
) -> Tuple[bool, str]:
    """Validate a manuscript claim against measured PSNRs, at printed precision.

    Comparing at printed precision is deliberate: the reader can only check the
    claim against the printed table, so the claim must hold for the numbers as
    printed, not for their full-precision originals.
    """
    printed = [round(float(v), decimals) for v in measured]
    worst = min(printed) if printed else float("nan")
    ok = worst >= claim.threshold_db if claim.comparator == ">=" else worst > claim.threshold_db
    if ok:
        return True, f"claim holds: min printed PSNR = {format_psnr(worst, decimals)} dB"
    return False, (
        f"claim 'PSNR {claim.comparator} {claim.threshold_db} dB' is contradicted by the table: "
        f"min printed PSNR = {format_psnr(worst, decimals)} dB. "
        f"Either restate the claim as 'PSNR {claim.comparator} {math.floor(worst)} dB' "
        f"or report the value to the precision that makes it true."
    )


def linf_project(delta: torch.Tensor, eps: float) -> torch.Tensor:
    return torch.clamp(delta, -eps, eps)


def clamp_to_image(x: torch.Tensor, lo: float = 0.0, hi: float = 1.0) -> torch.Tensor:
    return torch.clamp(x, lo, hi)


def quantize_to_uint8(x: torch.Tensor) -> torch.Tensor:
    """Round to the 8-bit grid.

    An adversarial image that only exists in float32 is not a threat model: the
    evader must write a PNG. Every attack in this repo quantizes before the
    final evaluation, and `scripts/run_attack.py` reports both pre- and
    post-quantization AUC so the cost of quantization is visible.
    """
    return torch.round(x * 255.0) / 255.0
