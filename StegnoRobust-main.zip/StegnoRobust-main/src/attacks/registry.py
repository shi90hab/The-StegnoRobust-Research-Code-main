from __future__ import annotations

from typing import Any, Dict, Sequence

import torch.nn as nn

from .base import Attack, AttackConfig, CommitteeLoss
from .feature_level import FIA, NAA
from .gradient import DIFGSM, FGSM, MIFGSM, NIFGSM, PGD, SINIFGSM, TIFGSM, VMIFGSM

_ATTACKS = {
    "fgsm": FGSM,
    "pgd": PGD,
    "mifgsm": MIFGSM,
    "nifgsm": NIFGSM,
    "difgsm": DIFGSM,
    "tifgsm": TIFGSM,
    "vmifgsm": VMIFGSM,
    "sinifgsm": SINIFGSM,
    "fia": FIA,
    "naa": NAA,
}

ATTACK_CITATIONS = {
    "fgsm": "Goodfellow et al., 2015 [14]",
    "pgd": "Madry et al., 2018 [15] -- the attack used in the submitted manuscript",
    "mifgsm": "Dong et al., CVPR 2018",
    "nifgsm": "Lin et al., ICLR 2020",
    "difgsm": "Xie et al., CVPR 2019",
    "tifgsm": "Dong et al., CVPR 2019",
    "vmifgsm": "Wang & He, CVPR 2021",
    "sinifgsm": "Lin et al., ICLR 2020",
    "fia": "Wang et al., ICCV 2021",
    "naa": "Zhang et al., CVPR 2022 -- the neuron-attribution family named by Reviewer 2",
}


def build_attack(cfg: AttackConfig, models: Sequence[nn.Module], **kwargs: Any) -> Attack:
    key = cfg.name.lower()
    if key not in _ATTACKS:
        raise KeyError(f"unknown attack '{cfg.name}'; available: {sorted(_ATTACKS)}")
    loss = CommitteeLoss(models, weighting=cfg.committee_weighting)
    return _ATTACKS[key](loss, cfg, **kwargs)
