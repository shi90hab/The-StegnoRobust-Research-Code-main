"""Standard and transferable gradient attacks.

Reviewer 2, comment 2 -- "the absence of head-to-head quantitative comparison
with recent post-2024 adversarial steganography or transferable attack methods
... nor against standard adversarial baselines."

The manuscript attacks with plain PGD only, so any statement about
transferability is a statement about the *weakest* available attack. The
transfer-attack literature exists precisely because plain PGD overfits the
surrogate; concluding "evasion does not transfer" without running MI-FGSM,
DI-FGSM, TI-FGSM or a feature-level attack is not a finding about steganalysis,
it is a finding about PGD. Every attack below shares the budget, the step count
and the committee loss, so the comparison is matched.

  FGSM      Goodfellow et al. [14]        one-step baseline
  PGD       Madry et al. [15]             the manuscript's attack
  MI-FGSM   momentum                      the standard transfer baseline
  NI-FGSM   Nesterov look-ahead
  DI-FGSM   input diversity               random resize+pad each step
  TI-FGSM   translation invariance        Gaussian-smoothed gradient
  VMI-FGSM  variance tuning               current strong transfer baseline
  SI-NI     scale invariance              ensemble over {1,1/2,1/4,1/8}
"""
from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn.functional as F

from .base import Attack, AttackConfig, CommitteeLoss
from .common import clamp_to_image, linf_project


class FGSM(Attack):
    def __call__(self, x, y_target):
        d = torch.zeros_like(x, requires_grad=True)
        g = self._grad(x + d, y_target)
        return self._finalise(x, self.eps * g.sign())


class PGD(Attack):
    """Manuscript Algorithm 1. Kept bit-identical in behaviour for continuity."""

    def __call__(self, x, y_target):
        delta = self._init_delta(x)
        for _ in range(self.cfg.steps):
            g = self._grad(x + delta, y_target)
            delta = linf_project(delta.detach() + self.alpha * g.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)


class MIFGSM(Attack):
    def __init__(self, loss_fn, cfg):
        super().__init__(loss_fn, cfg)
        self.decay = float(cfg.extra.get("decay", 1.0))

    def __call__(self, x, y_target):
        delta = self._init_delta(x)
        momentum = torch.zeros_like(x)
        for _ in range(self.cfg.steps):
            g = self._grad(x + delta, y_target)
            g = g / g.abs().flatten(1).mean(1).view(-1, 1, 1, 1).clamp_min(1e-12)
            momentum = self.decay * momentum + g
            delta = linf_project(delta.detach() + self.alpha * momentum.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)


class NIFGSM(MIFGSM):
    """Nesterov: take the gradient at the look-ahead point."""

    def __call__(self, x, y_target):
        delta = self._init_delta(x)
        momentum = torch.zeros_like(x)
        for _ in range(self.cfg.steps):
            nes = (x + delta + self.alpha * self.decay * momentum).detach().requires_grad_(True)
            g = self._grad(nes, y_target)
            g = g / g.abs().flatten(1).mean(1).view(-1, 1, 1, 1).clamp_min(1e-12)
            momentum = self.decay * momentum + g
            delta = linf_project(delta.detach() + self.alpha * momentum.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)


def _input_diversity(x: torch.Tensor, prob: float, resize_rate: float) -> torch.Tensor:
    if torch.rand(1).item() >= prob:
        return x
    h = x.shape[-1]
    hi = int(h * resize_rate)
    new = int(torch.randint(h, hi, (1,)).item())
    xr = F.interpolate(x, size=(new, new), mode="nearest")
    pad = hi - new
    pl = int(torch.randint(0, pad + 1, (1,)).item())
    pt = int(torch.randint(0, pad + 1, (1,)).item())
    xp = F.pad(xr, (pl, pad - pl, pt, pad - pt))
    return F.interpolate(xp, size=(h, h), mode="nearest")


class DIFGSM(MIFGSM):
    """Input-diversity + momentum.

    Caveat recorded here because it matters for steganalysis specifically:
    resizing resamples pixels and therefore destroys the embedding residual the
    detector reads. DI is applied ONLY inside the gradient computation, never to
    the emitted image, so the delivered stego is still a valid 8-bit PNG whose
    payload is intact. `verify_payload` in scripts/run_attack.py checks recovery.
    """

    def __init__(self, loss_fn, cfg):
        super().__init__(loss_fn, cfg)
        self.prob = float(cfg.extra.get("di_prob", 0.5))
        self.resize_rate = float(cfg.extra.get("di_resize_rate", 1.1))

    def _grad(self, x_adv, y_target):
        loss = self.loss_fn(_input_diversity(x_adv, self.prob, self.resize_rate), y_target)
        (g,) = torch.autograd.grad(loss, x_adv)
        return -g if self.cfg.targeted else g


def _gaussian_kernel(klen: int, sigma: float, channels: int, device, dtype) -> torch.Tensor:
    ax = torch.arange(klen, dtype=dtype, device=device) - (klen - 1) / 2.0
    g = torch.exp(-(ax**2) / (2 * sigma**2))
    k2 = torch.outer(g, g)
    k2 = k2 / k2.sum()
    return k2.expand(channels, 1, klen, klen).contiguous()


class TIFGSM(MIFGSM):
    """Translation-invariant: convolve the gradient with a Gaussian kernel."""

    def __init__(self, loss_fn, cfg):
        super().__init__(loss_fn, cfg)
        self.klen = int(cfg.extra.get("ti_kernel", 7))
        self.sigma = float(cfg.extra.get("ti_sigma", 3.0))

    def _grad(self, x_adv, y_target):
        g = super()._grad(x_adv, y_target)
        k = _gaussian_kernel(self.klen, self.sigma, g.shape[1], g.device, g.dtype)
        return F.conv2d(g, k, padding=self.klen // 2, groups=g.shape[1])


class VMIFGSM(MIFGSM):
    """Variance-tuned MI-FGSM (Wang & He). Strong, widely used transfer baseline."""

    def __init__(self, loss_fn, cfg):
        super().__init__(loss_fn, cfg)
        self.n_sample = int(cfg.extra.get("vmi_samples", 5))
        self.beta = float(cfg.extra.get("vmi_beta", 1.5))

    def __call__(self, x, y_target):
        delta = self._init_delta(x)
        momentum = torch.zeros_like(x)
        variance = torch.zeros_like(x)
        radius = self.beta * self.eps
        for _ in range(self.cfg.steps):
            g = self._grad(x + delta, y_target)
            g_hat = g + variance
            g_hat = g_hat / g_hat.abs().flatten(1).mean(1).view(-1, 1, 1, 1).clamp_min(1e-12)
            momentum = self.decay * momentum + g_hat

            acc = torch.zeros_like(x)
            for _ in range(self.n_sample):
                noise = torch.empty_like(x).uniform_(-radius, radius)
                xn = (x + delta + noise).detach().requires_grad_(True)
                acc = acc + self._grad(xn, y_target)
            variance = acc / self.n_sample - g

            delta = linf_project(delta.detach() + self.alpha * momentum.sign(), self.eps)
            delta = (clamp_to_image(x + delta) - x).requires_grad_(True)
        return self._finalise(x, delta)


class SINIFGSM(NIFGSM):
    """Scale-invariant Nesterov: average the gradient over {1, 1/2, 1/4, 1/8}.

    Scaling a luminance image also scales the embedding residual, so the scale
    ensemble is meaningful here rather than a purely photometric trick.
    """

    def __init__(self, loss_fn, cfg):
        super().__init__(loss_fn, cfg)
        self.m = int(cfg.extra.get("si_copies", 5))

    def _grad(self, x_adv, y_target):
        total = torch.zeros_like(x_adv)
        for i in range(self.m):
            xs = (x_adv / (2**i)).clamp(0, 1)
            loss = self.loss_fn(xs, y_target)
            (g,) = torch.autograd.grad(loss, x_adv, retain_graph=False)
            total = total + g
        g = total / self.m
        return -g if self.cfg.targeted else g
