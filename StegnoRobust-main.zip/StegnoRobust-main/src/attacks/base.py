"""Attack interface and the committee loss.

Every attack in this repo implements `Attack.__call__(x, y_target) -> x_adv` and
declares its hyperparameters in a dataclass so that Hydra can construct it and
the resolved values land in the run's config record (Reviewer 2, comment 6:
"attack loss, epsilon-to-PSNR conversion, number of PGD steps ... missing").
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common import clamp_to_image, linf_project, to_detector_input


class CommitteeLoss(nn.Module):
    """Mean cross-entropy of the committee toward the target ("cover") label.

    `weighting`:
      * "mean"    -- Eq. 1 of the manuscript, unchanged.
      * "minmax"  -- optimise the worst-case member (max loss), which is the
                     stronger and more honest ensemble attack; a mean can be
                     driven down by collapsing one member while another is
                     untouched.
      * "logit"   -- ensemble the logits rather than the losses (Liu et al.
                     ensemble-in-logits), usually the most transferable.
    """

    def __init__(self, models: Sequence[nn.Module], weighting: str = "mean"):
        super().__init__()
        self.models = nn.ModuleList(models)
        if weighting not in {"mean", "minmax", "logit"}:
            raise ValueError(f"unknown weighting '{weighting}'")
        self.weighting = weighting

    def logits(self, x: torch.Tensor) -> List[torch.Tensor]:
        z = to_detector_input(x)
        return [m(z) for m in self.models]

    def forward(self, x: torch.Tensor, y_target: torch.Tensor) -> torch.Tensor:
        zs = self.logits(x)
        if self.weighting == "logit":
            return F.cross_entropy(torch.stack(zs, 0).mean(0), y_target)
        losses = torch.stack([F.cross_entropy(z, y_target) for z in zs])
        return losses.max() if self.weighting == "minmax" else losses.mean()


@dataclass
class AttackConfig:
    name: str = "pgd"
    eps_level: int = 8          # L_inf budget in 0-255 units; eps = eps_level/255
    alpha_level: float = 1.0    # step size in 0-255 units
    steps: int = 40
    random_start: bool = True
    targeted: bool = True       # push toward the "cover" label
    committee_weighting: str = "mean"
    quantize: bool = True
    extra: Dict[str, float] = field(default_factory=dict)


class Attack(ABC):
    def __init__(self, loss_fn: CommitteeLoss, cfg: AttackConfig):
        self.loss_fn = loss_fn
        self.cfg = cfg
        self.eps = cfg.eps_level / 255.0
        self.alpha = cfg.alpha_level / 255.0

    @property
    def name(self) -> str:
        return self.cfg.name

    @abstractmethod
    def __call__(self, x: torch.Tensor, y_target: torch.Tensor) -> torch.Tensor:
        ...

    def _init_delta(self, x: torch.Tensor) -> torch.Tensor:
        if self.cfg.random_start and self.eps > 0:
            d = torch.empty_like(x).uniform_(-self.eps, self.eps)
            return (clamp_to_image(x + d) - x).detach().requires_grad_(True)
        return torch.zeros_like(x, requires_grad=True)

    def _grad(self, x_adv: torch.Tensor, y_target: torch.Tensor) -> torch.Tensor:
        loss = self.loss_fn(x_adv, y_target)
        # Targeted: descend the loss toward the target class. Untargeted: ascend
        # away from the true class. The sign is set once, here.
        (g,) = torch.autograd.grad(loss, x_adv, retain_graph=False, create_graph=False)
        return -g if self.cfg.targeted else g

    def _finalise(self, x: torch.Tensor, delta: torch.Tensor) -> torch.Tensor:
        from .common import quantize_to_uint8

        x_adv = clamp_to_image(x + linf_project(delta.detach(), self.eps))
        return quantize_to_uint8(x_adv) if self.cfg.quantize else x_adv
