"""Transferability gap, computed only where it is defined.

Reviewer 1, comment 5 and Reviewer 2, comment 3 make the same structural point:
the submitted gap

    Gap(eps) = mean drop on the attacked committee - drop on the held-out detector

is arithmetically correct but semantically empty when the held-out detector
starts at AUC 0.498, because a detector that never detected anything cannot
"resist" an attack -- there is no detection to remove. The submitted Table 3
shows exactly this: SRNet moves 0.498 -> 0.501, a drop of -0.003, and the entire
reported gap of 0.276 is the committee's own collapse.

`transferability_gap` therefore refuses to return a number unless *both* the
attacked committee and the held-out detector passed the convergence gate, and
returns a `TransferResult` carrying the reason when it cannot. It also reports
the *relative* drop and a normalised gap, since an absolute drop from 1.000 and
one from 0.760 are not comparable quantities.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

from .metrics import ConvergenceGate, DetectionReport, delong_auc_test


@dataclass
class TransferResult:
    epsilon: float
    committee_clean: Optional[float]
    committee_attacked: Optional[float]
    committee_drop: Optional[float]
    heldout_clean: Optional[float]
    heldout_attacked: Optional[float]
    heldout_drop: Optional[float]
    gap: Optional[float]
    normalised_gap: Optional[float]
    defined: bool
    reason: str
    heldout_test: Optional[Dict[str, float]] = None

    def as_row(self) -> Dict[str, object]:
        d = self.__dict__.copy()
        d.pop("heldout_test", None)
        if self.heldout_test:
            d["heldout_p_value"] = self.heldout_test.get("p")
        return d


def _drop(clean: float, attacked: float) -> float:
    return clean - attacked


def transferability_gap(
    epsilon: float,
    committee_clean: Sequence[DetectionReport],
    committee_attacked: Sequence[DetectionReport],
    heldout_clean: DetectionReport,
    heldout_attacked: DetectionReport,
    gate: ConvergenceGate,
    heldout_labels: Optional[np.ndarray] = None,
    heldout_scores_clean: Optional[np.ndarray] = None,
    heldout_scores_attacked: Optional[np.ndarray] = None,
) -> TransferResult:
    blockers: List[str] = []

    for r in committee_clean:
        ok, why = gate.admits(r)
        if not ok:
            blockers.append(f"committee member {r.detector} not converged ({why})")
    ok_h, why_h = gate.admits(heldout_clean)
    if not ok_h:
        blockers.append(
            f"held-out {heldout_clean.detector} not converged ({why_h}); a chance-level "
            "held-out detector cannot evidence resistance to a transferred attack"
        )

    c_clean = float(np.mean([r.auc for r in committee_clean]))
    c_att = float(np.mean([r.auc for r in committee_attacked]))
    h_clean, h_att = heldout_clean.auc, heldout_attacked.auc

    test = None
    if (
        heldout_labels is not None
        and heldout_scores_clean is not None
        and heldout_scores_attacked is not None
    ):
        # Paired DeLong on the held-out detector: is its AUC change significant
        # at all? In the submitted run it is not, which is the honest statement.
        test = delong_auc_test(heldout_labels, heldout_scores_clean, heldout_scores_attacked)

    if blockers:
        return TransferResult(
            epsilon=epsilon,
            committee_clean=c_clean,
            committee_attacked=c_att,
            committee_drop=_drop(c_clean, c_att),
            heldout_clean=h_clean,
            heldout_attacked=h_att,
            heldout_drop=_drop(h_clean, h_att),
            gap=None,
            normalised_gap=None,
            defined=False,
            reason="; ".join(blockers),
            heldout_test=test,
        )

    c_drop, h_drop = _drop(c_clean, c_att), _drop(h_clean, h_att)
    denom = max(c_clean - 0.5, 1e-9)
    return TransferResult(
        epsilon=epsilon,
        committee_clean=c_clean,
        committee_attacked=c_att,
        committee_drop=c_drop,
        heldout_clean=h_clean,
        heldout_attacked=h_att,
        heldout_drop=h_drop,
        gap=c_drop - h_drop,
        # Normalised by the headroom above chance: a drop of 0.25 from AUC 1.00
        # and one from AUC 0.60 are different events.
        normalised_gap=(c_drop - h_drop) / denom,
        defined=True,
        reason="both attacked committee and held-out detector passed the convergence gate",
        heldout_test=test,
    )


def attack_success_rate(labels: np.ndarray, scores: np.ndarray, threshold: float = 0.0) -> float:
    """Fraction of stego images pushed below the decision threshold.

    Reported alongside AUC because AUC is a ranking statistic: a detector can
    lose AUC without any individual image crossing the operating threshold, and
    an examiner cares about the threshold.
    """
    pos = scores[np.asarray(labels) == 1]
    return float((pos <= threshold).mean()) if len(pos) else float("nan")
