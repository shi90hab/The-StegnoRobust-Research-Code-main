"""Vector figures with journal-consistent typography.

Set once, here. Never configure matplotlib inside a figure function -- that is
how a paper ends up with five different font sizes across its figures.
All output is PDF (vector). IJIES accepts vector figures; a rasterised figure at
column width is the most common cosmetic reason for a revision request.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

COLUMN_WIDTH_IN = 3.5     # single column
TEXT_WIDTH_IN = 7.16      # full width, two-column layout


def configure(serif: bool = True, base_size: int = 8) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "serif" if serif else "sans-serif",
            "font.serif": ["Times New Roman", "DejaVu Serif", "STIXGeneral"],
            "mathtext.fontset": "stix",
            "font.size": base_size,
            "axes.labelsize": base_size,
            "axes.titlesize": base_size,
            "legend.fontsize": base_size - 1,
            "xtick.labelsize": base_size - 1,
            "ytick.labelsize": base_size - 1,
            "axes.linewidth": 0.6,
            "grid.linewidth": 0.4,
            "lines.linewidth": 1.1,
            "lines.markersize": 3.5,
            "figure.dpi": 300,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.02,
            "pdf.fonttype": 42,   # embed TrueType, not Type 3 -- required by many publishers
            "ps.fonttype": 42,
            "axes.grid": True,
            "grid.alpha": 0.3,
        }
    )


def _save(fig, out: str | Path) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out.with_suffix(".pdf"))
    fig.savefig(out.with_suffix(".svg"))
    import matplotlib.pyplot as plt

    plt.close(fig)
    return out.with_suffix(".pdf")


def plot_convergence(histories: Dict[str, List[Dict[str, float]]], out: str | Path):
    """Loss (left axis) and validation AUC (right axis) per detector.

    Replaces submitted Figure 7. The chance line and the convergence gate are
    drawn explicitly so the reader can see which detectors were admitted.
    """
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, len(histories), figsize=(TEXT_WIDTH_IN, 2.0), sharex=False)
    axes = np.atleast_1d(axes)
    for ax, (name, hist) in zip(axes, histories.items()):
        ep = [h["epoch"] for h in hist]
        ax.plot(ep, [h["train_loss"] for h in hist], color="0.35", label="train loss")
        ax.set_xlabel("epoch")
        ax.set_ylabel("loss")
        ax2 = ax.twinx()
        ax2.plot(ep, [h["val_auc"] for h in hist], color="C0", label="val AUC")
        ax2.axhline(0.5, ls=":", lw=0.7, color="0.6")
        ax2.axhline(0.75, ls="--", lw=0.7, color="C3")
        ax2.set_ylim(0.4, 1.02)
        ax2.set_ylabel("validation AUC")
        ax.set_title(name)
        ax2.grid(False)
    fig.tight_layout()
    return _save(fig, out)


def plot_auc_vs_budget(
    budgets: Sequence[float],
    curves: Dict[str, Sequence[float]],
    cis: Optional[Dict[str, Sequence[tuple]]] = None,
    out: str | Path = "outputs/fig_auc_vs_budget",
    heldout: Optional[str] = None,
):
    """Replaces submitted Figure 8, with CI bands (comment: uncertainty)."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(COLUMN_WIDTH_IN, 2.4))
    for i, (name, ys) in enumerate(curves.items()):
        style = "--" if name == heldout else "-"
        ax.plot(budgets, ys, style, marker="o", label=name + (" (held-out)" if name == heldout else ""))
        if cis and name in cis:
            lo = [c[0] for c in cis[name]]
            hi = [c[1] for c in cis[name]]
            ax.fill_between(budgets, lo, hi, alpha=0.15, linewidth=0)
    ax.axhline(0.5, ls=":", lw=0.7, color="0.5")
    ax.set_xlabel(r"perturbation budget $\varepsilon$ (/255)")
    ax.set_ylabel("ROC-AUC")
    ax.set_ylim(-0.02, 1.02)
    ax.legend(frameon=False)
    fig.tight_layout()
    return _save(fig, out)


def plot_pareto(psnrs: Sequence[float], aucs: Dict[str, Sequence[float]], out: str | Path):
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(COLUMN_WIDTH_IN, 2.4))
    for name, ys in aucs.items():
        ax.plot(psnrs, ys, marker="s", label=name)
    ax.invert_xaxis()
    ax.set_xlabel("perturbation PSNR (dB)")
    ax.set_ylabel("ROC-AUC")
    ax.legend(frameon=False)
    fig.tight_layout()
    return _save(fig, out)


def plot_transfer_gap(
    budgets: Sequence[float],
    gaps: Sequence[Optional[float]],
    defined: Sequence[bool],
    out: str | Path,
):
    """Replaces submitted Figure 11.

    Undefined points -- those where the held-out detector did not converge -- are
    drawn as open markers on a shaded band rather than as a solid line, so the
    figure cannot be read as evidence where none exists.
    """
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(COLUMN_WIDTH_IN, 2.4))
    b = np.asarray(budgets, float)
    g = np.array([np.nan if v is None else v for v in gaps], float)
    d = np.asarray(defined, bool)
    if d.any():
        ax.plot(b[d], g[d], marker="o", color="C0", label="gap (defined)")
    if (~d).any():
        # Undefined points have no gap value at all; draw them on the axis floor
        # with an open marker so the figure shows that the budget was evaluated
        # but the quantity is not defined there.
        finite = g[np.isfinite(g)]
        floor = float(np.nanmin(finite)) if finite.size else 0.0
        ax.plot(b[~d], np.full((~d).sum(), floor), marker="o", mfc="none", ls="none",
                color="C3", label="undefined: held-out detector at chance")
        if finite.size:
            ax.axhspan(floor - 0.02, float(np.nanmax(finite)) + 0.02, color="C3", alpha=0.06, lw=0)
    ax.set_xlabel(r"perturbation budget $\varepsilon$ (/255)")
    ax.set_ylabel("transferability gap")
    ax.legend(frameon=False)
    fig.tight_layout()
    return _save(fig, out)


def plot_attack_comparison(
    attack_names: Sequence[str], heldout_auc: Sequence[float], errs: Sequence[float], out: str | Path
):
    """New figure: transfer strength by attack method (Reviewer 2, comment 2)."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(TEXT_WIDTH_IN / 2, 2.4))
    y = np.arange(len(attack_names))
    ax.barh(y, heldout_auc, xerr=errs, color="0.6", edgecolor="black", linewidth=0.5, capsize=2)
    ax.set_yticks(y, attack_names)
    ax.axvline(0.5, ls=":", lw=0.7, color="0.4")
    ax.set_xlabel("held-out detector ROC-AUC after transfer")
    fig.tight_layout()
    return _save(fig, out)
