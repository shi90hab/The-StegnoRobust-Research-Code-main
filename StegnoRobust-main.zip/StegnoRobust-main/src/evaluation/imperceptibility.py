"""PSNR / SSIM / LPIPS with one consistent definition each.

The submitted Table 1 reports PSNR 38.50 for SteganoGAN-dense, and the abstract
claims "PSNR >= 37 dB" for the *perturbation*, while Table 3 shows 36.9 dB. Two
different quantities carry the same name in the paper. Here they are separated
by function name and both are recorded per run:

    cover_stego_quality(cover, stego)      -- Table 1
    perturbation_quality(stego, evaded)    -- Table 3

Averaging convention: PSNR is averaged per image and then over images, never
computed from the pooled MSE. The two differ by up to ~1 dB on this data, which
is larger than the discrepancy the reviewer flagged.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn.functional as F


def psnr(a: torch.Tensor, b: torch.Tensor, data_range: float = 1.0) -> torch.Tensor:
    mse = (a - b).flatten(1).pow(2).mean(dim=1).clamp_min(1e-12)
    return 20 * torch.log10(torch.tensor(data_range, device=a.device)) - 10 * torch.log10(mse)


def _gaussian_window(size: int, sigma: float, channels: int, device, dtype):
    coords = torch.arange(size, dtype=dtype, device=device) - size // 2
    g = torch.exp(-(coords**2) / (2 * sigma**2))
    g = (g / g.sum()).unsqueeze(0)
    w = (g.t() @ g).expand(channels, 1, size, size).contiguous()
    return w


def ssim(a: torch.Tensor, b: torch.Tensor, data_range: float = 1.0, size: int = 11, sigma: float = 1.5):
    c = a.shape[1]
    w = _gaussian_window(size, sigma, c, a.device, a.dtype)
    pad = size // 2
    mu1 = F.conv2d(a, w, padding=pad, groups=c)
    mu2 = F.conv2d(b, w, padding=pad, groups=c)
    mu1s, mu2s, mu12 = mu1 * mu1, mu2 * mu2, mu1 * mu2
    s1 = F.conv2d(a * a, w, padding=pad, groups=c) - mu1s
    s2 = F.conv2d(b * b, w, padding=pad, groups=c) - mu2s
    s12 = F.conv2d(a * b, w, padding=pad, groups=c) - mu12
    C1, C2 = (0.01 * data_range) ** 2, (0.03 * data_range) ** 2
    m = ((2 * mu12 + C1) * (2 * s12 + C2)) / ((mu1s + mu2s + C1) * (s1 + s2 + C2))
    return m.flatten(1).mean(dim=1)


class LPIPS:
    """Lazy wrapper around the `lpips` package (AlexNet backbone, the standard).

    Raises with an actionable message instead of substituting a different
    perceptual metric, so a missing dependency cannot silently change Table 1.
    """

    def __init__(self, net: str = "alex", device: str = "cuda"):
        try:
            import lpips as _lpips  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "pip install lpips==0.1.4 -- required to reproduce the LPIPS column of Table 1"
            ) from exc
        self.model = _lpips.LPIPS(net=net).to(device).eval()
        self.device = device

    @torch.no_grad()
    def __call__(self, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        # lpips expects [-1,1] and 3 channels
        a3 = a.repeat(1, 3, 1, 1) if a.shape[1] == 1 else a
        b3 = b.repeat(1, 3, 1, 1) if b.shape[1] == 1 else b
        return self.model(a3 * 2 - 1, b3 * 2 - 1).flatten()


@dataclass
class QualityReport:
    label: str
    psnr_mean: float
    psnr_std: float
    psnr_min: float
    ssim_mean: float
    ssim_std: float
    lpips_mean: Optional[float]
    lpips_std: Optional[float]
    n: int

    def as_row(self) -> Dict[str, object]:
        return asdict(self)


def _report(label: str, a: torch.Tensor, b: torch.Tensor, lpips_fn: Optional[LPIPS]) -> QualityReport:
    p = psnr(a, b).cpu().numpy()
    s = ssim(a, b).cpu().numpy()
    lp = lpips_fn(a, b).cpu().numpy() if lpips_fn is not None else None
    return QualityReport(
        label=label,
        psnr_mean=float(p.mean()), psnr_std=float(p.std(ddof=1)) if len(p) > 1 else 0.0,
        # psnr_min is reported because the ">= X dB" claim is a claim about the
        # WORST image, not the average. The submitted abstract used the mean.
        psnr_min=float(p.min()),
        ssim_mean=float(s.mean()), ssim_std=float(s.std(ddof=1)) if len(s) > 1 else 0.0,
        lpips_mean=float(lp.mean()) if lp is not None else None,
        lpips_std=float(lp.std(ddof=1)) if lp is not None and len(lp) > 1 else None,
        n=int(a.shape[0]),
    )


def cover_stego_quality(cover, stego, lpips_fn=None) -> QualityReport:
    """Table 1: how imperceptible is the embedding."""
    return _report("cover_vs_stego", cover, stego, lpips_fn)


def perturbation_quality(stego, evaded, lpips_fn=None) -> QualityReport:
    """Table 3: how imperceptible is the evasion, measured w.r.t. the STEGO
    image (not the cover). Mixing the two references is what produced the
    inconsistent PSNR claim the reviewer flagged."""
    return _report("stego_vs_evaded", stego, evaded, lpips_fn)


def capacity_bpp(message_bits: int, h: int, w: int) -> float:
    return message_bits / (h * w)
