"""Multi-seed aggregation, paired significance tests, multiple-comparison control.

Reviewer 2, comment 8 -- "no statistical uncertainty ... A credible evaluation
should include multiple datasets, multiple payloads, repeated random splits,
confidence intervals".
Reviewer 2, comment 7 -- "Several numerical claims are overinterpreted."

`claim_supported` is the operational answer to comment 7: it takes a proposed
claim (method A beats method B) and returns False when the margin is smaller
than the seed-to-seed standard deviation, so that a claim cannot enter the
manuscript without passing the same test a reviewer would apply.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class SeedAggregate:
    name: str
    values: List[float]
    mean: float
    std: float
    ci_lo: float
    ci_hi: float
    n: int

    def formatted(self, decimals: int = 3) -> str:
        return f"{self.mean:.{decimals}f} ± {self.std:.{decimals}f}"


def aggregate_seeds(name: str, values: Sequence[float], alpha: float = 0.05) -> SeedAggregate:
    from scipy import stats

    v = np.asarray([x for x in values if np.isfinite(x)], dtype=float)
    n = len(v)
    if n == 0:
        return SeedAggregate(name, [], float("nan"), float("nan"), float("nan"), float("nan"), 0)
    mean = float(v.mean())
    std = float(v.std(ddof=1)) if n > 1 else 0.0
    if n > 1:
        # t interval, not normal: with 5 seeds the normal interval is ~20% too narrow.
        h = stats.t.ppf(1 - alpha / 2, n - 1) * std / np.sqrt(n)
    else:
        h = float("nan")
    return SeedAggregate(name, v.tolist(), mean, std, mean - h, mean + h, n)


def min_achievable_p_wilcoxon(n: int) -> float:
    """Smallest two-sided p the signed-rank test can produce with n pairs.

    This is 2^-(n-1), and it is the reason a five-seed study can never report a
    significant Wilcoxon result at alpha = 0.05: the floor is 0.0625. Anyone
    running five seeds and a rank test is guaranteed a null finding regardless of
    effect size. `paired_test` detects this and switches test rather than
    reporting a foregone conclusion.
    """
    return 2.0 ** (-(n - 1)) if n >= 1 else 1.0


def recommend_n_seeds(alpha: float = 0.05, test: str = "wilcoxon") -> int:
    if test != "wilcoxon":
        return 5
    n = 2
    while min_achievable_p_wilcoxon(n) > alpha:
        n += 1
    return n


@dataclass
class PairedTest:
    a: str
    b: str
    mean_diff: float
    statistic: float
    p_value: float
    p_adjusted: Optional[float]
    effect_size: float
    effect_name: str
    test: str
    n: int
    significant: bool
    note: str = ""


def paired_test(
    name_a: str,
    values_a: Sequence[float],
    name_b: str,
    values_b: Sequence[float],
    test: str = "auto",
    alpha: float = 0.05,
) -> PairedTest:
    """Paired comparison across seeds.

    `test="auto"` chooses Wilcoxon when n < 8, because normality cannot be
    assessed with five seeds and the t-test's assumption is then an act of faith.
    """
    from scipy import stats

    a = np.asarray(values_a, dtype=float)
    b = np.asarray(values_b, dtype=float)
    if len(a) != len(b):
        raise ValueError(f"paired test needs matched seeds: {len(a)} vs {len(b)}")
    n = len(a)
    d = a - b
    chosen = ("wilcoxon" if n < 8 else "ttest") if test == "auto" else test

    note = ""
    if chosen == "wilcoxon" and min_achievable_p_wilcoxon(n) > alpha:
        need = recommend_n_seeds(alpha, "wilcoxon")
        note = (
            f"Wilcoxon cannot reach p < {alpha} with n = {n} pairs (floor "
            f"{min_achievable_p_wilcoxon(n):.4f}); fell back to the paired t-test. "
            f"Run at least {need} seeds to use the rank test."
        )
        chosen = "ttest"

    if np.allclose(d, 0):
        stat, p = 0.0, 1.0
    elif chosen == "wilcoxon":
        stat, p = stats.wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
    else:
        stat, p = stats.ttest_rel(a, b)

    sd = d.std(ddof=1) if n > 1 else 0.0
    dz = float(d.mean() / sd) if sd > 0 else float("inf") if d.mean() != 0 else 0.0
    return PairedTest(
        a=name_a, b=name_b, mean_diff=float(d.mean()), statistic=float(stat), p_value=float(p),
        p_adjusted=None, effect_size=dz, effect_name="Cohen's d_z", test=chosen, n=n,
        significant=bool(p < alpha), note=note,
    )


def holm_correct(tests: List[PairedTest], alpha: float = 0.05) -> List[PairedTest]:
    """Holm-Bonferroni. Required whenever the proposed method is compared against
    several baselines in one table; without it the family-wise error rate of a
    six-baseline table is ~26%, not 5%."""
    order = np.argsort([t.p_value for t in tests])
    m = len(tests)
    prev = 0.0
    for rank, idx in enumerate(order):
        adj = min(1.0, max(prev, (m - rank) * tests[idx].p_value))
        prev = adj
        tests[idx].p_adjusted = float(adj)
        tests[idx].significant = bool(adj < alpha)
    return tests


def claim_supported(
    values_a: Sequence[float],
    values_b: Sequence[float],
    min_effect: float = 0.0,
    alpha: float = 0.05,
) -> Tuple[bool, str]:
    """Gate a manuscript claim of the form "A outperforms B".

    Fails the claim when (a) the test is not significant, or (b) the margin is
    smaller than the pooled seed-to-seed standard deviation -- the condition
    under which a reviewer will say the result is noise, and correctly so.
    """
    a, b = np.asarray(values_a, float), np.asarray(values_b, float)
    t = paired_test("A", a, "B", b, alpha=alpha)
    pooled_sd = float(np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2)) if len(a) > 1 else 0.0
    margin = float(a.mean() - b.mean())
    if not t.significant:
        return False, (
            f"not supported: paired {t.test} p = {t.p_value:.3g} at alpha = {alpha} "
            f"(mean difference {margin:+.4f}, n = {t.n} seeds)"
            + (f" [{t.note}]" if t.note else "")
        )
    if abs(margin) < max(pooled_sd, min_effect):
        return False, (
            f"not supported: margin {margin:+.4f} is smaller than the seed-to-seed "
            f"spread ({pooled_sd:.4f}); report as 'comparable', not as an improvement"
        )
    return True, (
        f"supported: margin {margin:+.4f}, paired {t.test} p = {t.p_value:.3g}, "
        f"d_z = {t.effect_size:.2f}, n = {t.n} seeds"
    )


def bootstrap_diff_ci(
    values_a: Sequence[float], values_b: Sequence[float], n_boot: int = 10000, seed: int = 0,
    alpha: float = 0.05,
) -> Tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    a, b = np.asarray(values_a, float), np.asarray(values_b, float)
    d = a - b
    idx = rng.integers(0, len(d), size=(n_boot, len(d)))
    boots = d[idx].mean(axis=1)
    return float(d.mean()), float(np.percentile(boots, 100 * alpha / 2)), float(
        np.percentile(boots, 100 * (1 - alpha / 2))
    )
