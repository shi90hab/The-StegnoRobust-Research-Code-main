"""Computational profiling: parameters, FLOPs, peak VRAM, latency, wall-clock.

Not requested verbatim by either reviewer, but "the experimental scope is too
narrow for a middle-tier venue" (Reviewer 2, comment 8) is partly a question of
what the paper reports. A cost table also substantiates the paper's own framing
of the attack as "low-cost" -- currently an assertion with no measurement behind
it.

Latency is measured after warm-up and with an explicit cuda.synchronize before
stopping the timer; without synchronisation the number measures the launch queue,
not the model.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, Optional

import torch
import torch.nn as nn


@dataclass
class CostReport:
    """Cost of one component, tagged with the hardware that produced it.

    §13: on CPU there is no VRAM to report, so peak resident set size takes its
    place, and `hardware` / `timing_reportable` travel with the numbers. FLOPs
    and parameter count are comparable across devices; latency and wall-clock
    are not, and the table generator refuses to print them unmarked.
    """

    component: str
    params_m: float
    gflops: Optional[float]
    peak_vram_gb: Optional[float]      # None on CPU -- absent, not zero
    peak_rss_gb: Optional[float]
    latency_ms: float
    train_hours: Optional[float] = None
    hardware: str = "unknown"
    device: str = "unknown"
    threads: Optional[int] = None
    timing_reportable: bool = True
    timing_note: str = ""

    def as_row(self) -> Dict[str, Any]:
        return asdict(self)


def peak_rss_gb() -> float:
    """Peak resident memory. The CPU counterpart of max_memory_allocated.

    Reported for every run, not only CPU ones: on a memory-constrained host the
    ceiling is hit as swap thrash rather than as a clean OOM, and a recorded peak
    is the only way to see it coming.
    """
    try:
        import resource

        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports kilobytes, macOS reports bytes.
        import sys

        return peak / 1e9 if sys.platform == "darwin" else peak / 1e6
    except Exception:
        try:
            import psutil

            return psutil.Process().memory_info().rss / 1e9
        except Exception:
            return float("nan")


def count_flops(model: nn.Module, input_shape=(1, 1, 256, 256), device: str = "cpu") -> Optional[float]:
    try:
        from fvcore.nn import FlopCountAnalysis

        x = torch.zeros(input_shape, device=device)
        flops = FlopCountAnalysis(model.to(device).eval(), x)
        flops.unsupported_ops_warnings(False)
        flops.uncalled_modules_warnings(False)
        return float(flops.total()) / 1e9
    except Exception:
        return None


@torch.no_grad()
def measure_latency(
    model: nn.Module, input_shape=(1, 1, 256, 256), device: str = "cuda",
    warmup: int = 20, iters: int = 100,
) -> float:
    dev = torch.device(device if torch.cuda.is_available() else "cpu")
    model = model.to(dev).eval()
    x = torch.zeros(input_shape, device=dev)
    for _ in range(warmup):
        model(x)
    if dev.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        model(x)
    if dev.type == "cuda":
        torch.cuda.synchronize()   # without this we time the queue, not the model
    return (time.perf_counter() - t0) / iters * 1000.0 / input_shape[0]


def profile_model(
    name: str, model: nn.Module, input_shape=(1, 1, 256, 256), device: str = "cuda",
    train_hours: Optional[float] = None, fingerprint: Optional[Any] = None,
) -> CostReport:
    params = sum(p.numel() for p in model.parameters()) / 1e6
    on_cuda = torch.cuda.is_available() and device.startswith("cuda")
    if on_cuda:
        torch.cuda.reset_peak_memory_stats()
    lat = measure_latency(model, input_shape, device)
    vram = (torch.cuda.max_memory_allocated() / 1e9) if on_cuda else None
    return CostReport(
        component=name, params_m=params, gflops=count_flops(model, input_shape, "cpu"),
        peak_vram_gb=vram, peak_rss_gb=peak_rss_gb(), latency_ms=lat, train_hours=train_hours,
        hardware=(fingerprint.label() if fingerprint else device),
        device=(fingerprint.device if fingerprint else device),
        threads=(fingerprint.threads if fingerprint else None),
        timing_reportable=(fingerprint.timing_reportable if fingerprint else True),
        timing_note=(fingerprint.timing_note if fingerprint else ""),
    )


def profile_attack(
    name: str, attack_fn: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    x: torch.Tensor, y: torch.Tensor, device: str = "cuda", iters: int = 5,
    fingerprint: Optional[Any] = None,
) -> CostReport:
    """Attack cost per image -- the quantity that substantiates 'low-cost'."""
    if torch.cuda.is_available() and device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        attack_fn(x, y)
    if torch.cuda.is_available() and device.startswith("cuda"):
        torch.cuda.synchronize()
    dt = (time.perf_counter() - t0) / iters / x.shape[0] * 1000.0
    on_cuda = torch.cuda.is_available() and device.startswith("cuda")
    peak = (torch.cuda.max_memory_allocated() / 1e9) if on_cuda else None
    return CostReport(
        component=name, params_m=0.0, gflops=None, peak_vram_gb=peak, peak_rss_gb=peak_rss_gb(),
        latency_ms=dt, train_hours=None,
        hardware=(fingerprint.label() if fingerprint else device),
        device=(fingerprint.device if fingerprint else device),
        threads=(fingerprint.threads if fingerprint else None),
        timing_reportable=(fingerprint.timing_reportable if fingerprint else True),
        timing_note=(fingerprint.timing_note if fingerprint else ""),
    )
