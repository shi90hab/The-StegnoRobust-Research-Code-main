"""Polarity-safe detection metrics, DeLong confidence intervals, committee rules.

This module exists because of three specific reviewer objections.

Reviewer 1, comment 4 -- "Table 2 reports XuNet AUC = 0.489 while Table 3 shows
XuNet decreasing to AUC = 0.000 after attack. Since an AUC below 0.5 can
indicate inverted ranking rather than loss of information, please clarify
whether score polarity was fixed consistently."

  The answer implemented here: a *canonical* score is defined once and for all as
  s = logit[stego] - logit[cover], and the class index for "stego" is asserted
  against the dataset label convention at construction time
  (assert_label_convention). Polarity is therefore never inferred from the data,
  which is what makes an AUC of 0.000 meaningful: it is a genuinely inverted
  ranking under a fixed orientation, not an artefact of a flipped column.

  `auc_with_polarity_report` additionally returns `auc_flipped = 1 - auc` and an
  explicit `inverted` flag so both numbers appear in the results table and the
  reader can see that the orientation was checked rather than assumed.

Reviewer 1, comment 6 -- "The committee mean AUC of 0.745 is derived from XuNet
and YeNet only, but one member has AUC = 0.489."

  `committee_summary` refuses to emit a mean when any member fails the
  convergence gate, returning `None` plus a machine-readable reason. Downstream
  table generation prints "n/a (member not converged)" rather than a number.

Reviewer 2, comment 7 / Reviewer 1, comment 5 -- claims must carry uncertainty.

  `delong_auc_ci` gives an analytic CI for a single AUC and `delong_auc_test`
  gives the paired DeLong test for two AUCs computed on the *same* test set,
  which is the correct test for "did the attack reduce this detector's AUC" and
  for "is the held-out detector's drop smaller than the committee's".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

# --------------------------------------------------------------------------
# Label / score conventions
# --------------------------------------------------------------------------

COVER_LABEL = 0
STEGO_LABEL = 1
STEGO_LOGIT_INDEX = 1  # column 1 of the 2-way head is P(stego)


def assert_label_convention(labels: np.ndarray) -> None:
    u = set(np.unique(labels).tolist())
    if not u.issubset({COVER_LABEL, STEGO_LABEL}):
        raise ValueError(f"labels must be in {{0,1}} (0=cover,1=stego); got {sorted(u)}")


def canonical_score(logits: np.ndarray) -> np.ndarray:
    """s = logit[stego] - logit[cover]. Higher means "more likely stego".

    Fixed once here so that every AUC in the paper is computed under one
    orientation. Do not compute AUC from raw softmax columns elsewhere.
    """
    logits = np.asarray(logits, dtype=np.float64)
    if logits.ndim != 2 or logits.shape[1] != 2:
        raise ValueError(f"expected (N,2) logits, got {logits.shape}")
    return logits[:, STEGO_LOGIT_INDEX] - logits[:, 1 - STEGO_LOGIT_INDEX]


# --------------------------------------------------------------------------
# AUC and the DeLong machinery
# --------------------------------------------------------------------------


def _midrank(x: np.ndarray) -> np.ndarray:
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N, dtype=np.float64)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(N, dtype=np.float64)
    out[J] = T
    return out


def _structural_components(scores: np.ndarray, m: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """DeLong V10/V01 components for k score vectors. scores is (k, m+n),
    positives first."""
    k, total = scores.shape
    n = total - m
    tx = np.empty((k, m)); ty = np.empty((k, n)); tz = np.empty((k, total))
    for r in range(k):
        tx[r] = _midrank(scores[r, :m])
        ty[r] = _midrank(scores[r, m:])
        tz[r] = _midrank(scores[r, :])
    aucs = (tz[:, :m].sum(axis=1) / m - (m + 1) / 2.0) / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    return aucs, v01, v10


def _cov(v01: np.ndarray, v10: np.ndarray, m: int, n: int) -> np.ndarray:
    return np.cov(v01) / m + np.cov(v10) / n


def roc_auc(labels: np.ndarray, scores: np.ndarray) -> float:
    """Rank-based AUC with correct tie handling. No sklearn dependency."""
    labels = np.asarray(labels).astype(int)
    scores = np.asarray(scores, dtype=np.float64)
    assert_label_convention(labels)
    pos = scores[labels == STEGO_LABEL]
    neg = scores[labels == COVER_LABEL]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    r = _midrank(np.concatenate([pos, neg]))
    return float((r[: len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def delong_auc_ci(
    labels: np.ndarray, scores: np.ndarray, alpha: float = 0.05
) -> Tuple[float, float, float]:
    """(auc, lo, hi) via the DeLong variance and a logit-transformed interval.

    The logit transform keeps the interval inside [0,1], which matters here
    because several AUCs sit near 0.5 and one sits at 1.000.
    """
    from scipy import stats

    labels = np.asarray(labels).astype(int)
    scores = np.asarray(scores, dtype=np.float64)
    order = np.argsort(-labels, kind="mergesort")  # positives first
    s = scores[order][None, :]
    m = int((labels == STEGO_LABEL).sum())
    n = len(labels) - m
    aucs, v01, v10 = _structural_components(s, m)
    auc = float(aucs[0])
    var = float(np.atleast_2d(_cov(v01, v10, m, n))[0, 0])
    if var <= 0 or auc in (0.0, 1.0):
        # Degenerate: perfect or constant separation. Fall back to a
        # Clopper-Pearson-style bound on the equivalent Mann-Whitney statistic.
        lo, hi = _bootstrap_auc_ci(labels, scores, alpha=alpha)
        return auc, lo, hi
    se = np.sqrt(var)
    z = stats.norm.ppf(1 - alpha / 2)
    lg = np.log(auc / (1 - auc))
    se_lg = se / (auc * (1 - auc))
    lo = 1 / (1 + np.exp(-(lg - z * se_lg)))
    hi = 1 / (1 + np.exp(-(lg + z * se_lg)))
    return auc, float(lo), float(hi)


def _bootstrap_auc_ci(
    labels: np.ndarray, scores: np.ndarray, alpha: float = 0.05, n_boot: int = 2000, seed: int = 0
) -> Tuple[float, float]:
    rng = np.random.default_rng(seed)
    pos_idx = np.flatnonzero(labels == STEGO_LABEL)
    neg_idx = np.flatnonzero(labels == COVER_LABEL)
    vals = np.empty(n_boot)
    for b in range(n_boot):
        p = rng.choice(pos_idx, size=len(pos_idx), replace=True)
        q = rng.choice(neg_idx, size=len(neg_idx), replace=True)
        idx = np.concatenate([p, q])
        vals[b] = roc_auc(labels[idx], scores[idx])
    return float(np.nanpercentile(vals, 100 * alpha / 2)), float(
        np.nanpercentile(vals, 100 * (1 - alpha / 2))
    )


def delong_auc_test(
    labels: np.ndarray, scores_a: np.ndarray, scores_b: np.ndarray
) -> Dict[str, float]:
    """Paired DeLong test for two AUCs on the SAME samples.

    Use for clean-vs-attacked on one detector, since both score vectors come
    from the same test images.
    """
    from scipy import stats

    labels = np.asarray(labels).astype(int)
    order = np.argsort(-labels, kind="mergesort")
    s = np.vstack([np.asarray(scores_a)[order], np.asarray(scores_b)[order]])
    m = int((labels == STEGO_LABEL).sum())
    n = len(labels) - m
    aucs, v01, v10 = _structural_components(s, m)
    cov = _cov(v01, v10, m, n)
    L = np.array([[1.0, -1.0]])
    var = float(np.atleast_2d(L @ cov @ L.T)[0, 0])
    diff = float(aucs[0] - aucs[1])
    if var <= 0:
        return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "diff": diff, "z": float("nan"), "p": float("nan")}
    z = diff / np.sqrt(var)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "diff": diff, "z": float(z), "p": float(p)}


# --------------------------------------------------------------------------
# Detection report
# --------------------------------------------------------------------------


@dataclass
class DetectionReport:
    detector: str
    auc: float
    auc_lo: float
    auc_hi: float
    auc_flipped: float
    inverted: bool
    accuracy: float
    fpr: float
    fnr: float
    p_error: float
    md5: float  # missed detection at 5% false alarm -- the forensic operating point
    n_pos: int
    n_neg: int
    degenerate: bool
    degenerate_reason: Optional[str] = None

    def as_row(self) -> Dict[str, object]:
        return self.__dict__.copy()


def detection_report(
    detector: str,
    labels: np.ndarray,
    logits: np.ndarray,
    threshold: float = 0.0,
) -> DetectionReport:
    labels = np.asarray(labels).astype(int)
    assert_label_convention(labels)
    s = canonical_score(logits)
    auc, lo, hi = delong_auc_ci(labels, s)
    pred = (s > threshold).astype(int)

    tp = int(((pred == 1) & (labels == 1)).sum())
    tn = int(((pred == 0) & (labels == 0)).sum())
    fp = int(((pred == 1) & (labels == 0)).sum())
    fn = int(((pred == 0) & (labels == 1)).sum())
    n_pos, n_neg = tp + fn, tn + fp
    fpr = fp / max(n_neg, 1)
    fnr = fn / max(n_pos, 1)
    acc = (tp + tn) / max(len(labels), 1)

    # A detector that emits (nearly) one distinct score is collapsed. This is the
    # XuNet failure mode in the submitted Table 2 and it must be flagged in the
    # results object, not diagnosed by eye from an FPR of 1.000.
    uniq = len(np.unique(np.round(s, 6)))
    degenerate = uniq <= 2 or fpr > 0.99 or fnr > 0.99
    reason = None
    if degenerate:
        reason = (
            f"near-constant scores ({uniq} distinct values)"
            if uniq <= 2
            else f"saturated confusion matrix (FPR={fpr:.3f}, FNR={fnr:.3f})"
        )

    return DetectionReport(
        detector=detector,
        auc=auc,
        auc_lo=lo,
        auc_hi=hi,
        auc_flipped=1.0 - auc,
        inverted=auc < 0.5,
        accuracy=acc,
        fpr=fpr,
        fnr=fnr,
        p_error=0.5 * (fpr + fnr),
        md5=missed_detection_at_fa(labels, s, fa=0.05),
        n_pos=n_pos,
        n_neg=n_neg,
        degenerate=degenerate,
        degenerate_reason=reason,
    )


def missed_detection_at_fa(labels: np.ndarray, scores: np.ndarray, fa: float = 0.05) -> float:
    """MD@5%FA: the miss rate at a 5% false-alarm budget.

    Reported because in casework a false accusation and a missed detection are
    not symmetric costs, and AUC hides where on the ROC a detector is usable.
    """
    neg = np.sort(scores[labels == COVER_LABEL])
    if len(neg) == 0:
        return float("nan")
    thr = np.quantile(neg, 1 - fa)
    pos = scores[labels == STEGO_LABEL]
    return float((pos <= thr).mean()) if len(pos) else float("nan")


# --------------------------------------------------------------------------
# Convergence gate and committee rules
# --------------------------------------------------------------------------


@dataclass
class ConvergenceGate:
    """Reviewer 1 comment 8 / Reviewer 2 comments 3-4.

    A detector is admitted to the committee, or to the held-out role, only if its
    clean validation AUC is significantly above chance. `min_auc` is the point
    estimate floor; `require_ci_above_chance` additionally demands that the lower
    end of the DeLong 95% CI exceeds 0.5, which is the statistically honest test.
    """

    min_auc: float = 0.75
    require_ci_above_chance: bool = True
    forbid_degenerate: bool = True

    def admits(self, rep: DetectionReport) -> Tuple[bool, str]:
        if self.forbid_degenerate and rep.degenerate:
            return False, f"degenerate: {rep.degenerate_reason}"
        if rep.auc < self.min_auc:
            return False, f"clean AUC {rep.auc:.3f} < gate {self.min_auc:.2f}"
        if self.require_ci_above_chance and rep.auc_lo <= 0.5:
            return False, f"95% CI lower bound {rep.auc_lo:.3f} does not exceed chance"
        return True, "admitted"


@dataclass
class CommitteeSummary:
    members: List[str]
    admitted: List[str]
    rejected: Dict[str, str]
    mean_auc: Optional[float]
    reason: str
    per_member: Dict[str, float] = field(default_factory=dict)


def committee_summary(
    reports: Sequence[DetectionReport], gate: ConvergenceGate
) -> CommitteeSummary:
    admitted, rejected = [], {}
    for r in reports:
        ok, why = gate.admits(r)
        (admitted.append(r.detector) if ok else rejected.update({r.detector: why}))
    per = {r.detector: r.auc for r in reports}
    if rejected:
        return CommitteeSummary(
            members=[r.detector for r in reports],
            admitted=admitted,
            rejected=rejected,
            mean_auc=None,
            reason=(
                "committee mean suppressed: "
                + "; ".join(f"{k} ({v})" for k, v in rejected.items())
                + ". Averaging a converged detector with a chance-level one produces "
                "a number that describes neither."
            ),
            per_member=per,
        )
    return CommitteeSummary(
        members=[r.detector for r in reports],
        admitted=admitted,
        rejected={},
        mean_auc=float(np.mean([per[d] for d in admitted])),
        reason="all members passed the convergence gate",
        per_member=per,
    )
