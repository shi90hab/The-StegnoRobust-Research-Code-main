"""XuNet [8], with the training-stability fixes required by Reviewer 1 comment 8.

Original run: XuNet reached AUC 0.489 with FPR 1.000 and FNR 0.000, i.e. it
predicted "stego" for every input -- a collapsed classifier, not a weak one.
Three properties of the architecture make this collapse likely and are handled
explicitly here rather than left to chance:

1. The KV kernel is FIXED (a buffer). Letting it train destroys the high-pass
   prior in the first few hundred steps and the network never recovers.
2. The absolute-value layer after the first convolution is essential; without it
   the sign of the residual carries content information that swamps the payload.
3. BatchNorm in a collapsed regime produces near-constant activations. We expose
   `bn_momentum` so it can be lowered, and pair it with paired batching
   (src/data/pair_dataset.py) which is the actual fix.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from .srm import KVConv


class _Group(nn.Module):
    def __init__(self, cin, cout, ksize, use_abs=False, use_tanh=True, pool=5, pool_stride=2, bn_momentum=0.05):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, ksize, padding=ksize // 2, bias=False)
        self.bn = nn.BatchNorm2d(cout, momentum=bn_momentum)
        self.use_abs = use_abs
        self.act = nn.Tanh() if use_tanh else nn.ReLU(inplace=True)
        self.pool = nn.AvgPool2d(pool, stride=pool_stride, padding=pool // 2)

    def forward(self, x):
        x = self.conv(x)
        if self.use_abs:
            x = torch.abs(x)
        x = self.bn(x)
        x = self.act(x)
        return self.pool(x)


class XuNet(nn.Module):
    name = "XuNet"

    def __init__(self, in_channels: int = 1, num_classes: int = 2, bn_momentum: float = 0.05):
        super().__init__()
        self.hpf = KVConv()  # fixed, not trained
        self.g1 = _Group(in_channels, 8, 5, use_abs=True, use_tanh=True, bn_momentum=bn_momentum)
        self.g2 = _Group(8, 16, 5, use_tanh=True, bn_momentum=bn_momentum)
        self.g3 = _Group(16, 32, 1, use_tanh=False, bn_momentum=bn_momentum)
        self.g4 = _Group(32, 64, 1, use_tanh=False, bn_momentum=bn_momentum)
        self.g5 = _Group(64, 128, 1, use_tanh=False, pool=1, pool_stride=1, bn_momentum=bn_momentum)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(128, num_classes)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, mean=0.0, std=0.01)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, std=0.01)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.hpf(x)
        x = self.g1(x)
        x = self.g2(x)
        x = self.g3(x)
        x = self.g4(x)
        x = self.g5(x)
        x = self.gap(x).flatten(1)
        return self.fc(x)

    def no_decay_params(self):
        """The fixed HPF has no parameters; BN affine terms should skip weight decay."""
        return [n for n, _ in self.named_parameters() if "bn" in n or n.endswith(".bias")]
