"""SRM high-pass filter bank (30 basic 5x5 kernels) and the KV kernel.

Used by YeNet's front end [6] and, as a single kernel, by XuNet [8]. Kernels are
registered as buffers (not parameters) in the trainable=False case so they are
saved in the checkpoint and moved with .to(device), but receive no gradient.
"""
from __future__ import annotations

from typing import List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn

# Xu et al. [8] KV high-pass kernel, normalised by 1/12.
KV_KERNEL = (
    np.array(
        [
            [-1, 2, -2, 2, -1],
            [2, -6, 8, -6, 2],
            [-2, 8, -12, 8, -2],
            [2, -6, 8, -6, 2],
            [-1, 2, -2, 2, -1],
        ],
        dtype=np.float32,
    )
    / 12.0
)


def _place(k: np.ndarray) -> np.ndarray:
    """Embed a small kernel into the centre of a 5x5 support."""
    out = np.zeros((5, 5), dtype=np.float32)
    h, w = k.shape
    t, l = (5 - h) // 2, (5 - w) // 2
    out[t : t + h, l : l + w] = k
    return out


DIRECTIONS_8 = [(0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]
DIRECTIONS_4 = [(0, 1), (1, 0), (1, 1), (1, -1)]


def _directional(taps: Sequence[float], direction: Tuple[int, int]) -> np.ndarray:
    """Lay a 1-D tap sequence along `direction`, centred in a 5x5 support.

    taps are indexed from the centre outwards: taps[0] sits at the centre pixel,
    taps[k] at k steps along the direction.
    """
    k = np.zeros((5, 5), dtype=np.float32)
    dy, dx = direction
    for i, t in enumerate(taps):
        y, x = 2 + i * dy, 2 + i * dx
        if 0 <= y < 5 and 0 <= x < 5:
            k[y, x] += t
    return k


def srm_bank(n: int = 30) -> np.ndarray:
    """The 30 basic SRM linear residual kernels as (30, 5, 5).

    Composition, following Fridrich & Kodovsky's rich model (each family
    normalised by its q-factor so residual magnitudes are comparable):

        8  first-order  (spam14, eight neighbour directions), q = 1
        4  second-order (two axes, two diagonals),            q = 2
        8  third-order  (eight directions),                   q = 3
        1  SQUARE 3x3,                                        q = 4
        4  EDGE 3x3,                                          q = 4
        1  SQUARE 5x5 (the KV kernel XuNet uses),             q = 12
        4  EDGE 5x5,                                          q = 12
        --
        30

    Distinctness is asserted: emitting rotations of a rotation-symmetric base
    silently produces duplicate channels, which wastes front-end capacity while
    appearing to have 30.
    """
    ks: List[np.ndarray] = []

    for d in DIRECTIONS_8:                                   # first order, q=1
        ks.append(_directional([-1.0, 1.0], d))
    for d in DIRECTIONS_4:                                   # second order, q=2
        dy, dx = d
        k = np.zeros((5, 5), dtype=np.float32)
        k[2, 2] = -2.0
        k[2 + dy, 2 + dx] = 1.0
        k[2 - dy, 2 - dx] = 1.0
        ks.append(k / 2.0)
    for d in DIRECTIONS_8:                                   # third order, q=3
        dy, dx = d
        k = np.zeros((5, 5), dtype=np.float32)
        for i, t in zip(range(-1, 3), (1.0, -3.0, 3.0, -1.0)):
            y, x = 2 + i * dy, 2 + i * dx
            if 0 <= y < 5 and 0 <= x < 5:
                k[y, x] += t
        ks.append(k / 3.0)

    sq3 = np.array([[-1, 2, -1], [2, -4, 2], [-1, 2, -1]], dtype=np.float32) / 4.0
    ks.append(_place(sq3))                                   # SQUARE 3x3, q=4

    edge3 = np.array([[-1, 2, -1], [2, -4, 2], [0, 0, 0]], dtype=np.float32) / 4.0
    for r in range(4):                                       # EDGE 3x3, q=4
        ks.append(_place(np.rot90(edge3, r)))

    ks.append(KV_KERNEL.astype(np.float32).copy())           # SQUARE 5x5, q=12

    edge5 = KV_KERNEL.astype(np.float32).copy()
    edge5[3:, :] = 0.0
    for r in range(4):                                       # EDGE 5x5, q=12
        ks.append(np.ascontiguousarray(np.rot90(edge5, r), dtype=np.float32))

    out = np.stack(ks[:n], axis=0).astype(np.float32)
    assert out.shape == (n, 5, 5), out.shape
    n_unique = len({np.round(k, 8).tobytes() for k in out})
    assert n_unique == n, f"SRM bank has {n_unique} distinct kernels, expected {n}"
    return out


class SRMConv(nn.Module):
    """30-channel SRM front end.

    `trainable=True` reproduces YeNet's published behaviour of fine-tuning the
    bank at a much lower learning rate than the body; see
    src/training/optim.py::param_groups.
    """

    def __init__(self, trainable: bool = True):
        super().__init__()
        w = torch.from_numpy(srm_bank()).unsqueeze(1)  # (30,1,5,5)
        if trainable:
            self.weight = nn.Parameter(w)
        else:
            self.register_buffer("weight", w)
        self.trainable = trainable

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return nn.functional.conv2d(x, self.weight, padding=2)


class KVConv(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer("weight", torch.from_numpy(KV_KERNEL).view(1, 1, 5, 5))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return nn.functional.conv2d(x, self.weight, padding=2)


class TLU(nn.Module):
    """Truncated linear unit, Ye et al. [6]. Threshold T=3.0 by default."""

    def __init__(self, threshold: float = 3.0):
        super().__init__()
        self.threshold = threshold

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.clamp(x, -self.threshold, self.threshold)
