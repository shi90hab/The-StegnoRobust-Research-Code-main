"""Deep hiding baselines: SteganoGAN wrapper and a HiDDeN-style encoder/decoder.

Reviewer 2, comment 5 asks for comparison against "stronger modern deep hiding
methods" as well as classical ones. Two are provided:

  SteganoGANWrapper -- loads the pretrained released weights used in the
      manuscript (basic / dense / residual). If the `steganogan` package is not
      installed the wrapper raises with an actionable message rather than
      silently falling back, because a silent fallback would put a different
      generator behind the same name in the results table.

  HiDDeN -- a compact reimplementation of Zhu et al. [4]: a conv encoder that
      spreads a message tensor across the image, a noise layer, and a conv
      decoder. Included because HiDDeN is the standard deep-hiding reference and
      because it can be retrained here at *matched payload*, which the released
      SteganoGAN weights cannot (they are fixed at their trained data depth).
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


INSTALL_HINT = """
`pip install steganogan==0.1.3` fails on pip >= 24.1 with "No matching distribution
found" WHILE LISTING 0.1.3 as available. The cause is neither the network nor the
Python version: the published wheel's metadata contains a malformed requirement,

    Requires-Dist: numpy (>=1.15.4<1.16.0)          <- missing comma

and pip 24.1 turned metadata validation from a warning into a hard error. Install it
with the repair script, which fixes that one character and leaves the code and the
pretrained weights untouched:

    python tools/install_steganogan.py

Do not "fix" this with --ignore-requires-python; that flag addresses a different
problem and has no effect here.
"""


class SteganoGANWrapper:
    """Thin adapter around the released SteganoGAN checkpoints.

    Two compatibility problems stand between the 2019 release and a 2026 Colab,
    and both are handled here rather than in the notebook, because they are
    properties of the released artifact rather than of the environment:

    1. The pretrained `.steg` files are pickled *model objects*, not state dicts.
       Since torch 2.6 `torch.load` defaults to `weights_only=True` and refuses
       them.
    2. Those pickles embed a torch-1.0 Adam optimizer. Modern
       `Optimizer.__setstate__` assumes a `defaults` key that the 2019 pickle does
       not carry, so unpickling dies with
       `AttributeError: 'Adam' object has no attribute 'defaults'`. The optimizer
       is irrelevant to inference; an empty `defaults` is enough to get past it.
    3. `decode` builds its bit list from `decoder(x) > 0`, which produced uint8
       0/1 in 2019 and produces Python `bool` now, so the package's own
       `bits_to_bytearray` renders them as the strings "True"/"False" and raises
       `ValueError: invalid literal for int() with base 2`.

    Every shim is scoped to the operation that needs it and reverted afterwards. A
    global monkeypatch of `torch.load` would silently weaken every checkpoint load
    in the process, which is not a trade worth making for convenience.
    """

    VARIANTS = ("basic", "dense", "residual")

    @staticmethod
    @contextmanager
    def legacy_compat():
        """Make a 2019 artifact loadable and usable on a 2026 stack, reversibly."""
        import torch

        orig_load = torch.load
        orig_setstate = torch.optim.Optimizer.__setstate__

        def load(*args, **kwargs):
            kwargs.setdefault("weights_only", False)          # (1)
            return orig_load(*args, **kwargs)

        def setstate(self, state):                            # (2)
            state = dict(state)
            state.setdefault("defaults", {})
            return orig_setstate(self, state)

        def bits_to_bytearray(bits):                          # (3)
            return bytearray(
                int("".join(str(int(b)) for b in bits[i * 8:(i + 1) * 8]), 2)
                for i in range(len(bits) // 8)
            )

        torch.load = load
        torch.optim.Optimizer.__setstate__ = setstate

        patched_modules = []
        try:
            import steganogan.models as sm
            import steganogan.utils as su

            # models.py did `from steganogan.utils import bits_to_bytearray`, so the
            # name must be replaced in BOTH modules -- patching utils alone leaves
            # the already-bound reference in models untouched.
            for mod in (su, sm):
                if hasattr(mod, "bits_to_bytearray"):
                    patched_modules.append((mod, mod.bits_to_bytearray))
                    mod.bits_to_bytearray = bits_to_bytearray
        except ImportError:
            pass

        try:
            yield
        finally:
            torch.load = orig_load
            torch.optim.Optimizer.__setstate__ = orig_setstate
            for mod, original in patched_modules:
                mod.bits_to_bytearray = original

    def __init__(self, variant: str = "dense", device: str = "cuda"):
        if variant not in self.VARIANTS:
            raise ValueError(f"variant must be one of {self.VARIANTS}")
        try:
            from steganogan import SteganoGAN  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "The `steganogan` package is required to reproduce the manuscript's "
                "generator; refusing to substitute a different one, which would put "
                "another model behind the same name in the results table.\n" + INSTALL_HINT
            ) from exc

        import torch

        use_cuda = device == "cuda" and torch.cuda.is_available()
        with self.legacy_compat():
            self.model = SteganoGAN.load(architecture=variant, cuda=use_cuda, verbose=False)
        self.variant = variant
        self.device = "cuda" if use_cuda else "cpu"

    def encode(self, cover_path: str, out_path: str, message: str) -> None:
        with self.legacy_compat():
            self.model.encode(cover_path, out_path, message)

    def decode(self, stego_path: str) -> str:
        """Recover the payload.

        Note on capacity, which matters for Table 1 of the manuscript. At the
        released `data_depth` of 8 the raw bit error rate on natural images is
        ~0.18-0.27, so a message is often NOT recoverable and this raises
        `ValueError: Failed to find message.` That is SteganoGAN's documented
        behaviour, not a defect here: its headline metric is RS-BPP, the
        error-corrected rate `data_depth * (2 * accuracy - 1)`, which at 80%
        accuracy is ~4.8 bpp rather than 8. Report the nominal data depth and the
        measured RS-BPP separately -- calling 8 bpp the capacity overstates it.
        """
        with self.legacy_compat():
            return self.model.decode(stego_path)

    def bit_error_rate(self, cover_path: str, message: str) -> float:
        """Measured BER for one cover, which is what RS-BPP is computed from."""
        import numpy as np
        from PIL import Image

        with self.legacy_compat():
            arr = np.asarray(Image.open(cover_path).convert("RGB"), dtype=np.float32)
            cover = torch.FloatTensor(arr / 127.5 - 1.0).permute(2, 1, 0).unsqueeze(0)
            payload = self.model._make_payload(
                cover.size(3), cover.size(2), self.model.data_depth, message
            )
            cover, payload = cover.to(self.model.device), payload.to(self.model.device)
            with torch.no_grad():
                generated = self.model.encoder(cover, payload).clamp(-1.0, 1.0)
                decoded = (self.model.decoder(generated).view(-1) > 0).float()
            return float((decoded != (payload.view(-1) > 0).float()).float().mean())

    def rs_bpp(self, cover_path: str, message: str) -> float:
        """Error-corrected payload rate: data_depth * (2 * accuracy - 1)."""
        acc = 1.0 - self.bit_error_rate(cover_path, message)
        return float(self.data_depth * (2 * acc - 1))

    @property
    def data_depth(self) -> int:
        return int(getattr(self.model, "data_depth", 0))


class _ConvBNReLU(nn.Sequential):
    def __init__(self, cin, cout):
        super().__init__(nn.Conv2d(cin, cout, 3, 1, 1), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class HiDDeNEncoder(nn.Module):
    def __init__(self, message_bits: int, channels: int = 64, blocks: int = 4, in_ch: int = 3):
        super().__init__()
        self.message_bits = message_bits
        layers = [_ConvBNReLU(in_ch, channels)] + [_ConvBNReLU(channels, channels) for _ in range(blocks - 1)]
        self.body = nn.Sequential(*layers)
        self.after_concat = _ConvBNReLU(channels + in_ch + message_bits, channels)
        self.out = nn.Conv2d(channels, in_ch, 1)

    def forward(self, image: torch.Tensor, message: torch.Tensor) -> torch.Tensor:
        n, _, h, w = image.shape
        m = message.view(n, self.message_bits, 1, 1).expand(-1, -1, h, w)
        f = self.body(image)
        f = self.after_concat(torch.cat([m, f, image], dim=1))
        return image + self.out(f)


class HiDDeNDecoder(nn.Module):
    def __init__(self, message_bits: int, channels: int = 64, blocks: int = 7, in_ch: int = 3):
        super().__init__()
        layers = [_ConvBNReLU(in_ch, channels)] + [_ConvBNReLU(channels, channels) for _ in range(blocks - 1)]
        layers.append(_ConvBNReLU(channels, message_bits))
        self.body = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(message_bits, message_bits)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.fc(self.pool(self.body(image)).flatten(1))


class NoiseLayer(nn.Module):
    """Identity / crop / gaussian / jpeg-approx noise, selectable from config."""

    def __init__(self, kind: str = "identity", strength: float = 0.0):
        super().__init__()
        self.kind, self.strength = kind, strength

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.kind == "identity" or self.strength <= 0:
            return x
        if self.kind == "gaussian":
            return x + torch.randn_like(x) * self.strength
        if self.kind == "dropout":
            mask = (torch.rand_like(x) > self.strength).float()
            return x * mask
        raise ValueError(f"unknown noise kind {self.kind}")


@dataclass
class HiDDeNConfig:
    message_bits: int = 64
    channels: int = 64
    noise: str = "identity"
    noise_strength: float = 0.0
    lambda_image: float = 0.7
    lambda_message: float = 1.0


class HiDDeN(nn.Module):
    """Trainable at any payload, which is what makes matched-payload comparison
    against SteganoGAN and the classical methods possible."""

    def __init__(self, cfg: HiDDeNConfig, in_ch: int = 3):
        super().__init__()
        self.cfg = cfg
        self.encoder = HiDDeNEncoder(cfg.message_bits, cfg.channels, in_ch=in_ch)
        self.decoder = HiDDeNDecoder(cfg.message_bits, cfg.channels, in_ch=in_ch)
        self.noise = NoiseLayer(cfg.noise, cfg.noise_strength)

    def forward(self, cover: torch.Tensor, message: torch.Tensor):
        stego = self.encoder(cover, message).clamp(0, 1)
        decoded = self.decoder(self.noise(stego))
        return stego, decoded

    def loss(self, cover, message):
        stego, decoded = self(cover, message)
        l_img = F.mse_loss(stego, cover)
        l_msg = F.binary_cross_entropy_with_logits(decoded, message)
        total = self.cfg.lambda_image * l_img + self.cfg.lambda_message * l_msg
        return total, {"image_mse": l_img.item(), "message_bce": l_msg.item()}

    def bpp(self, h: int, w: int) -> float:
        return self.cfg.message_bits / (h * w)
