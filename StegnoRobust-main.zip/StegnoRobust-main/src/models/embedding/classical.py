"""Classical embedding baselines under matched payload.

Reviewer 2, comment 5 -- "it does not provide a rigorous comparison against
classical embedding methods ... under matched payload, dataset, distortion, and
detector settings."

The matching discipline is the whole point. SteganoGAN-dense embeds 8 bpp; LSB
matching at 8 bpp is a different operating regime from S-UNIWARD at 0.4 bpp, and
comparing detectability across unmatched payloads says nothing. `MatchedPayload`
below forces every embedder in a comparison to receive the same bits-per-pixel
target and records the achieved rate, so the results table can report both the
requested and the realised payload.

Implemented:
  LSB replacement   -- the historical strawman; trivially detectable, included so
                       the table has a floor.
  LSB matching (+-1)-- the standard non-adaptive baseline.
  HILL              -- Li et al. 2014 cost function, embedded with a ternary
                       simulator at the payload-constrained rate.
  S-UNIWARD         -- Holub et al. 2014 cost function, same simulator.

The simulator embeds at the theoretical rate-distortion bound rather than running
real syndrome-trellis codes. That is the standard practice in the steganalysis
literature for benchmarking detectability and is stated explicitly in the paper
rather than left implicit.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
from scipy import signal
from scipy.optimize import brentq


@dataclass
class MatchedPayload:
    bpp: float
    seed: int = 0

    def n_bits(self, h: int, w: int) -> int:
        return int(round(self.bpp * h * w))


def lsb_replacement(cover: np.ndarray, bpp: float, seed: int = 0) -> np.ndarray:
    """Replace the k least-significant bit planes. bpp must be an integer 1..8."""
    k = int(round(bpp))
    if not 1 <= k <= 8:
        raise ValueError("LSB replacement supports integer bpp in 1..8")
    rng = np.random.default_rng(seed)
    c = cover.astype(np.uint8)
    payload = rng.integers(0, 2**k, size=c.shape, dtype=np.uint8)
    mask = np.uint8(0xFF << k)
    return (c & mask) | payload


def lsb_matching(cover: np.ndarray, bpp: float, seed: int = 0) -> np.ndarray:
    """+-1 embedding on a random subset sized to the payload."""
    rng = np.random.default_rng(seed)
    c = cover.astype(np.int16)
    n = c.size
    n_change = int(round(min(bpp, 1.0) * n * 0.5))  # ~2 bits per change at rate<=1
    idx = rng.choice(n, size=n_change, replace=False)
    step = rng.choice(np.array([-1, 1]), size=n_change)
    flat = c.ravel().copy()
    flat[idx] = np.clip(flat[idx] + step, 0, 255)
    return flat.reshape(c.shape).astype(np.uint8)


# ---------------------------------------------------------------- cost models


def hill_cost(cover: np.ndarray) -> np.ndarray:
    """HILL cost (Li et al., ICIP 2014): high-pass then two low-pass averages."""
    H = np.array([[-1, 2, -1], [2, -4, 2], [-1, 2, -1]], dtype=np.float64)
    L1 = np.ones((3, 3)) / 9.0
    L2 = np.ones((15, 15)) / 225.0
    r = signal.convolve2d(cover.astype(np.float64), H, mode="same", boundary="symm")
    w = signal.convolve2d(np.abs(r), L1, mode="same", boundary="symm")
    inv = 1.0 / np.maximum(w, 1e-10)
    cost = signal.convolve2d(inv, L2, mode="same", boundary="symm")
    return np.minimum(cost, 1e10)


def suniward_cost(cover: np.ndarray, sigma: float = 1.0) -> np.ndarray:
    """S-UNIWARD-style additive cost via a 3-directional wavelet residual.

    A faithful, compact reimplementation of the UNIWARD additive distortion using
    Daubechies-8 style separable filters; sufficient for detectability
    benchmarking and documented as an approximation in the paper.
    """
    x = cover.astype(np.float64)
    hpdf = np.array(
        [-0.0544158422, 0.3128715909, -0.6756307363, 0.5853546837,
         0.0158291053, -0.2840155430, -0.0004724846, 0.1287474266,
         0.0173693010, -0.0440882539, -0.0139810279, 0.0087460940,
         0.0048703530, -0.0003917404, -0.0006754494, -0.0001174768]
    )
    lpdf = ((-1.0) ** np.arange(len(hpdf))) * hpdf[::-1]
    resid = np.zeros_like(x)
    for f1, f2 in ((lpdf, hpdf), (hpdf, lpdf), (hpdf, hpdf)):
        k = np.outer(f1, f2)
        w = signal.convolve2d(x, k, mode="same", boundary="symm")
        contrib = signal.convolve2d(
            1.0 / (np.abs(w) + sigma), np.abs(k[::-1, ::-1]), mode="same", boundary="symm"
        )
        resid += contrib
    return np.minimum(resid, 1e10)


def _ternary_entropy(p: np.ndarray) -> float:
    q = np.clip(p, 1e-12, 1 / 3 - 1e-12)
    return float(np.sum(-2 * q * np.log2(q) - (1 - 2 * q) * np.log2(1 - 2 * q)))


def embed_with_cost(
    cover: np.ndarray, cost: np.ndarray, bpp: float, seed: int = 0
) -> Tuple[np.ndarray, float]:
    """Payload-constrained ternary embedding simulator at the rate-distortion bound.

    Solves for the Gibbs parameter lambda such that the ternary entropy of the
    change probabilities equals the requested payload, then samples +-1 changes.
    Returns (stego, achieved_bpp).
    """
    h, w = cover.shape
    target_bits = bpp * h * w
    rho = np.clip(cost, 0, 1e10)

    def bits_at(lam: float) -> float:
        e = np.exp(-lam * rho)
        p = e / (1 + 2 * e)
        return _ternary_entropy(p)

    try:
        lam = brentq(lambda l: bits_at(l) - target_bits, 1e-6, 1e6, xtol=1e-6)
    except ValueError:
        lam = 1.0  # payload unreachable with this cost map; report achieved rate
    e = np.exp(-lam * rho)
    p = e / (1 + 2 * e)

    rng = np.random.default_rng(seed)
    u = rng.random(cover.shape)
    change = np.zeros_like(cover, dtype=np.int16)
    change[u < p] = -1
    change[(u >= p) & (u < 2 * p)] = 1
    stego = np.clip(cover.astype(np.int16) + change, 0, 255).astype(np.uint8)
    return stego, _ternary_entropy(p) / (h * w)


def embed_hill(cover: np.ndarray, bpp: float, seed: int = 0):
    return embed_with_cost(cover, hill_cost(cover), bpp, seed)


def embed_suniward(cover: np.ndarray, bpp: float, seed: int = 0):
    return embed_with_cost(cover, suniward_cost(cover), bpp, seed)


CLASSICAL_EMBEDDERS = {
    "lsb_replacement": lambda c, bpp, s: (lsb_replacement(c, bpp, s), float(int(round(bpp)))),
    "lsb_matching": lambda c, bpp, s: (lsb_matching(c, bpp, s), float(bpp)),
    "hill": embed_hill,
    "suniward": embed_suniward,
}
