"""YeNet [6]: SRM filter bank + TLU front end, then a plain convolutional body.

YeNet is the detector that converged in the original run (AUC 1.000). It is
reimplemented here unchanged in substance so that the revised results remain
comparable to the submitted ones; the only additions are (a) the option to keep
the SRM bank fixed for ablation, and (b) exposure of the TLU threshold as a
config value rather than a literal.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from .srm import SRMConv, TLU


def _cbr(cin, cout, k=3, s=1, p=1, act=True):
    layers = [nn.Conv2d(cin, cout, k, s, p, bias=False), nn.BatchNorm2d(cout)]
    if act:
        layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


class YeNet(nn.Module):
    name = "YeNet"

    def __init__(
        self,
        in_channels: int = 1,
        num_classes: int = 2,
        tlu_threshold: float = 3.0,
        trainable_srm: bool = True,
    ):
        super().__init__()
        assert in_channels == 1, "YeNet operates on the luminance channel"
        self.srm = SRMConv(trainable=trainable_srm)
        self.tlu = TLU(tlu_threshold)
        self.body = nn.Sequential(
            _cbr(30, 30, 3),
            _cbr(30, 30, 3),
            _cbr(30, 30, 3),
            nn.AvgPool2d(2, 2),
            _cbr(30, 32, 5, p=2),
            nn.AvgPool2d(3, 2, padding=1),
            _cbr(32, 32, 5, p=2),
            nn.AvgPool2d(3, 2, padding=1),
            _cbr(32, 32, 5, p=2),
            nn.AvgPool2d(3, 2, padding=1),
            _cbr(32, 16, 3),
            _cbr(16, 16, 3),
        )
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(16, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.tlu(self.srm(x))
        x = self.body(x)
        x = self.gap(x).flatten(1)
        return self.fc(x)

    def srm_parameters(self):
        return [p for n, p in self.named_parameters() if n.startswith("srm.")]

    def body_parameters(self):
        return [p for n, p in self.named_parameters() if not n.startswith("srm.")]
