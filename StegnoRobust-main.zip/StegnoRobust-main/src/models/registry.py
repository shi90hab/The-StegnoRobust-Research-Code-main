from __future__ import annotations

from typing import Any, Dict

import torch.nn as nn

from .srnet import SRNet
from .xunet import XuNet
from .yenet import YeNet

_REGISTRY = {"xunet": XuNet, "yenet": YeNet, "srnet": SRNet}


def build_detector(name: str, **kwargs: Any) -> nn.Module:
    key = name.lower()
    if key not in _REGISTRY:
        raise KeyError(f"unknown detector '{name}'; available: {sorted(_REGISTRY)}")
    return _REGISTRY[key](**kwargs)


def count_parameters(model: nn.Module) -> Dict[str, int]:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total": total, "trainable": trainable, "frozen": total - trainable}
