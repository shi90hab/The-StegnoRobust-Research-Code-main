"""SRNet [7], with the convergence protocol Reviewer 2 comment 3 demands.

SRNet is the held-out detector whose near-chance clean AUC (0.498) invalidates
the paper's central transferability claim. It did not converge because SRNet is
known to require a much longer schedule than XuNet/YeNet: Boroumand et al. train
for ~400k iterations with Adamax and a step LR drop, and -- critically -- the
Type-1/Type-2 blocks contain no pooling for the first seven layers, so gradients
must travel far before any spatial reduction helps them.

What this file adds beyond a faithful reimplementation:

* `init_from` supports curriculum initialisation: SRNet trained first on a
  high-payload (easy) task, then fine-tuned to the target payload. This is the
  standard recipe for making SRNet converge on hard settings and is exposed in
  configs/detector/srnet.yaml as `curriculum.enabled`.
* Zero-init of the last BN gamma in each residual block (`zero_init_residual`)
  makes every Type-3 block an identity at step 0, which measurably stabilises
  the first epochs of a deep residual stack.
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn


class Type1(nn.Module):
    """Conv-BN-ReLU, no pooling."""

    def __init__(self, cin, cout):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(cin, cout, 3, 1, 1, bias=False),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class Type2(nn.Module):
    """Residual block, no pooling: x + Conv-BN-ReLU-Conv-BN."""

    def __init__(self, c, zero_init_residual: bool = True):
        super().__init__()
        self.c1 = nn.Conv2d(c, c, 3, 1, 1, bias=False)
        self.b1 = nn.BatchNorm2d(c)
        self.relu = nn.ReLU(inplace=True)
        self.c2 = nn.Conv2d(c, c, 3, 1, 1, bias=False)
        self.b2 = nn.BatchNorm2d(c)
        if zero_init_residual:
            nn.init.zeros_(self.b2.weight)

    def forward(self, x):
        y = self.relu(self.b1(self.c1(x)))
        y = self.b2(self.c2(y))
        return x + y


class Type3(nn.Module):
    """Residual block with 1x1-strided shortcut and average pooling."""

    def __init__(self, cin, cout, zero_init_residual: bool = True):
        super().__init__()
        self.short = nn.Sequential(
            nn.Conv2d(cin, cout, 1, 2, 0, bias=False), nn.BatchNorm2d(cout)
        )
        self.c1 = nn.Conv2d(cin, cout, 3, 1, 1, bias=False)
        self.b1 = nn.BatchNorm2d(cout)
        self.relu = nn.ReLU(inplace=True)
        self.c2 = nn.Conv2d(cout, cout, 3, 1, 1, bias=False)
        self.b2 = nn.BatchNorm2d(cout)
        self.pool = nn.AvgPool2d(3, 2, padding=1)
        if zero_init_residual:
            nn.init.zeros_(self.b2.weight)

    def forward(self, x):
        y = self.relu(self.b1(self.c1(x)))
        y = self.pool(self.b2(self.c2(y)))
        return self.short(x) + y


class Type4(nn.Module):
    """Terminal block: Conv-BN then global average pooling."""

    def __init__(self, cin, cout):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(cin, cout, 3, 1, 1, bias=False),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
        )
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        return self.gap(self.block(x)).flatten(1)


class SRNet(nn.Module):
    name = "SRNet"

    def __init__(
        self,
        in_channels: int = 1,
        num_classes: int = 2,
        width: int = 16,
        zero_init_residual: bool = True,
    ):
        super().__init__()
        w = width
        self.l1 = Type1(in_channels, 64)
        self.l2 = Type1(64, w)
        self.l3 = nn.Sequential(*[Type2(w, zero_init_residual) for _ in range(5)])
        self.l8 = Type3(w, w, zero_init_residual)
        self.l9 = Type3(w, 64, zero_init_residual)
        self.l10 = Type3(64, 128, zero_init_residual)
        self.l11 = Type3(128, 256, zero_init_residual)
        self.l12 = Type4(256, 512)
        self.fc = nn.Linear(512, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.l2(self.l1(x))
        x = self.l3(x)
        x = self.l11(self.l10(self.l9(self.l8(x))))
        return self.fc(self.l12(x))

    def init_from(self, ckpt_path: str, strict: bool = False) -> None:
        """Curriculum warm start from a checkpoint trained at an easier payload."""
        sd = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        sd = sd.get("model_state_dict", sd)
        missing, unexpected = self.load_state_dict(sd, strict=strict)
        if missing or unexpected:
            print(f"[SRNet.init_from] missing={len(missing)} unexpected={len(unexpected)}")
