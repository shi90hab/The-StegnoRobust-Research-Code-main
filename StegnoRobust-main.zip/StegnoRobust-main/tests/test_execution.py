"""Tests for skill §13 (local CPU execution) and §12 dual-target operation.

The recurring theme: a number that cannot be reproduced or compared must fail
loudly at the point it is produced, not be silently printed into a table.
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from src.evaluation.tables import table_profiling
from src.supervision.registry import (
    DELIVERY,
    PressureConfig,
    PressureMonitor,
    RunRecord,
    RunRegistry,
)
import src.utils.execution as execution_mod
from src.utils.execution import (
    TARGETS,
    HardwareFingerprint,
    UnreportableTiming,
    assert_timing_reportable,
    configure,
    low_ram_guard,
    pin_threads,
    sklearn_n_jobs,
)


# ---------------------------------------------------------------- thread pinning


def test_pin_threads_sets_every_blas_backend():
    env = pin_threads(1)
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        assert env[var] == "1" and os.environ[var] == "1"


def test_torch_thread_count_follows_the_pin():
    torch = pytest.importorskip("torch")
    pin_threads(1)
    assert torch.get_num_threads() == 1


def test_n_jobs_minus_one_is_never_allowed_for_a_reported_run():
    """n_jobs=-1 makes the result depend on the host's core count."""
    assert sklearn_n_jobs(-1, "pinned") == 1
    assert sklearn_n_jobs(None, "pinned") == 1
    assert sklearn_n_jobs(4, "pinned") == 4


# ---------------------------------------------------------------- target declaration


def test_local_target_is_refused_on_a_hosted_runtime(monkeypatch):
    """The other half of the contract, which the three tests above were masking.

    Declaring env=local on Colab would record a laptop's hardware for a run that
    happened on a rented VM, so every timing in the table would describe a machine
    that never ran it. This is the failure that surfaced on Colab as three red
    tests -- the guard working, and the tests wrong.
    """
    monkeypatch.setattr(execution_mod, "_is_colab", lambda: True)
    with pytest.raises(RuntimeError, match="hosted runtime"):
        configure("local", threads=1)

    # ...and the hosted targets are accepted there, with timings marked unusable.
    fp = configure("colab_cpu", threads=2, thread_mode="pinned")
    assert fp.is_hosted is True
    assert fp.timing_reportable is False
    assert "varies between sessions" in fp.timing_note


def test_target_must_be_declared_from_the_known_set():
    with pytest.raises(ValueError):
        configure("laptop")
    assert set(TARGETS) == {"local", "colab_cpu", "colab_gpu"}


@pytest.fixture
def not_hosted(monkeypatch):
    """Pretend we are on fixed local hardware.

    `configure("local")` deliberately raises on a hosted runtime -- that guard is
    the point of §13. But a test that only passes on a laptop is a test that fails
    in CI and on Colab, which is exactly what happened. These tests exercise the
    LOGIC, so the environment is pinned rather than assumed.
    """
    monkeypatch.setattr(execution_mod, "_is_colab", lambda: False)


def test_local_pinned_run_is_reportable(not_hosted):
    fp = configure("local", threads=1, thread_mode="pinned")
    assert fp.timing_reportable is True
    assert fp.threads == 1 and fp.device == "cpu"
    assert_timing_reportable(fp)


def test_exploration_mode_timings_are_refused(not_hosted):
    fp = configure("local", threads=2, thread_mode="exploration")
    assert fp.timing_reportable is False
    with pytest.raises(UnreportableTiming):
        assert_timing_reportable(fp, "epoch wall-clock")


def test_hosted_cpu_timings_are_refused():
    """The VM's CPU model varies per session, so wall-clock is incomparable."""
    fp = HardwareFingerprint(
        target="colab_cpu", device="cpu", device_name="x", cpu_model="unknown", cpu_count=2,
        threads=2, thread_mode="pinned", total_ram_gb=13.0, platform="linux", is_hosted=True,
        timing_reportable=False, timing_note="hosted CPU runtime: CPU model varies between sessions",
    )
    with pytest.raises(UnreportableTiming):
        assert_timing_reportable(fp)


def test_mps_is_never_reportable():
    """Unsupported ops fall back to CPU silently, so latency means nothing."""
    fp = HardwareFingerprint(
        target="local", device="mps", device_name="Apple MPS", cpu_model="M2", cpu_count=8,
        threads=1, thread_mode="pinned", total_ram_gb=16.0, platform="darwin", is_hosted=False,
        timing_reportable=False, timing_note="MPS: unsupported operators fall back to CPU silently",
    )
    with pytest.raises(UnreportableTiming):
        assert_timing_reportable(fp)


def test_fingerprint_label_is_usable_as_a_table_cell(not_hosted):
    fp = configure("local", threads=1)
    assert "CPU" in fp.label() and "1t" in fp.label()


# ---------------------------------------------------------------- low RAM


def test_low_ram_guard_caps_joblib_workers():
    fp = HardwareFingerprint(
        target="local", device="cpu", device_name="x", cpu_model="x", cpu_count=8, threads=1,
        thread_mode="pinned", total_ram_gb=16.0, platform="darwin", is_hosted=False,
        timing_reportable=True,
    )
    # a 1 GB frame at n_jobs=6 costs 6 GB in copies before the estimator allocates
    capped, why = low_ram_guard(fp, 6, int(1e9))
    assert capped < 6 and "copies the dataset per worker" in why
    assert low_ram_guard(fp, 2, int(1e7))[0] == 2


# ---------------------------------------------------------------- cost table


def _row(**kw):
    base = dict(component="c", params_m=1.0, gflops=1.0, peak_vram_gb=None, peak_rss_gb=1.0,
                latency_ms=10.0, train_hours=1.0, hardware="CPU x (1t)", device="cpu",
                threads=1, timing_reportable=True, timing_note="")
    base.update(kw)
    return base


def test_hardware_column_appears_when_rows_span_devices(tmp_path):
    out = table_profiling(
        [_row(component="a", device="cpu", hardware="CPU x (1t)"),
         _row(component="b", device="cuda", hardware="Tesla T4", peak_vram_gb=1.2)],
        tmp_path / "cost.tex",
    )
    tex = out.read_text()
    assert "Hardware" in tex
    assert "must not be compared across rows" in tex


def test_no_hardware_column_when_all_rows_share_hardware(tmp_path):
    tex = table_profiling([_row(component="a"), _row(component="b")], tmp_path / "c.tex").read_text()
    assert "Hardware" not in tex


def test_unreportable_timing_prints_nr_not_a_number(tmp_path):
    tex = table_profiling(
        [_row(component="explore", latency_ms=99.0, train_hours=5.0, timing_reportable=False,
              timing_note="hosted CPU runtime: CPU model varies")],
        tmp_path / "c.tex",
    ).read_text()
    assert "n/r" in tex and "99.00" not in tex
    assert "the metric from that run is still valid, its speed is not" in tex


def test_vram_and_rss_are_distinguished(tmp_path):
    tex = table_profiling(
        [_row(component="gpu", peak_vram_gb=1.4, device="cuda", hardware="T4"),
         _row(component="cpu", peak_vram_gb=None, peak_rss_gb=2.1)],
        tmp_path / "c.tex",
    ).read_text()
    assert "(VRAM)" in tex and "(RSS)" in tex


# ---------------------------------------------------------------- dual target


def test_delivery_channel_per_target():
    assert DELIVERY["local"] == "direct"
    assert DELIVERY["colab_cpu"] == DELIVERY["colab_gpu"] == "branch"


def test_budget_is_shared_across_targets_and_survives_migration(tmp_path):
    reg = RunRegistry(tmp_path / "reg.json")
    reg.register(RunRecord(experiment_id="exp1", target="local", detector="srnet"))
    reg.budget("exp1").round = 2
    reg.save()

    reg.migrate("exp1", "colab_gpu", "sustained memory pressure", "Tesla T4")
    assert reg.runs["exp1"].target == "colab_gpu"
    assert reg.runs["exp1"].delivery == "branch"
    # the counter belongs to the experiment, not to the process or the target
    assert reg.budget("exp1").round == 2

    reloaded = RunRegistry(tmp_path / "reg.json")
    assert reloaded.budget("exp1").round == 2


def test_migration_marks_timings_invalid_but_not_metrics(tmp_path):
    reg = RunRegistry(tmp_path / "reg.json")
    reg.register(RunRecord(experiment_id="exp2", target="local"))
    assert reg.timing_valid("exp2")[0] is True

    reg.migrate("exp2", "colab_gpu", "load average sustained", "Tesla T4")
    ok, reason = reg.timing_valid("exp2")
    assert ok is False
    assert "describe neither machine" in reason
    assert "Metrics remain valid" in reason
    assert len(reg.runs["exp2"].migrations) == 1


def test_budget_sync_takes_the_higher_round_so_none_is_lost(tmp_path):
    reg = RunRegistry(tmp_path / "reg.json")
    reg.register(RunRecord(experiment_id="exp3", target="local"))
    reg.budget("exp3").round = 1
    merged = reg.sync_budget_from_checkpoint(
        "exp3", {"extra": {"supervisor": {"round": 2, "max_rounds": 3,
                                          "last_intervention_epoch": 30,
                                          "applied_patch_hashes": ["z"],
                                          "halted": False, "halt_reason": ""}}}
    )
    assert merged.round == 2, "a reconnect must not lose a round"
    assert "z" in merged.applied_patch_hashes


# ---------------------------------------------------------------- migration pressure


def test_a_single_spike_does_not_trigger_migration():
    m = PressureMonitor(PressureConfig(sustained_minutes=5, sample_seconds=30))
    fired, why = m.observe({"load_per_core": 9.0, "memory_percent": 99.0, "swap_percent": 80.0})
    assert fired is False
    assert "sustained pressure, not a spike" in why


def test_sustained_pressure_triggers_migration():
    cfg = PressureConfig(sustained_minutes=1, sample_seconds=30)
    m = PressureMonitor(cfg)
    fired = False
    for _ in range(cfg.samples_required):
        fired, why = m.observe({"load_per_core": 9.0, "memory_percent": 99.0, "swap_percent": 80.0})
    assert fired is True and "consecutive minutes" in why


def test_recovered_host_resets_the_window():
    cfg = PressureConfig(sustained_minutes=1, sample_seconds=30)
    m = PressureMonitor(cfg)
    m.observe({"load_per_core": 9.0, "memory_percent": 99.0, "swap_percent": 80.0})
    m.observe({"load_per_core": 0.1, "memory_percent": 20.0, "swap_percent": 0.0})
    fired, _ = m.observe({"load_per_core": 9.0, "memory_percent": 99.0, "swap_percent": 80.0})
    assert fired is False
