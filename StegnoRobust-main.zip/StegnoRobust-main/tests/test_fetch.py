"""Dataset acquisition: pin on first use, verify on every use."""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

import src.data.fetch as F


@pytest.fixture
def source(tmp_path):
    payload = tmp_path / "src.tgz"
    payload.write_bytes(b"archive contents v1" * 2000)
    F.SOURCES["testsrc"] = {
        "url": payload.as_uri(), "filename": "src.tgz", "approx_mb": 1,
        "license": "test", "citation": "x", "source_format": "TGZ", "caveat": None,
    }
    yield payload, hashlib.sha256(payload.read_bytes()).hexdigest()
    F.SOURCES.pop("testsrc", None)


def test_first_download_records_the_digest_rather_than_inventing_one(tmp_path, source, capsys):
    _, real = source
    rec = F.fetch("testsrc", tmp_path / "cache", expected_sha256=None,
                  provenance_path=tmp_path / "prov.json")
    assert rec.sha256 == real
    assert "not yet pinned" in capsys.readouterr().out


def test_cached_and_pinned_archive_is_verified(tmp_path, source):
    _, real = source
    cache = tmp_path / "cache"
    F.fetch("testsrc", cache, provenance_path=tmp_path / "p.json")
    rec = F.fetch("testsrc", cache, expected_sha256=real, provenance_path=tmp_path / "p.json")
    assert rec.sha256 == real


def test_a_silently_replaced_cache_is_redownloaded_not_used(tmp_path, source):
    payload, real = source
    cache = tmp_path / "cache"
    F.fetch("testsrc", cache, provenance_path=tmp_path / "p.json")
    (cache / "src.tgz").write_bytes(b"a different mirror entirely")
    rec = F.fetch("testsrc", cache, expected_sha256=real, provenance_path=tmp_path / "p.json")
    assert rec.sha256 == real, "a cached file failing its pin must be re-fetched"


def test_a_changed_source_refuses_to_proceed(tmp_path, source):
    with pytest.raises(RuntimeError) as e:
        F.fetch("testsrc", tmp_path / "cache", expected_sha256="0" * 64,
                provenance_path=tmp_path / "p.json")
    assert "do not proceed" in str(e.value).lower()
    assert "re-run every affected experiment" in str(e.value)


def test_provenance_records_license_and_citation(tmp_path, source):
    F.fetch("testsrc", tmp_path / "cache", provenance_path=tmp_path / "p.json")
    rec = json.loads((tmp_path / "p.json").read_text())["testsrc"]
    for k in ("url", "sha256", "size_bytes", "license", "citation", "source_format", "downloaded_at"):
        assert k in rec


def test_stage_does_not_re_extract(tmp_path, source):
    payload, _ = source
    dest = tmp_path / "staged"
    dest.mkdir()
    (dest / "existing").write_text("x")
    assert F.stage(payload, dest) == dest
    assert (dest / "existing").exists()


def test_unknown_source_is_a_keyerror_not_a_silent_default():
    with pytest.raises(KeyError):
        F.fetch("not_a_dataset", "/tmp/x")


def test_every_declared_source_carries_format_and_caveat():
    """The JPEG-vs-PGM distinction is load-bearing for steganalysis, so no source
    may be declared without stating its format."""
    for name, spec in F.SOURCES.items():
        assert spec.get("source_format"), f"{name} has no source_format"
        assert spec.get("license"), f"{name} has no license recorded"
        assert spec.get("url", "").startswith(("http://", "https://")), f"{name} has no real URL"


def test_dataset_configs_are_readable_without_the_paths_node():
    """Regression: a group config must be readable standalone.

    `configs/dataset/*.yaml` interpolates ${paths.local_root}, which lives in
    main.yaml. Hydra composes the two at run time, but a notebook or script that
    loads one group file on its own gets InterpolationKeyError the moment it
    touches `.root`. Anything reading a group file directly must read it
    unresolved -- this test pins that contract.
    """
    from omegaconf import OmegaConf
    from omegaconf.errors import InterpolationKeyError

    root_dir = Path(__file__).resolve().parents[1]
    for name in ("bsds500", "bossbase", "div2k", "coco"):
        cfg = OmegaConf.load(root_dir / "configs" / "dataset" / f"{name}.yaml")

        with pytest.raises(InterpolationKeyError):
            _ = cfg.root                      # the failure mode, pinned

        raw = OmegaConf.to_container(cfg, resolve=False)
        assert "${paths.local_root}" in raw["root"], f"{name}: unexpected root template"
        resolved = raw["root"].replace("${paths.local_root}", "/content/stegorobust")
        assert resolved.startswith("/content/stegorobust/data/")
        assert "${" not in resolved, f"{name}: another interpolation is still unresolved"


def test_dataset_configs_declare_a_real_url_and_archive_name():
    from omegaconf import OmegaConf

    root_dir = Path(__file__).resolve().parents[1]
    for name in ("bsds500", "bossbase", "div2k", "coco"):
        raw = OmegaConf.to_container(
            OmegaConf.load(root_dir / "configs" / "dataset" / f"{name}.yaml"), resolve=False
        )
        assert raw["url"].startswith(("http://", "https://"))
        assert raw["archive"].endswith((".tgz", ".zip", ".tar.bz2", ".tar.gz"))
        assert "sha256" in raw, f"{name} has no slot to pin its digest"
