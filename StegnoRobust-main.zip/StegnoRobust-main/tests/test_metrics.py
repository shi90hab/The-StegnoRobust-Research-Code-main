"""Tests for the claims this repository makes about its own numbers.

These are not incidental unit tests. Each one corresponds to a reviewer comment
and fails if the corresponding defect is reintroduced.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

from src.evaluation.metrics import (
    ConvergenceGate,
    canonical_score,
    committee_summary,
    delong_auc_ci,
    delong_auc_test,
    detection_report,
    roc_auc,
)
from src.evaluation.transferability import transferability_gap
from src.attacks.common import PsnrClaim, check_psnr_claim, format_psnr, psnr_worst_case


def _logits(scores):
    """Build (N,2) logits whose canonical score equals `scores`."""
    s = np.asarray(scores, float)
    return np.stack([np.zeros_like(s), s], axis=1)


def test_auc_matches_sklearn():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 2, 500)
    s = rng.normal(y * 1.2, 1.0)
    try:
        from sklearn.metrics import roc_auc_score
    except ImportError:
        pytest.skip("sklearn not installed")
    assert abs(roc_auc(y, s) - roc_auc_score(y, s)) < 1e-9


def test_auc_handles_ties():
    y = np.array([0, 0, 1, 1])
    s = np.array([1.0, 1.0, 1.0, 1.0])
    assert abs(roc_auc(y, s) - 0.5) < 1e-12


def test_polarity_is_fixed_not_inferred():
    """R1-4: an inverted ranking must report AUC < 0.5, never be silently flipped."""
    y = np.array([0] * 50 + [1] * 50)
    inverted = np.concatenate([np.ones(50), -np.ones(50)])  # stego scores LOWER
    rep = detection_report("inverted", y, _logits(inverted))
    assert rep.auc < 0.5
    assert rep.inverted is True
    assert abs(rep.auc_flipped - (1 - rep.auc)) < 1e-12


def test_degenerate_detector_is_flagged():
    """R1-4/R2-4: the XuNet failure mode (constant prediction) must be detected."""
    y = np.array([0] * 50 + [1] * 50)
    rep = detection_report("collapsed", y, _logits(np.full(100, 3.0)))
    assert rep.degenerate
    assert rep.fpr == 1.0 and rep.fnr == 0.0


def test_committee_mean_suppressed_when_member_fails():
    """R1-6: no mean over a converged and a chance-level detector."""
    y = np.array([0] * 100 + [1] * 100)
    rng = np.random.default_rng(1)
    good = detection_report("yenet", y, _logits(np.concatenate([rng.normal(-3, 1, 100), rng.normal(3, 1, 100)])))
    bad = detection_report("xunet", y, _logits(rng.normal(0, 1, 200)))
    summ = committee_summary([good, bad], ConvergenceGate())
    assert summ.mean_auc is None
    assert "xunet" in summ.rejected
    assert "suppressed" in summ.reason


def test_transferability_gap_undefined_when_heldout_at_chance():
    """R1-5/R2-3: the manuscript's central claim must not be computable here."""
    y = np.array([0] * 100 + [1] * 100)
    rng = np.random.default_rng(2)
    strong = np.concatenate([rng.normal(-4, 1, 100), rng.normal(4, 1, 100)])
    chance = rng.normal(0, 1, 200)

    committee_clean = [detection_report("yenet", y, _logits(strong))]
    committee_att = [detection_report("yenet", y, _logits(strong * 0.05))]
    held_clean = detection_report("srnet", y, _logits(chance))
    held_att = detection_report("srnet", y, _logits(chance))

    res = transferability_gap(
        8 / 255, committee_clean, committee_att, held_clean, held_att, ConvergenceGate()
    )
    assert res.defined is False
    assert res.gap is None
    assert "not converged" in res.reason


def test_transferability_gap_defined_when_both_converged():
    y = np.array([0] * 200 + [1] * 200)
    rng = np.random.default_rng(3)
    strong = np.concatenate([rng.normal(-4, 1, 200), rng.normal(4, 1, 200)])
    ok_held = np.concatenate([rng.normal(-2, 1, 200), rng.normal(2, 1, 200)])
    # A successful attack destroys the RANKING, so degrade by adding noise --
    # scaling the scores leaves AUC unchanged, which is itself worth asserting.
    assert abs(roc_auc(y, strong) - roc_auc(y, strong * 0.05)) < 1e-12

    attacked_committee = strong + rng.normal(0, 6, 400)
    attacked_held = ok_held + rng.normal(0, 1, 400)
    res = transferability_gap(
        8 / 255,
        [detection_report("yenet", y, _logits(strong))],
        [detection_report("yenet", y, _logits(attacked_committee))],
        detection_report("srnet", y, _logits(ok_held)),
        detection_report("srnet", y, _logits(attacked_held)),
        ConvergenceGate(),
    )
    assert res.defined is True
    assert res.gap is not None and res.gap > 0


def test_delong_ci_contains_point_estimate():
    rng = np.random.default_rng(4)
    y = np.array([0] * 300 + [1] * 300)
    s = np.concatenate([rng.normal(0, 1, 300), rng.normal(1, 1, 300)])
    auc, lo, hi = delong_auc_ci(y, s)
    assert lo <= auc <= hi and 0 <= lo and hi <= 1


def test_delong_paired_test_detects_real_drop():
    rng = np.random.default_rng(5)
    y = np.array([0] * 300 + [1] * 300)
    before = np.concatenate([rng.normal(0, 1, 300), rng.normal(2.5, 1, 300)])
    after = before - np.concatenate([np.zeros(300), np.full(300, 2.5)])
    res = delong_auc_test(y, before, after)
    assert res["diff"] > 0.2 and res["p"] < 0.01


def test_psnr_claim_checker_catches_the_reported_inconsistency():
    """R1-3: the exact numbers from the submitted paper."""
    measured = [50.3, 45.2, 42.3, 40.5, 38.3, 36.9]
    ok, msg = check_psnr_claim(PsnrClaim(threshold_db=37.0), measured)
    assert ok is False and "36.9" in msg
    ok2, _ = check_psnr_claim(PsnrClaim(threshold_db=36.0), measured)
    assert ok2 is True


def test_psnr_formatting_is_round_half_even_and_stable():
    assert format_psnr(36.94) == "36.9"
    assert format_psnr(36.96) == "37.0"
    # Exact half-way values round to the EVEN last digit, which is the rule the
    # table note states: 36.95 -> 37.0 (0 is even), 36.85 -> 36.8 (8 is even).
    # Ties therefore do not drift systematically upward, which is what turns a
    # measured 36.9x into a claimed ">= 37 dB".
    assert format_psnr(36.95) == "37.0"
    assert format_psnr(36.85) == "36.8"
    # And the number that started the argument stays where the table put it.
    assert format_psnr(36.9) == "36.9"


def test_psnr_worst_case_is_below_measured():
    # eps = 8/255 -> algebraic floor 30.06 dB; the measured 36.9 dB is consistent
    # because PGD does not saturate every pixel. The two are different quantities.
    assert abs(psnr_worst_case(8) - 30.06) < 0.02
    assert psnr_worst_case(8) < 36.9
