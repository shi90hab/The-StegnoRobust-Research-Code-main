"""Tests for skill §14. Each corresponds to a silent failure mode."""
import json
import stat
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from src.data.kaggle_source import (
    GITIGNORE_ENTRIES,
    DatasetProvenance,
    KaggleCredentialError,
    LeaderboardSplitError,
    assert_not_leaderboard_split,
    check_drift,
    ensure_gitignored,
    sha256_file,
    split_plan,
    verify_or_redownload,
)

HAS_GIT = subprocess.run(["git", "--version"], capture_output=True).returncode == 0


def test_leaderboard_split_cannot_be_the_held_out_test_set():
    with pytest.raises(LeaderboardSplitError) as e:
        assert_not_leaderboard_split("test", "competition_test")
    msg = str(e.value)
    assert "unlabeled" in msg and "thousands of submissions" in msg
    # a locally carved split is fine
    assert_not_leaderboard_split("test", "labeled")


def test_split_plan_keeps_the_leaderboard_separate():
    plan = split_plan(has_competition_test=True)
    assert set(plan) == {"train", "val", "test", "leaderboard"}
    assert "never as the paper's held-out evaluation" in plan["leaderboard"]
    assert "touched once" in plan["test"]
    assert "leaderboard" not in split_plan(has_competition_test=False)


@pytest.mark.skipif(not HAS_GIT, reason="git not available")
def test_credentials_are_gitignored_before_the_first_commit(tmp_path):
    from src.utils.git_provenance import ensure_repo

    repo = ensure_repo(tmp_path / "paper")
    added = ensure_gitignored(repo)
    ignore = (repo / ".gitignore").read_text().splitlines()
    for entry in GITIGNORE_ENTRIES:
        assert entry in ignore
    assert "kaggle.json" in added


@pytest.mark.skipif(not HAS_GIT, reason="git not available")
def test_a_committed_key_demands_rotation_not_deletion(tmp_path):
    from src.utils.git_provenance import ensure_repo, git

    repo = ensure_repo(tmp_path / "paper")
    git("config", "user.email", "t@e.com", repo=repo)
    git("config", "user.name", "T", repo=repo)
    (repo / "kaggle.json").write_text('{"username":"u","key":"k"}')
    git("add", "-f", "kaggle.json", repo=repo)
    git("commit", "-m", "oops", repo=repo)

    with pytest.raises(KaggleCredentialError) as e:
        ensure_gitignored(repo)
    assert "rotate" in str(e.value).lower()
    assert "history retains the blob" in str(e.value)


def test_local_key_with_loose_permissions_is_rejected(tmp_path, monkeypatch):
    import src.data.kaggle_source as ks

    key = tmp_path / "kaggle.json"
    key.write_text('{"username":"u","key":"k"}')
    key.chmod(0o644)
    monkeypatch.setattr(ks, "KAGGLE_JSON", key)
    monkeypatch.delenv("KAGGLE_USERNAME", raising=False)
    monkeypatch.delenv("KAGGLE_KEY", raising=False)

    with pytest.raises(KaggleCredentialError) as e:
        ks.configure_credentials()
    assert "chmod 600" in str(e.value)

    key.chmod(0o600)
    assert ks.configure_credentials() == "local"


def test_missing_credentials_refuse_a_key_pasted_in_chat(tmp_path, monkeypatch):
    import src.data.kaggle_source as ks

    monkeypatch.setattr(ks, "KAGGLE_JSON", tmp_path / "absent.json")
    monkeypatch.delenv("KAGGLE_USERNAME", raising=False)
    monkeypatch.delenv("KAGGLE_KEY", raising=False)
    with pytest.raises(KaggleCredentialError) as e:
        ks.configure_credentials()
    assert "Do not paste a key into a chat" in str(e.value)


def test_hash_mismatch_redownloads_rather_than_using_the_cache(tmp_path):
    archive = tmp_path / "data.zip"
    archive.write_bytes(b"original contents")
    pinned = DatasetProvenance(slug="o/s", kind="dataset", version="3",
                               sha256=sha256_file(archive))

    # unchanged file is used as-is
    assert verify_or_redownload(archive, pinned, downloader=lambda p: None) == archive

    # a mirror silently replaces the archive
    archive.write_bytes(b"different contents entirely")
    calls = []

    def downloader(path):
        calls.append(path)
        path.write_bytes(b"original contents")

    verify_or_redownload(archive, pinned, downloader=downloader)
    assert len(calls) == 1, "a cached file failing its hash must be re-downloaded, not used"


def test_drift_warns_but_never_auto_upgrades(monkeypatch, capsys):
    import src.data.kaggle_source as ks

    pinned = DatasetProvenance(slug="o/s", kind="dataset", version="3", sha256="a" * 64)
    monkeypatch.setattr(ks, "current_version", lambda slug, kind="dataset": "4")

    drifted, msg = ks.check_drift(pinned)
    assert drifted is True
    assert "NOT upgrading automatically" in msg
    assert pinned.version == "3", "the pin must not be mutated by the check"
    assert "DATASET DRIFT" in capsys.readouterr().out


def test_drift_can_be_made_fatal(monkeypatch):
    import src.data.kaggle_source as ks

    pinned = DatasetProvenance(slug="o/s", kind="dataset", version="3", sha256="a" * 64)
    monkeypatch.setattr(ks, "current_version", lambda slug, kind="dataset": "4")
    with pytest.raises(ks.DatasetDrift):
        ks.check_drift(pinned, fail=True)


def test_matching_version_reports_no_drift(monkeypatch):
    import src.data.kaggle_source as ks

    pinned = DatasetProvenance(slug="o/s", kind="dataset", version="3", sha256="a" * 64)
    monkeypatch.setattr(ks, "current_version", lambda slug, kind="dataset": "3")
    assert ks.check_drift(pinned)[0] is False


def test_provenance_round_trips(tmp_path):
    recs = {
        "o/s": DatasetProvenance(slug="o/s", kind="dataset", version="3", sha256="a" * 64,
                                 license="CC BY-NC-SA 4.0"),
        "m/h": DatasetProvenance(slug="m/h", kind="model", version="1", sha256=None,
                                 handle="m/h/pytorch/x/1"),
    }
    path = DatasetProvenance.save_all(recs, tmp_path / "prov.json")
    back = DatasetProvenance.load(path)
    assert back["o/s"].license == "CC BY-NC-SA 4.0"
    assert back["m/h"].kind == "model", "pretrained weights are pinned like data"
