"""The 2019-artifact compatibility shims (skill: reproducibility of the generator).

These run without `steganogan` installed: what they pin is that every global the
shim touches is put back. A leaked `torch.load` override would silently disable
`weights_only` for every checkpoint load in the process, which is a security
property, not a convenience one.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

torch = pytest.importorskip("torch")

from src.models.embedding.deep import INSTALL_HINT, SteganoGANWrapper


def test_shims_are_reverted_on_exit():
    load_before = torch.load
    setstate_before = torch.optim.Optimizer.__setstate__
    with SteganoGANWrapper.legacy_compat():
        assert torch.load is not load_before, "torch.load was not shimmed"
        assert torch.optim.Optimizer.__setstate__ is not setstate_before
    assert torch.load is load_before, "torch.load leaked out of the context"
    assert torch.optim.Optimizer.__setstate__ is setstate_before


def test_shims_are_reverted_even_if_the_body_raises():
    load_before = torch.load
    with pytest.raises(RuntimeError):
        with SteganoGANWrapper.legacy_compat():
            raise RuntimeError("boom")
    assert torch.load is load_before, "a failed load must still restore torch.load"


def test_weights_only_default_is_flipped_inside_the_context(tmp_path):
    """The torch>=2.6 default is what rejects the pretrained .steg files."""
    seen = {}
    original = torch.load

    def spy(*args, **kwargs):
        seen.update(kwargs)
        return original(*args, **kwargs)

    torch.load = spy
    try:
        p = tmp_path / "x.pt"
        torch.save({"a": torch.zeros(1)}, p)
        with SteganoGANWrapper.legacy_compat():
            torch.load(p)
        assert seen.get("weights_only") is False
    finally:
        torch.load = original


def test_legacy_optimizer_state_without_defaults_unpickles():
    """Reproduces 'Adam object has no attribute defaults' from a torch-1.0 pickle.

    The instance must be created WITHOUT __init__ -- that is what the unpickler
    does, and it is why `self.defaults` is absent. Constructing a real Adam and
    calling __setstate__ on it does not reproduce the bug, because __init__ has
    already set `defaults`.
    """
    m = torch.nn.Linear(2, 2)
    reference = torch.optim.Adam(m.parameters())
    state = {k: v for k, v in reference.__getstate__().items() if k != "defaults"}

    raw = torch.optim.Adam.__new__(torch.optim.Adam)      # as the unpickler builds it
    assert not hasattr(raw, "defaults")
    with pytest.raises(AttributeError, match="defaults"):
        raw.__setstate__(dict(state))

    with SteganoGANWrapper.legacy_compat():
        patched = torch.optim.Adam.__new__(torch.optim.Adam)
        patched.__setstate__(dict(state))                 # must not raise
        # The shim supplies an empty defaults; torch's own __setstate__ then
        # populates it (e.g. 'differentiable'), which is exactly what should
        # happen -- the point is only that the attribute exists in time.
        assert isinstance(patched.defaults, dict)


def test_install_hint_names_the_real_cause():
    """The hint must not send anyone chasing --ignore-requires-python again."""
    assert "missing comma" in INSTALL_HINT
    assert "tools/install_steganogan.py" in INSTALL_HINT
    assert "24.1" in INSTALL_HINT


def test_wrapper_refuses_to_substitute_a_generator(monkeypatch):
    monkeypatch.setitem(sys.modules, "steganogan", None)
    with pytest.raises((ImportError, TypeError, AttributeError)):
        SteganoGANWrapper(variant="dense", device="cpu")


def test_variant_is_validated():
    with pytest.raises(ValueError, match="variant must be one of"):
        SteganoGANWrapper(variant="nonexistent")
