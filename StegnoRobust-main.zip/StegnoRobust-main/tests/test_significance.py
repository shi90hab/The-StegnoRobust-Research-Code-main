import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from src.evaluation.significance import aggregate_seeds, claim_supported, holm_correct, paired_test


def test_claim_rejected_when_margin_is_within_seed_noise():
    """R2-7: 'overinterpreted' claims must not pass."""
    a = [0.71, 0.68, 0.75, 0.66, 0.73]
    b = [0.70, 0.69, 0.74, 0.65, 0.72]
    ok, msg = claim_supported(a, b)
    assert ok is False
    assert "spread" in msg or "not supported" in msg


def test_claim_accepted_for_a_large_consistent_margin():
    a = [0.95, 0.94, 0.96, 0.95, 0.94]
    b = [0.60, 0.61, 0.59, 0.62, 0.60]
    ok, msg = claim_supported(a, b)
    assert ok is True and "supported" in msg


def test_holm_correction_is_monotone_and_conservative():
    tests = [
        paired_test("m1", [0.9] * 5, "base", [0.5, 0.51, 0.49, 0.5, 0.52]),
        paired_test("m2", [0.8] * 5, "base", [0.5, 0.51, 0.49, 0.5, 0.52]),
        paired_test("m3", [0.55] * 5, "base", [0.5, 0.51, 0.49, 0.5, 0.52]),
    ]
    holm_correct(tests)
    for t in tests:
        assert t.p_adjusted >= t.p_value


def test_aggregate_uses_t_interval_not_normal():
    agg = aggregate_seeds("x", [0.9, 0.91, 0.89, 0.92, 0.88])
    half = agg.ci_hi - agg.mean
    normal_half = 1.96 * agg.std / np.sqrt(5)
    assert half > normal_half, "with n=5 the t interval must be wider than the normal one"
