"""Tests for the properties skill §12 requires, and that a reviewer would probe.

Each test corresponds to an audit row: budget persistence (17), split isolation
(16), thrash suppression, and the intervention log (18).
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from src.supervision import log as ilog
from src.supervision.patch_stub import PatchRefused, apply_patch, validate_override
from src.supervision.supervisor import (
    Patch,
    Supervisor,
    SupervisorState,
    TestSplitVisible,
    assert_no_test_split,
    propose_patch,
)
from src.supervision.triggers import TriggerConfig, evaluate_triggers


# ---------------------------------------------------------------- split isolation


@pytest.mark.parametrize("key", ["test_loader", "X_test", "test_ds", "holdout_test", "y_test"])
def test_supervisor_refuses_any_test_artifact(key):
    with pytest.raises(TestSplitVisible):
        assert_no_test_split({"val_loader": 1, key: 2})


def test_nested_test_artifacts_are_caught():
    with pytest.raises(TestSplitVisible):
        assert_no_test_split({"loaders": {"train": 1, "test": 2}})


def test_validation_only_scope_passes():
    assert_no_test_split({"train_loader": 1, "val_loader": 2, "lr": 1e-3, "latest_epoch": 4})


# ---------------------------------------------------------------- trip conditions


def test_divergence_fires_immediately_and_ignores_the_thrash_guard():
    hist = [{"epoch": i, "train_loss": 0.5, "val_auc": 0.8} for i in range(10)]
    hist.append({"epoch": 10, "train_loss": 99.0, "val_auc": 0.8})
    ev = evaluate_triggers(hist, TriggerConfig(), last_intervention_epoch=10)
    assert ev is not None and ev.name == "divergence" and ev.severity == "immediate"


def test_nan_loss_is_divergence():
    hist = [{"epoch": 0, "train_loss": float("nan"), "val_auc": 0.8}]
    assert evaluate_triggers(hist, TriggerConfig()).name == "divergence"


def test_chance_level_run_trips_underperformance_at_warmup():
    """The submitted paper's actual failure: loss falls, AUC sits at chance."""
    hist = [{"epoch": i, "train_loss": 0.7 - i * 0.01, "val_auc": 0.50} for i in range(25)]
    ev = evaluate_triggers(hist, TriggerConfig(warmup_epochs=20))
    assert ev.name == "underperformance"
    assert ev.suggested_category == "method_altering"


def test_healthy_run_trips_nothing():
    hist = [{"epoch": i, "train_loss": 0.7 - i * 0.02, "val_auc": 0.5 + i * 0.02} for i in range(25)]
    assert evaluate_triggers(hist, TriggerConfig()) is None


def test_thrash_guard_suppresses_a_recent_intervention():
    hist = [{"epoch": i, "train_loss": 0.5, "val_auc": 0.9} for i in range(25)]
    cfg = TriggerConfig(min_epochs_between_interventions=10)
    assert evaluate_triggers(hist, cfg, last_intervention_epoch=None) is not None
    assert evaluate_triggers(hist, cfg, last_intervention_epoch=20) is None


# ---------------------------------------------------------------- budget


def test_budget_is_enforced_after_three_rounds():
    st = SupervisorState(round=3, max_rounds=3)
    ok, why = st.can_intervene()
    assert ok is False and "budget exhausted" in why


def test_budget_survives_a_checkpoint_round_trip():
    """A Colab reconnect must not reset the counter."""
    st = SupervisorState(round=2, max_rounds=3, last_intervention_epoch=40,
                         applied_patch_hashes=["abc"])
    ckpt = {"extra": {"supervisor": st.to_checkpoint_extra()}}
    restored = SupervisorState.from_checkpoint(ckpt)
    assert restored.round == 2
    assert restored.last_intervention_epoch == 40
    assert restored.applied_patch_hashes == ["abc"]
    assert restored.can_intervene()[0] is True
    restored.round = 3
    assert restored.can_intervene()[0] is False


def test_equivalent_patch_is_not_reapplied():
    hist = [{"epoch": i, "train_loss": 0.5, "val_auc": 0.9} for i in range(25)]
    ev = evaluate_triggers(hist, TriggerConfig())
    patch = propose_patch(ev, {"lr": 1e-3})
    st = SupervisorState(applied_patch_hashes=[patch.sha256])
    assert st.already_tried(patch)

    sup = Supervisor(repo=".", trigger_cfg=TriggerConfig(), dry_run=True)
    _, proposed, reason = sup.decide(hist, st, {"lr": 1e-3})
    assert proposed is None and "thrash" in reason


# ---------------------------------------------------------------- patch safety


def test_patch_cannot_override_arbitrary_config_keys():
    validate_override({"detector.optim.lr": 1e-4})
    with pytest.raises(PatchRefused):
        validate_override({"paths.outputs": "/tmp/elsewhere"})
    with pytest.raises(PatchRefused):
        validate_override({"split.fractions": [0.9, 0.05, 0.05]})


def test_unified_diff_patches_are_not_auto_applied():
    p = Patch(kind="unified_diff", body="--- a\n+++ b\n", category="mechanical", summary="x")
    _, msg = apply_patch(p, {}, SupervisorState())
    assert msg.startswith("refused")


def test_patch_is_refused_once_the_budget_is_gone():
    p = Patch(kind="config_override", body=json.dumps({"detector.optim.lr": 1e-5}),
              category="mechanical", summary="lower lr")
    _, msg = apply_patch(p, {}, SupervisorState(round=3, max_rounds=3))
    assert msg.startswith("refused") and "budget" in msg


def test_method_altering_patches_are_tagged_not_hidden():
    hist = [{"epoch": i, "train_loss": 0.5, "val_auc": 0.5} for i in range(25)]
    ev = evaluate_triggers(hist, TriggerConfig(warmup_epochs=20))
    patch = propose_patch(ev, {"lr": 1e-3})
    assert patch.category == "method_altering"


# ---------------------------------------------------------------- intervention log


def test_intervention_log_round_trips_and_summarises(tmp_path):
    p = tmp_path / "agent_interventions.jsonl"
    ilog.append(
        ilog.Intervention.now(
            round=1, trigger="plateau", rule="no val_auc gain > 0.001 for 8 epochs",
            category="mechanical", files=["configs/"], diff_summary="lr 1e-3 -> 3.3e-4",
            val_before=0.83, patch_sha256="aaa",
        ), p,
    )
    ilog.append(
        ilog.Intervention.now(
            round=2, trigger="underperformance", rule="below convergence gate",
            category="method_altering", files=["src/models/yenet.py"],
            diff_summary="froze the SRM front end", val_before=0.50, patch_sha256="bbb",
        ), p,
    )
    ilog.update_outcome("bbb", val_after=0.91, path=p)

    entries = ilog.read(p)
    assert len(entries) == 2
    assert entries[1].val_after == 0.91 and entries[1].applied is True

    summary = ilog.method_altering_diff_summary(p)
    assert "method-altering" in summary
    assert "froze the SRM front end" in summary
    assert "0.5000 -> 0.9100" in summary
    # A mechanical edit must NOT appear in the methods-section warning.
    assert "lr 1e-3" not in summary


def test_clean_log_says_the_methods_section_is_accurate(tmp_path):
    assert "describes what ran" in ilog.method_altering_diff_summary(tmp_path / "none.jsonl")


# ---------------------------------------------------------------- integration


def test_full_supervisor_loop_publishes_and_the_stub_applies(tmp_path):
    """Watcher decides and publishes; stub fetches and applies. No runtime is touched."""
    pytest.importorskip("omegaconf")
    import subprocess

    if subprocess.run(["git", "--version"], capture_output=True).returncode != 0:
        pytest.skip("git not available")

    from omegaconf import OmegaConf

    from src.supervision.patch_stub import fetch_patches
    from src.utils.git_provenance import ensure_repo, git

    repo = ensure_repo(tmp_path / "paper")
    git("config", "user.email", "t@e.com", repo=repo)
    git("config", "user.name", "T", repo=repo)
    (repo / "README.md").write_text("paper")
    git("add", "-A", repo=repo)
    git("commit", "-m", "init", repo=repo)

    logp = tmp_path / "interventions.jsonl"
    sup = Supervisor(repo=repo, trigger_cfg=TriggerConfig(warmup_epochs=20),
                     log_path=logp, detector="yenet")

    # The submitted study's failure: training loss falls while validation AUC
    # stays at chance for 25 epochs.
    hist = [{"epoch": i, "train_loss": 0.7 - i * 0.01, "val_auc": 0.50} for i in range(25)]
    state, patch, reason = sup.step(hist, SupervisorState(max_rounds=3), {"lr": 1e-3},
                                    seed=0, config_hash="abc1234")
    assert patch is not None and patch.category == "method_altering"
    assert state.round == 1

    published = fetch_patches(repo)
    assert len(published) == 1 and published[0].sha256 == patch.sha256

    cfg = OmegaConf.create({
        "detector": {"paired_batching": False, "optim": {"lr": 1e-3, "warmup_epochs": 0},
                     "yenet": {"arch": {"trainable_srm": True}},
                     "srnet": {"curriculum": {"enabled": False}}},
        "hparams": {"augment": False},
    })
    stub_state = SupervisorState(max_rounds=3)
    cfg, msg = apply_patch(published[0], cfg, stub_state)
    assert msg.startswith("applied") and "METHOD-ALTERING" in msg
    assert cfg.detector.paired_batching is True
    assert cfg.detector.yenet.arch.trainable_srm is False
    assert cfg.detector.srnet.curriculum.enabled is True

    # Idempotent: the same patch is not applied twice.
    assert apply_patch(published[0], cfg, stub_state)[1].startswith("skipped")

    body = git("log", "agent/patches", "-1", "--pretty=%B", repo=repo).stdout
    assert "trigger: agent_patch" in body and "agent_revision: 1/3" in body
    assert "nan" not in body


# ---------------------------------------------------------------- W&B history parsing


RAW_HISTORY = [
    {"_step": 0, "epoch": 0, "_runtime": 12.0,
     "xunet/val_auc": 0.51, "xunet/train_loss": 0.70,
     "yenet/val_auc": 0.99, "yenet/train_loss": 0.31,
     "srnet/val_auc": 0.50, "srnet/train_loss": 0.69},
    {"_step": 1, "epoch": 1, "_runtime": 25.0,
     "xunet/val_auc": 0.52, "xunet/train_loss": 0.66,
     "yenet/val_auc": 1.00, "yenet/train_loss": 0.12,
     "srnet/val_auc": 0.50, "srnet/train_loss": 0.68},
]


def test_history_is_scoped_to_the_named_detector():
    """All detectors log into ONE run under their own prefix. Stripping the prefix
    unconditionally would make a supervisor watching SRNet read YeNet's curve."""
    srnet = Supervisor.parse_history(RAW_HISTORY, detector="srnet")
    assert [r["val_auc"] for r in srnet] == [0.50, 0.50]
    assert [r["train_loss"] for r in srnet] == [0.69, 0.68]

    yenet = Supervisor.parse_history(RAW_HISTORY, detector="yenet")
    assert [r["val_auc"] for r in yenet] == [0.99, 1.00]
    assert yenet[0]["val_auc"] != srnet[0]["val_auc"], "series must not be merged"


def test_unscoped_history_keeps_full_keys_rather_than_guessing():
    rows = Supervisor.parse_history(RAW_HISTORY, detector=None)
    assert "xunet/val_auc" in rows[0] and "srnet/val_auc" in rows[0]
    assert "val_auc" not in rows[0], "an unscoped read must not collapse three series into one"


def test_shared_keys_reach_every_detector():
    for det in ("xunet", "yenet", "srnet"):
        rows = Supervisor.parse_history(RAW_HISTORY, detector=det)
        assert [r["epoch"] for r in rows] == [0.0, 1.0]


def test_test_metrics_are_dropped_before_any_decision():
    raw = [{"epoch": 0, "srnet/val_auc": 0.5, "srnet/test_auc": 0.97, "test_loss": 0.1}]
    rows = Supervisor.parse_history(raw, detector="srnet")
    assert "test_auc" not in rows[0] and "test_loss" not in rows[0]
    assert rows[0]["val_auc"] == 0.5


def test_non_numeric_and_bookkeeping_only_rows_are_ignored():
    raw = [
        {"_step": 5, "_runtime": 3.0},                       # bookkeeping only
        {"epoch": 2, "srnet/val_auc": 0.8, "note": "hello"},  # string dropped
        {"epoch": 3, "srnet/converged": True},                # bool is not a metric
    ]
    rows = Supervisor.parse_history(raw, detector="srnet")
    assert len(rows) == 2
    assert "note" not in rows[0] and rows[0]["val_auc"] == 0.8
    assert "converged" not in rows[1]


def test_parsed_history_feeds_the_triggers_correctly():
    """End to end: raw W&B rows -> parse -> trigger, on the submitted failure mode."""
    raw = [{"epoch": i, "srnet/train_loss": 0.7 - i * 0.01, "srnet/val_auc": 0.50,
            "yenet/val_auc": 0.99} for i in range(25)]
    rows = Supervisor.parse_history(raw, detector="srnet")
    ev = evaluate_triggers(rows, TriggerConfig(warmup_epochs=20))
    assert ev is not None and ev.name == "underperformance"

    # The same rows read as YeNet must NOT fire underperformance.
    rows_y = Supervisor.parse_history(raw, detector="yenet")
    ev_y = evaluate_triggers(rows_y, TriggerConfig(warmup_epochs=20))
    assert ev_y is None or ev_y.name != "underperformance"


@pytest.mark.parametrize("key,blocked", [
    ("srnet/test_auc", True),      # namespaced -- the format the trainer actually logs
    ("data.test_split", True),     # dotted config key
    ("test_loss", True),
    ("holdout_test", True),
    ("X_test", True),
    ("test", True),
    ("val_auc", False),
    ("yenet/val_auc", False),
    ("latest_epoch", False),       # contains "test" but is not a test key
    ("contest_score", False),
    ("fastest", False),
])
def test_test_pattern_boundaries(key, blocked):
    """The guard must treat '/' and '.' as boundaries, not just '_'.

    An underscore-only boundary let every namespaced test metric through -- and
    this regex is the single thing preventing the supervisor from observing the
    test split.
    """
    from src.supervision.supervisor import _TEST_PATTERNS

    assert bool(_TEST_PATTERNS.search(key)) is blocked
