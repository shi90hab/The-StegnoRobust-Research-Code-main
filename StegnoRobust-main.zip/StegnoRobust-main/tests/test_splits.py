import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.covers import deterministic_group_split


def test_split_is_group_disjoint_and_stable():
    groups = [f"img{i:04d}" for i in range(500)]
    a = deterministic_group_split(groups)
    b = deterministic_group_split(groups)
    assert a == b, "hash-based split must be reproducible without a saved index"

    # adding images must not reshuffle existing assignments
    more = deterministic_group_split(groups + [f"img{i:04d}" for i in range(500, 700)])
    assert all(more[g] == a[g] for g in groups)


def test_split_fractions_are_approximately_respected():
    groups = [f"img{i:05d}" for i in range(5000)]
    a = deterministic_group_split(groups, (0.7, 0.15, 0.15))
    counts = {s: sum(1 for v in a.values() if v == s) for s in ("train", "val", "test")}
    assert abs(counts["train"] / 5000 - 0.7) < 0.02
    assert abs(counts["test"] / 5000 - 0.15) < 0.02


def test_different_salt_gives_a_different_split():
    groups = [f"img{i:04d}" for i in range(1000)]
    a = deterministic_group_split(groups, salt="run-a")
    b = deterministic_group_split(groups, salt="run-b")
    disagree = sum(1 for g in groups if a[g] != b[g])
    assert disagree > 100, "repeated random splits must actually differ"
