"""Tests for skill §11: token hygiene, commit policy, provenance messages.

The token tests matter most. A credential written into .git/config is not
recoverable by deleting a message; it has to be revoked. These assertions make
that mistake fail loudly at the next push rather than silently at publication.
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from src.utils.git_provenance import (
    GITIGNORE_REQUIRED,
    CommitProvenance,
    TokenLeak,
    assert_token_not_persisted,
    commit_and_push,
    config_hash,
    ensure_repo,
    git,
)

HAS_GIT = subprocess.run(["git", "--version"], capture_output=True).returncode == 0
pytestmark = pytest.mark.skipif(not HAS_GIT, reason="git not available")


@pytest.fixture
def repo(tmp_path):
    r = ensure_repo(tmp_path / "paper")
    git("config", "user.email", "test@example.com", repo=r)
    git("config", "user.name", "Test", repo=r)
    return r


def test_commit_message_carries_full_provenance():
    m = CommitProvenance(
        metric_name="val_auc", metric_value=0.8412, previous_best=0.8377, epoch=37,
        seed=42, config_hash="a3f9c1e", wandb_run="3kx9m2p1", trigger="new_best_val",
        agent_revision="2/3", detector="yenet",
    ).message()
    assert m.startswith("best: [yenet] val_auc 0.8412 (prev 0.8377) @ epoch 37")
    for field in ("seed: 42", "config_hash: a3f9c1e", "wandb_run: 3kx9m2p1",
                  "trigger: new_best_val", "agent_revision: 2/3"):
        assert field in m


def test_agent_revision_is_omitted_when_no_agent_ran():
    m = CommitProvenance("val_auc", 0.9, None, 3, 0, "abc", None, "new_best_val").message()
    assert "agent_revision" not in m
    assert "(first)" in m and "wandb_run: n/a" in m


def test_config_hash_is_stable_and_order_independent():
    a = config_hash({"lr": 1e-3, "seed": 0})
    b = config_hash({"seed": 0, "lr": 1e-3})
    assert a == b and len(a) == 7
    assert config_hash({"lr": 1e-4, "seed": 0}) != a


def test_ensure_repo_sets_lfs_and_ignores_intermediate_checkpoints(repo):
    attrs = (repo / ".gitattributes").read_text()
    assert "filter=lfs" in attrs and "_best.pt" in attrs
    ignore = (repo / ".gitignore").read_text().splitlines()
    for required in GITIGNORE_REQUIRED:
        assert required in ignore
    # every *.pt is ignored except the best model
    assert "*.pt" in ignore and "!*_best.pt" in ignore


def test_token_in_git_config_is_detected(repo):
    cfg = repo / ".git" / "config"
    cfg.write_text(cfg.read_text() + "\n\turl = https://ghp_" + "a" * 36 + "@github.com/x/y.git\n")
    with pytest.raises(TokenLeak) as e:
        assert_token_not_persisted(repo)
    assert "REVOKE" in str(e.value)


def test_fine_grained_token_pattern_is_detected(repo):
    cfg = repo / ".git" / "config"
    cfg.write_text(cfg.read_text() + "\n\tpassword = github_pat_" + "b" * 30 + "\n")
    with pytest.raises(TokenLeak):
        assert_token_not_persisted(repo)


def test_clean_repo_passes_the_token_check(repo):
    assert_token_not_persisted(repo)


def test_commit_on_new_best_records_a_sha(repo):
    (repo / "result.txt").write_text("val_auc 0.91")
    sha = commit_and_push(
        repo, ["result.txt"],
        CommitProvenance("val_auc", 0.91, 0.88, 12, 0, "abc1234", None, "new_best_val"),
        push=False,
    )
    assert sha and len(sha) == 40
    body = git("log", "-1", "--pretty=%B", repo=repo).stdout
    assert "seed: 0" in body and "trigger: new_best_val" in body


def test_nothing_to_commit_returns_none_rather_than_an_empty_commit(repo):
    (repo / "a.txt").write_text("x")
    commit_and_push(repo, ["a.txt"],
                    CommitProvenance("val_auc", 0.5, None, 0, 0, "h", None, "new_best_val"),
                    push=False)
    again = commit_and_push(repo, ["a.txt"],
                            CommitProvenance("val_auc", 0.5, None, 1, 0, "h", None, "new_best_val"),
                            push=False)
    assert again is None, "an unchanged tree must not produce an empty provenance commit"
