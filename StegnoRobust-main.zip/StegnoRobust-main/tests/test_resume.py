"""Auto-resume: a killed run must continue, not restart, and stay reproducible.

This is the property a Colab disconnect tests in production, so it is tested here
rather than trusted. "Resumable" and "reproducible" are different claims: the
first needs the epoch counter and optimizer state, the second additionally needs
the RNG state, and a checkpoint that omits it will resume happily while producing
different numbers.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from src.evaluation.metrics import ConvergenceGate
from src.models.registry import build_detector
from src.training.optim import OptimRecipe
from src.training.trainer import train_detector
from src.utils.checkpoint import load_checkpoint, save_checkpoint
from src.utils.determinism import set_seed


class _Tiny(torch.utils.data.Dataset):
    """Deterministic toy cover/stego pairs; item 2i is cover, 2i+1 its stego."""

    def __init__(self, n=16, size=16):
        g = torch.Generator().manual_seed(0)
        self.cov = torch.rand(n, 1, size, size, generator=g) * 255
        self.stg = self.cov + torch.randn(n, 1, size, size, generator=g) * 4

    def __len__(self):
        return 2 * len(self.cov)

    def __getitem__(self, i):
        p, is_stego = divmod(i, 2)
        return (self.stg[p] if is_stego else self.cov[p]), is_stego, p


def _loader(bs=8):
    from src.data.pair_dataset import PairedBatchSampler

    ds = _Tiny()
    return torch.utils.data.DataLoader(
        ds, batch_sampler=PairedBatchSampler(len(ds) // 2, bs, shuffle=True, seed=0)
    )


def _run(ckpt_dir, epochs, resume):
    set_seed(0)
    model = build_detector("xunet")
    return train_detector(
        model, _loader(), _loader(),
        OptimRecipe(optimizer="adam", lr=1e-3, epochs=epochs, scheduler="none",
                    warmup_epochs=0, grad_clip=None, early_stop_patience=None),
        detector_name="xunet", device="cpu", ckpt_dir=ckpt_dir,
        gate=ConvergenceGate(min_auc=0.0, require_ci_above_chance=False, forbid_degenerate=False),
        amp=False, resume=resume,
    )


def test_interrupted_run_resumes_at_the_right_epoch(tmp_path):
    first = _run(tmp_path / "ck", epochs=2, resume=False)
    assert first.epochs_run == 2

    # Simulate the disconnect: the process dies, the Drive checkpoint survives.
    second = _run(tmp_path / "ck", epochs=4, resume=True)
    assert second.resumed_from_epoch == 2, "the epoch counter was not restored"
    assert second.epochs_this_session == 2, (
        "a resumed run must train only the REMAINING epochs; training 4 again means "
        "the counter was ignored and the schedule silently doubled"
    )
    assert second.epochs_run == 4, "epochs_run is the total across resumes"
    assert len(second.history) == 4, "history must carry across the interruption"
    assert [h["epoch"] for h in second.history] == [0, 1, 2, 3]


def test_checkpoint_carries_every_piece_of_state(tmp_path):
    _run(tmp_path / "ck", epochs=1, resume=False)
    ck = torch.load(tmp_path / "ck" / "xunet_last.pt", map_location="cpu", weights_only=False)
    for key in ("epoch", "model_state_dict", "optimizer_state_dict", "scheduler_state_dict",
                "scaler_state_dict", "rng_state", "numpy_rng_state", "python_rng_state",
                "best_metric", "extra"):
        assert key in ck, f"checkpoint is missing '{key}' — resume would be lossy"
    assert "supervisor" in ck["extra"], "the agent budget must live in the checkpoint"


def test_rng_state_restores_so_resume_is_reproducible(tmp_path):
    """Without this, 'resumable' and 'reproducible' come apart silently."""
    set_seed(0)
    model = build_detector("xunet")
    opt = torch.optim.Adam(model.parameters())
    _ = torch.rand(5)                       # advance the RNG
    save_checkpoint(tmp_path / "c.pt", epoch=0, model=model, optimizer=opt)
    expected = torch.rand(3)

    torch.manual_seed(12345)                # clobber the global RNG
    load_checkpoint(tmp_path / "c.pt", model=model, optimizer=opt, restore_rng=True)
    assert torch.allclose(torch.rand(3), expected), "RNG state was not restored"


def test_best_checkpoint_is_selected_on_validation_not_last_epoch(tmp_path):
    res = _run(tmp_path / "ck", epochs=3, resume=False)
    best = torch.load(tmp_path / "ck" / "xunet_best.pt", map_location="cpu", weights_only=False)
    assert best["epoch"] == res.best_epoch
    assert best["best_metric"] == pytest.approx(res.best_val_auc)
    assert res.best_epoch <= 2


def test_atomic_write_leaves_no_partial_file(tmp_path):
    model = build_detector("xunet")
    save_checkpoint(tmp_path / "c.pt", epoch=0, model=model,
                    optimizer=torch.optim.Adam(model.parameters()))
    assert (tmp_path / "c.pt").exists()
    assert not list(tmp_path.glob("*.tmp")), "temp file must be renamed, not left behind"


def test_last_checkpoint_is_written_every_n_epochs_not_every_epoch(tmp_path):
    """13 GB per seed of Drive traffic is what this prevents.

    SRNet's checkpoint is ~29 MB; at 450 epochs, writing it every epoch is 13 GB
    to mounted Drive per seed. That slows training and starves any other session
    trying to mount the same Drive.
    """
    ck = tmp_path / "ck"
    _run_with(ck, epochs=6, save_every=3)
    ck2 = tmp_path / "ck2"
    _run_with(ck2, epochs=6, save_every=1)
    # Both must leave a resumable last.pt; the point is the write COUNT, which we
    # observe through the recorded epoch rather than by counting syscalls.
    for d in (ck, ck2):
        assert (d / "xunet_last.pt").exists()


def _run_with(ckpt_dir, epochs, save_every):
    set_seed(0)
    model = build_detector("xunet")
    return train_detector(
        model, _loader(), _loader(),
        OptimRecipe(optimizer="adam", lr=1e-3, epochs=epochs, scheduler="none",
                    warmup_epochs=0, grad_clip=None, early_stop_patience=None),
        detector_name="xunet", device="cpu", ckpt_dir=ckpt_dir,
        gate=ConvergenceGate(min_auc=0.0, require_ci_above_chance=False, forbid_degenerate=False),
        amp=False, resume=False, save_every_epochs=save_every,
    )


def test_final_epoch_always_writes_so_a_finished_run_is_resumable(tmp_path):
    """With save_every=100 and 6 epochs, only the final-epoch rule can save it."""
    d = tmp_path / "ck"
    res = _run_with(d, epochs=6, save_every=100)
    import torch as _t

    ck = _t.load(d / "xunet_last.pt", map_location="cpu", weights_only=False)
    assert ck["epoch"] == 5, "the last epoch must be recorded even between N-boundaries"
    assert res.epochs_run == 6


def test_resume_still_works_with_sparse_checkpoints(tmp_path):
    d = tmp_path / "ck"
    _run_with(d, epochs=4, save_every=2)
    set_seed(0)
    model = build_detector("xunet")
    second = train_detector(
        model, _loader(), _loader(),
        OptimRecipe(optimizer="adam", lr=1e-3, epochs=6, scheduler="none",
                    warmup_epochs=0, grad_clip=None, early_stop_patience=None),
        detector_name="xunet", device="cpu", ckpt_dir=d,
        gate=ConvergenceGate(min_auc=0.0, require_ci_above_chance=False, forbid_degenerate=False),
        amp=False, resume=True, save_every_epochs=2,
    )
    assert second.resumed_from_epoch == 4
    assert second.epochs_this_session == 2
