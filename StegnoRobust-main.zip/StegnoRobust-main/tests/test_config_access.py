"""Config-access regressions: the trap that killed Phase 1 on the first detector.

`DictConfig.get(key, {})` returns a PLAIN dict when the key is absent, and
`OmegaConf.to_container` rejects plain dicts with

    ValueError: Input cfg is not an OmegaConf config object (dict)

Worse, an EMPTY DictConfig is falsy, so the common idiom `node or {}` silently
swaps a perfectly good empty config for a plain dict and hits the same wall. Both
forms were in the entry points; the first fired on XuNet (no `curriculum` block,
and it trains first), the second was waiting in Phase 2 on the manuscript's own
PGD config (`extra: {}`).

These tests walk the real config files rather than a fixture, so a newly added
detector or attack that omits an optional block is caught here instead of six
hours into a GPU run.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

OmegaConf = pytest.importorskip("omegaconf").OmegaConf
ROOT = Path(__file__).resolve().parents[1]


def safe_container(node):
    """The correct idiom, mirrored from the entry points."""
    return OmegaConf.to_container(node, resolve=True) if node is not None else {}


def test_get_with_dict_default_is_the_trap_we_think_it_is():
    cfg = OmegaConf.create({"a": 1})
    with pytest.raises(ValueError, match="not an OmegaConf config object"):
        OmegaConf.to_container(cfg.get("missing", {}))


def test_empty_dictconfig_is_falsy_so_or_default_is_also_a_trap():
    cfg = OmegaConf.create({"extra": {}})
    assert not cfg.extra, "an empty DictConfig is falsy -- this is what breaks `node or {}`"
    with pytest.raises(ValueError):
        OmegaConf.to_container(cfg.get("extra", {}) or {})
    assert safe_container(cfg.get("extra", None)) == {}


@pytest.mark.parametrize("detector", ["xunet", "yenet", "srnet"])
def test_every_detector_survives_the_optional_curriculum_lookup(detector):
    det = OmegaConf.load(ROOT / "configs" / "detector" / "all.yaml")
    curr = safe_container(det[detector].get("curriculum", None))
    assert isinstance(curr, dict)
    if detector == "srnet":
        assert curr.get("enabled") is True, "srnet must keep its curriculum"
    else:
        assert curr == {}, f"{detector} has no curriculum block and must tolerate that"


@pytest.mark.parametrize("attack", ["pgd", "naa", "suite"])
def test_every_attack_survives_the_optional_extra_lookup(attack):
    cfg = OmegaConf.load(ROOT / "configs" / "attack" / f"{attack}.yaml")
    extra = safe_container(cfg.get("extra", None))
    assert isinstance(extra, dict)
    if attack == "naa":
        assert extra.get("naa_ig_steps"), "naa must keep its integrated-gradient steps"


def test_required_blocks_convert_for_every_detector():
    """arch and optim are mandatory, so a plain to_container must work on them."""
    det = OmegaConf.load(ROOT / "configs" / "detector" / "all.yaml")
    for name in ("xunet", "yenet", "srnet"):
        assert isinstance(OmegaConf.to_container(det[name].arch, resolve=True), dict)
        optim = OmegaConf.to_container(det[name].optim, resolve=True)
        assert optim["epochs"] > 0 and optim["lr"] > 0


def test_entry_points_no_longer_use_the_unsafe_idiom():
    """Grep-level guard: the pattern must not come back in a future edit."""
    for script in ("scripts/train_detectors.py", "scripts/run_attack.py"):
        text = (ROOT / script).read_text()
        assert 'to_container(dcfg.get("curriculum", {})' not in text
        assert 'to_container(cfg.attack.get("extra", {})' not in text


# ---------------------------------------------------------------- ablation scoping


DETECTOR_ABLATIONS = ["full_model", "no_paired_batching", "frozen_srm",
                      "no_zero_init", "no_curriculum", "no_augment"]


@pytest.mark.parametrize("name", DETECTOR_ABLATIONS)
def test_detector_ablations_declare_which_detectors_they_affect(name):
    """A row that trains a detector its change cannot touch isolates nothing.

    `frozen_srm` on SRNet costs ~50 GPU-minutes and cannot move the number,
    because SRNet has no SRM front end. The declaration is what makes the row an
    ablation rather than a coincidence.
    """
    cfg = OmegaConf.load(ROOT / "configs" / "ablation" / f"{name}.yaml")
    only = OmegaConf.to_container(cfg.get("only_detectors", None), resolve=True)
    assert only, f"{name} does not declare only_detectors"
    assert set(only) <= {"xunet", "yenet", "srnet"}, f"{name}: unknown detector in {only}"


def test_each_ablation_targets_the_detector_that_owns_the_changed_field():
    """The declared target must match the config key the ablation overrides."""
    owner = {"detector.yenet.": "yenet", "detector.srnet.": "srnet"}
    for name in DETECTOR_ABLATIONS:
        cfg = OmegaConf.load(ROOT / "configs" / "ablation" / f"{name}.yaml")
        only = set(OmegaConf.to_container(cfg.get("only_detectors"), resolve=True))
        for key in (OmegaConf.to_container(cfg.get("overrides", {})) or {}):
            for prefix, det in owner.items():
                if key.startswith(prefix):
                    assert only == {det}, (
                        f"{name} overrides {key} (owned by {det}) but targets {only}"
                    )


def test_attack_ablations_do_not_declare_detectors():
    """Attack-side rows re-use trained detectors; they train nothing."""
    for name in ("committee_mean", "committee_minmax", "committee_logit", "no_quantize"):
        cfg = OmegaConf.load(ROOT / "configs" / "ablation" / f"{name}.yaml")
        assert cfg.get("only_detectors", None) is None, f"{name} should not name detectors"


def test_ablation_checkpoints_are_namespaced(tmp_path):
    """The bug that made every ablation row repeat the baseline.

    With one shared checkpoint directory, an ablation loads the full_model
    weights, finds start_epoch already past its budget, trains nothing, and
    re-evaluates. The table then shows six rows of the same number and looks
    entirely reasonable.
    """
    root = Path("/ckpt")

    def ckpt_dir(ablation, seed):
        return (root / f"seed{seed}" if ablation == "full_model"
                else root / ablation / f"seed{seed}")

    paths = {a: ckpt_dir(a, 0) for a in
             ("full_model", "no_curriculum", "no_zero_init", "frozen_srm")}
    assert len(set(paths.values())) == len(paths), f"collision: {paths}"
    assert paths["full_model"] == root / "seed0", "the main grid path must not move"
    assert paths["no_curriculum"] == root / "no_curriculum" / "seed0"


def test_entry_point_namespaces_ablation_checkpoints():
    src = (ROOT / "scripts" / "train_detectors.py").read_text()
    assert 'cfg.ablation.name / f"seed{cfg.seed}"' in src
    assert "trained 0 epochs" in src, "the zero-epoch guard must be present"
