"""Download-free data preparation: crop covers, generate stego, verify splits.

    python scripts/prepare_data.py dataset=bsds500

Colab behaviour: the archive is staged from Drive to local disk exactly once
(src/utils/checkpoint.py::stage_dataset), because reading thousands of small
files from mounted Drive dominates epoch wall-clock.
"""
import _bootstrap  # noqa: F401

import json
from pathlib import Path

import hydra
from omegaconf import DictConfig

from src.data.covers import deterministic_group_split, list_source_images, make_crops
from src.data.fetch import fetch, stage
from src.utils.checkpoint import stage_dataset
from src.utils.determinism import set_seed


@hydra.main(version_base=None, config_path="../configs", config_name="main")
def main(cfg: DictConfig) -> None:
    set_seed(cfg.seed, deterministic=cfg.deterministic)

    root = Path(cfg.dataset.root)
    archive = Path(cfg.dataset.archive)

    # Download once, verify on every run. The digest is recorded on first use and
    # printed so it can be pinned in the dataset config -- a guessed hash written
    # ahead of time would turn verification into a lie.
    if not archive.exists() or cfg.dataset.get("sha256"):
        rec = fetch(
            cfg.dataset.name, archive.parent,
            expected_sha256=cfg.dataset.get("sha256"),
            provenance_path=Path(cfg.paths.metrics) / "source_provenance.json",
        )
        archive = Path(rec and archive)

    stage(archive, root / "raw")
    raw = root / "raw" if (root / "raw").exists() else root

    if cfg.dataset.get("caveat"):
        print("\n" + "-" * 72)
        print(f"COVER SOURCE NOTE ({cfg.dataset.name}, {cfg.dataset.get('source_format')})")
        print("-" * 72)
        print(str(cfg.dataset.caveat).strip())
        print("-" * 72 + "\n")

    sources = list_source_images(raw)
    print(f"{len(sources)} source images under {raw}")

    covers = make_crops(
        sources, root / "cover", size=cfg.dataset.crop_size,
        crops_per_image=cfg.dataset.crops_per_image, seed=cfg.seed,
        grayscale=cfg.dataset.grayscale,
    )
    print(f"{len(covers)} cover crops -> {root / 'cover'}")

    assign = deterministic_group_split(
        [c.group for c in covers], tuple(cfg.split.fractions), salt=f"{cfg.split.salt}:{cfg.seed}"
    )
    counts = {s: sum(1 for v in assign.values() if v == s) for s in ("train", "val", "test")}
    (root / "split.json").write_text(json.dumps(assign, indent=2))
    print(f"source-image split: {counts}  (written to {root / 'split.json'})")

    print(
        "\nNext: generate stego with the SteganoGAN wrapper or an embedder from\n"
        "src/models/embedding, writing PNGs to "
        f"{root}/stego_<method>/ using the SAME filenames as the covers.\n"
        "build_pairs() raises if any cover lacks a stego, so a partial run cannot\n"
        "silently unbalance the test set."
    )


if __name__ == "__main__":
    main()
