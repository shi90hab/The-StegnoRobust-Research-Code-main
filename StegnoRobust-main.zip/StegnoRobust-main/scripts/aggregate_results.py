"""Aggregate multi-seed runs into the paper's figures and LaTeX tables.

    python scripts/aggregate_results.py --metrics outputs/metrics --out outputs

Everything the manuscript prints is produced here from the JSON records. Nothing
is retyped, so Table 2 and Table 3 cannot disagree (Reviewer 1, comment 4).
"""
import _bootstrap  # noqa: F401

import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from src.evaluation.plots import (
    configure,
    plot_attack_comparison,
    plot_auc_vs_budget,
    plot_convergence,
    plot_pareto,
    plot_transfer_gap,
)
from src.evaluation.significance import aggregate_seeds, holm_correct, paired_test
from src.evaluation.tables import (
    table_attack_comparison,
    table_clean_detection,
    table_evasion_sweep,
)
from src.attacks.registry import ATTACK_CITATIONS


def load_json(p: Path):
    return json.loads(p.read_text())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--held-out", default="srnet")
    ap.add_argument("--committee", nargs="+", default=["xunet", "yenet"])
    args = ap.parse_args()

    configure()
    figs, tabs = args.out / "figures", args.out / "tables"

    # ---------------------------------------------------------- convergence
    hist = {}
    for f in sorted(args.metrics.glob("history_*_seed0.json")):
        hist[f.stem.split("_")[1]] = load_json(f)
    if hist:
        plot_convergence(hist, figs / "fig_convergence")

    # ------------------------------------------------- clean detection table
    # Ablation-tagged since the grid was added: detectors_<ablation>_seed<N>.json.
    # A glob written before that change matches nothing and silently produces an
    # empty table rather than an error, which is the worst of both worlds.
    det_files = sorted(args.metrics.glob("detectors_*seed*.json"))
    if det_files:
        per_det = defaultdict(list)
        roles, meta = {}, {}
        for f in det_files:
            d = load_json(f)["results"]
            for name, rec in d.items():
                per_det[name].append(rec["test"])
                roles[name] = rec["role"]
                meta[name] = rec
        rows = []
        for name, recs in per_det.items():
            agg = aggregate_seeds(name, [r["auc"] for r in recs])
            rows.append(
                {
                    "detector": name,
                    "role": roles[name],
                    "accuracy": float(np.mean([r["accuracy"] for r in recs])),
                    "auc": agg.mean,
                    "auc_lo": agg.ci_lo if np.isfinite(agg.ci_lo) else recs[0]["auc_lo"],
                    "auc_hi": agg.ci_hi if np.isfinite(agg.ci_hi) else recs[0]["auc_hi"],
                    "inverted": bool(np.mean([r["auc"] for r in recs]) < 0.5),
                    "fpr": float(np.mean([r["fpr"] for r in recs])),
                    "fnr": float(np.mean([r["fnr"] for r in recs])),
                    "md5": float(np.mean([r["md5"] for r in recs])),
                    "converged": bool(meta[name]["train"]["converged"]),
                }
            )
        committee_rows = [r for r in rows if r["detector"] in args.committee]
        failed = [r["detector"] for r in committee_rows if not r["converged"]]
        committee = (
            {"mean_auc": None,
             "reason": "committee mean suppressed: " + ", ".join(failed) +
                       " did not pass the convergence gate. Averaging a converged detector "
                       "with a chance-level one produces a number that describes neither."}
            if failed else
            {"mean_auc": float(np.mean([r["auc"] for r in committee_rows])),
             "reason": "all members converged"}
        )
        table_clean_detection(rows, committee, tabs / "table2_clean_detection.tex")

    # ------------------------------------------------------- evasion sweeps
    by_attack = defaultdict(list)
    for f in sorted(args.metrics.glob("evasion_*.json")):
        d = load_json(f)
        by_attack[d["attack"]["name"]].append(d)

    for attack, runs in by_attack.items():
        eps = [r["eps_level"] for r in runs[0]["rows"]]
        merged = []
        for i, _ in enumerate(eps):
            row = {"eps_level": eps[i]}
            row["psnr"] = float(np.mean([r["rows"][i]["psnr"] for r in runs]))
            for n in args.committee + [args.held_out]:
                row[f"auc_{n}"] = float(np.mean([r["rows"][i][f"auc_{n}"] for r in runs]))
            gaps = [r["rows"][i]["gap"] for r in runs]
            defined = all(r["rows"][i]["gap_defined"] for r in runs)
            row["gap"] = float(np.mean(gaps)) if defined and all(g is not None for g in gaps) else None
            row["gap_defined"] = defined
            merged.append(row)
        table_evasion_sweep(merged, tabs / f"table3_evasion_{attack}.tex")

        curves = {n: [m[f"auc_{n}"] for m in merged] for n in args.committee + [args.held_out]}
        plot_auc_vs_budget(eps, curves, out=figs / f"fig_auc_vs_budget_{attack}", heldout=args.held_out)
        plot_pareto([m["psnr"] for m in merged], curves, figs / f"fig_pareto_{attack}")
        plot_transfer_gap(eps, [m["gap"] for m in merged], [m["gap_defined"] for m in merged],
                          figs / f"fig_transfer_gap_{attack}")

    # ------------------------------------ head-to-head attack comparison table
    if len(by_attack) > 1:
        ref = "pgd" if "pgd" in by_attack else sorted(by_attack)[0]

        def at_max_eps(runs, key):
            return [r["rows"][-1][key] for r in runs]

        rows, tests = [], []
        wb_key = f"auc_{args.committee[-1]}"
        tr_key = f"auc_{args.held_out}"
        for attack, runs in sorted(by_attack.items()):
            wb = aggregate_seeds(attack, at_max_eps(runs, wb_key))
            tr = aggregate_seeds(attack, at_max_eps(runs, tr_key))
            rows.append(
                {
                    "attack": attack.upper(),
                    "citation": ATTACK_CITATIONS.get(attack, ""),
                    "wb_mean": wb.mean, "wb_std": wb.std,
                    "tr_mean": tr.mean, "tr_std": tr.std,
                    "asr": float(np.mean(at_max_eps(runs, f"asr_{args.committee[-1]}"))),
                    "psnr": float(np.mean(at_max_eps(runs, "psnr"))),
                    "p_adj": None,
                }
            )
            if attack != ref and len(runs) == len(by_attack[ref]) and len(runs) > 1:
                tests.append(paired_test(attack, at_max_eps(runs, tr_key),
                                         ref, at_max_eps(by_attack[ref], tr_key)))
        if tests:
            holm_correct(tests)
            pmap = {t.a: t.p_adjusted for t in tests}
            for r in rows:
                r["p_adj"] = pmap.get(r["attack"].lower())
        table_attack_comparison(rows, tabs / "table4_attack_comparison.tex")
        plot_attack_comparison([r["attack"] for r in rows], [r["tr_mean"] for r in rows],
                               [r["tr_std"] for r in rows], figs / "fig_attack_comparison")

    print(f"figures -> {figs}\ntables  -> {tabs}")


if __name__ == "__main__":
    main()
