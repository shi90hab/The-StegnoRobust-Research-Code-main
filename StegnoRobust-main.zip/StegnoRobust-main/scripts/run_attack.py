"""Evasion sweep with a guarded transferability gap.

    python scripts/run_attack.py attack=pgd seed=0
    python scripts/run_attack.py -m attack=pgd,naa seed=0,1,2,3,4

Answers:
  R1-2  epsilon -> PSNR conversion is explicit and both the algebraic floor and
        the measured value are written to the results record
  R1-3  one PSNR rounding rule; the claim checker consumes this output
  R1-5  the gap is emitted only when both sides passed the convergence gate
  R1-7  ditto, plus a paired DeLong test on the held-out detector
  R2-2  --attack selects any method in the suite, at a matched budget
"""
import _bootstrap  # noqa: F401

import json
from pathlib import Path

import hydra
import numpy as np
import torch
from omegaconf import DictConfig, OmegaConf

from src.attacks.base import AttackConfig
from src.attacks.registry import ATTACK_CITATIONS, build_attack
from src.attacks.common import format_psnr, psnr_empirical, psnr_worst_case
from src.data.covers import deterministic_group_split
from src.data.pair_dataset import PairDataset, PairedBatchSampler, build_pairs, split_pairs
from src.evaluation.metrics import ConvergenceGate, canonical_score, detection_report
from src.evaluation.transferability import attack_success_rate, transferability_gap
from src.models.registry import build_detector
from src.utils.checkpoint import load_checkpoint
from src.utils.determinism import Provenance, set_seed


def _load_detector(cfg, name, seed, device):
    model = build_detector(
        name, in_channels=cfg.detector.input_channels, num_classes=cfg.detector.num_classes,
        **OmegaConf.to_container(cfg.detector[name].arch),
    )
    ckpt = Path(cfg.paths.checkpoints) / f"seed{seed}" / f"{name}_best.pt"
    if not ckpt.exists():
        raise FileNotFoundError(
            f"{ckpt} not found. Run scripts/train_detectors.py first -- the attack must "
            "operate on the SELECTED checkpoint, not on a freshly initialised model."
        )
    load_checkpoint(ckpt, model=model, map_location=device, restore_rng=False)
    return model.to(device).eval()


@hydra.main(version_base=None, config_path="../configs", config_name="main")
def main(cfg: DictConfig) -> None:
    set_seed(cfg.seed, deterministic=cfg.deterministic)
    prov = Provenance.capture(cfg.seed)
    device = cfg.device if torch.cuda.is_available() else "cpu"

    # Ablations are configuration, not code branches: each file changes exactly one
    # field, applied here so the resolved config recorded with the run shows the
    # ablated value rather than the default.
    abl = cfg.get("ablation")
    if abl and abl.get("overrides"):
        for key, value in abl.overrides.items():
            OmegaConf.update(cfg, key, value, merge=True)
        print(f"[ablation] {abl.name}: " + ", ".join(f"{k}={v}" for k, v in abl.overrides.items()))

    out = Path(cfg.paths.metrics)
    out.mkdir(parents=True, exist_ok=True)

    members = [_load_detector(cfg, n, cfg.seed, device) for n in cfg.committee.members]
    held = _load_detector(cfg, cfg.committee.held_out, cfg.seed, device)
    gate = ConvergenceGate(**OmegaConf.to_container(cfg.convergence_gate))

    pairs = build_pairs(Path(cfg.dataset.root) / "cover",
                        Path(cfg.dataset.root) / f"stego_{cfg.embed.name}")
    assign = deterministic_group_split(
        [p.group for p in pairs], tuple(cfg.split.fractions), salt=f"{cfg.split.salt}:{cfg.seed}"
    )
    _, _, test = split_pairs(pairs, assign)
    from torch.utils.data import DataLoader

    loader = DataLoader(
        PairDataset(test), batch_sampler=PairedBatchSampler(len(test), cfg.detector.batch_size, False, cfg.seed)
    )

    rows, transfer_rows = [], []
    all_names = list(cfg.committee.members) + [cfg.committee.held_out]
    clean_reports = {}

    for eps_level in cfg.attack.eps_levels:
        acfg = AttackConfig(
            name=cfg.attack.name, eps_level=int(eps_level), alpha_level=float(cfg.attack.alpha_level),
            steps=int(cfg.attack.steps), random_start=bool(cfg.attack.random_start),
            targeted=bool(cfg.attack.targeted), committee_weighting=str(cfg.attack.committee_weighting),
            quantize=bool(cfg.attack.quantize),
            # Same trap as the curriculum block in train_detectors.py: an EMPTY
            # DictConfig is falsy, so `node or {}` silently swaps it for a plain
            # dict, which to_container then rejects. configs/attack/pgd.yaml has
            # `extra: {}`, so this fired on the manuscript's own attack.
            extra=(OmegaConf.to_container(_extra_node, resolve=True)
                   if (_extra_node := cfg.attack.get("extra", None)) is not None else {}),
        )
        kwargs = {}
        if cfg.attack.name in {"naa", "fia"} and "layers" in cfg.attack:
            kwargs["layers"] = OmegaConf.to_container(cfg.attack.layers)
        attack = build_attack(acfg, members, **kwargs)

        logits = {n: [] for n in all_names}
        clean_logits = {n: [] for n in all_names}
        labels_all, psnrs = [], []

        for x, y, _ in loader:
            x = x.to(device) / 255.0          # detector inputs are 0..255 luma
            x3 = x.repeat(1, 3, 1, 1)          # attack operates in RGB space
            y = y.to(device)
            y_target = torch.zeros_like(y)     # target class = "cover"

            with torch.no_grad():
                for n, m in zip(all_names, members + [held]):
                    clean_logits[n].append(m(x * 255.0).float().cpu().numpy())

            # Only stego images are attacked; covers are passed through unchanged,
            # which is the correct threat model -- the evader has nothing to hide
            # in a cover.
            is_stego = (y == 1)
            x_adv = x3.clone()
            if is_stego.any():
                x_adv[is_stego] = attack(x3[is_stego], y_target[is_stego])
            if is_stego.any():
                psnrs.append(psnr_empirical(x3[is_stego], x_adv[is_stego]))

            xa = (0.299 * x_adv[:, 0] + 0.587 * x_adv[:, 1] + 0.114 * x_adv[:, 2]).unsqueeze(1)
            with torch.no_grad():
                for n, m in zip(all_names, members + [held]):
                    logits[n].append(m(xa * 255.0).float().cpu().numpy())
            labels_all.append(y.cpu().numpy())

        labels = np.concatenate(labels_all)
        att = {n: detection_report(n, labels, np.concatenate(logits[n])) for n in all_names}
        cln = {n: detection_report(n, labels, np.concatenate(clean_logits[n])) for n in all_names}
        if eps_level == 0 or not clean_reports:
            clean_reports = cln

        measured_psnr = float(np.mean(psnrs)) if psnrs else float("nan")
        tr = transferability_gap(
            epsilon=eps_level / 255.0,
            committee_clean=[clean_reports[n] for n in cfg.committee.members],
            committee_attacked=[att[n] for n in cfg.committee.members],
            heldout_clean=clean_reports[cfg.committee.held_out],
            heldout_attacked=att[cfg.committee.held_out],
            gate=gate,
            heldout_labels=labels,
            heldout_scores_clean=canonical_score(np.concatenate(clean_logits[cfg.committee.held_out])),
            heldout_scores_attacked=canonical_score(np.concatenate(logits[cfg.committee.held_out])),
        )

        row = {
            "eps_level": int(eps_level),
            "eps": eps_level / 255.0,
            "psnr": measured_psnr,
            "psnr_printed": format_psnr(measured_psnr),
            "psnr_algebraic_floor": psnr_worst_case(eps_level),
            "gap": tr.gap,
            "gap_defined": tr.defined,
            "gap_reason": tr.reason,
            "normalised_gap": tr.normalised_gap,
        }
        for n in all_names:
            row[f"auc_{n}"] = att[n].auc
            row[f"auc_{n}_lo"] = att[n].auc_lo
            row[f"auc_{n}_hi"] = att[n].auc_hi
            row[f"asr_{n}"] = attack_success_rate(labels, canonical_score(np.concatenate(logits[n])))
        rows.append(row)
        transfer_rows.append(tr.as_row())

        print(
            f"eps={eps_level}/255  PSNR={format_psnr(measured_psnr)} dB "
            f"(algebraic floor {psnr_worst_case(eps_level):.1f})  "
            + "  ".join(f"{n}={att[n].auc:.3f}" for n in all_names)
            + ("  gap=n/a" if tr.gap is None else f"  gap={tr.gap:.3f}")
        )
        if not tr.defined:
            print(f"    gap undefined: {tr.reason}")

    tag = f"{cfg.attack.name}_{cfg.ablation.name}_seed{cfg.seed}"
    (out / f"evasion_{tag}.json").write_text(
        json.dumps(
            {
                "provenance": prov.as_dict(),
                "attack": OmegaConf.to_container(cfg.attack, resolve=True),
                "citation": ATTACK_CITATIONS.get(cfg.attack.name, ""),
                "rows": rows,
                "transfer": transfer_rows,
            },
            indent=2, default=str,
        )
    )
    print(f"\nwrote {out / f'evasion_{tag}.json'}")


if __name__ == "__main__":
    main()
