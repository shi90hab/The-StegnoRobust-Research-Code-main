"""Run the training supervisor. This runs OUTSIDE the Colab runtime.

    python scripts/run_supervisor.py --wandb-run entity/project/run_id --repo /path/to/clone
    python scripts/run_supervisor.py --wandb-run ... --dry-run     # decide, do not publish

It polls W&B for the live run, evaluates the trip conditions in
configs/supervisor/default.yaml, and — when one fires and the budget allows —
pushes a bounded patch to the agent/patches branch. The in-notebook stub picks it
up between epochs. The supervisor never touches the training runtime, and it
never sees the test split: `assert_no_test_split` runs on the W&B history and on
the run state before any decision is made.
"""
import _bootstrap  # noqa: F401

import argparse
import json
from pathlib import Path

from src.supervision import log as ilog
from src.supervision.supervisor import Supervisor, SupervisorState, assert_no_test_split
from src.supervision.triggers import TriggerConfig
from src.utils.git_provenance import assert_token_not_persisted, config_hash, load_pat


def load_state(ckpt_path: Path) -> SupervisorState:
    """The budget lives in the checkpoint, so a reconnect cannot reset it."""
    if not ckpt_path.exists():
        return SupervisorState()
    import torch

    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    return SupervisorState.from_checkpoint(ck)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--wandb-run", required=True, help="entity/project/run_id")
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--checkpoint", type=Path, default=None, help="the run's *_last.pt, for the budget counter")
    ap.add_argument("--detector", default=None)
    ap.add_argument("--metric-key", default="val_auc")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--poll-seconds", type=int, default=120)
    ap.add_argument("--once", action="store_true", help="single decision cycle, then exit")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--config", type=Path, default=Path("configs/supervisor/default.yaml"))
    args = ap.parse_args()

    if args.wandb_run.count("/") != 2:
        raise SystemExit(
            f"--wandb-run must be '<entity>/<project>/<run_id>', got '{args.wandb_run}'.\n"
            "The training script prints the exact string to use. A two-part path silently "
            "resolves against your default entity, which may not be the run you think."
        )

    assert_token_not_persisted(args.repo)
    if not args.dry_run and not load_pat():
        print("[supervisor] no GITHUB_PAT in the environment; patches will be committed locally only")

    from omegaconf import OmegaConf

    scfg = OmegaConf.load(args.config)
    tcfg_dict = OmegaConf.to_container(scfg.triggers, resolve=True)
    if args.detector and args.detector in (scfg.get("per_detector") or {}):
        tcfg_dict.update(OmegaConf.to_container(scfg.per_detector[args.detector], resolve=True))
    tcfg = TriggerConfig(**tcfg_dict)

    sup = Supervisor(
        repo=args.repo, trigger_cfg=tcfg, wandb_run_path=args.wandb_run,
        metric_key=args.metric_key, detector=args.detector, dry_run=args.dry_run,
    )

    ckpt = args.checkpoint or (args.repo / "outputs" / "checkpoints" / f"{args.detector}_last.pt")

    # The run state the supervisor is allowed to see. Validation only -- this dict
    # is what assert_no_test_split inspects.
    def run_state():
        state = {"lr": 1e-3, "weight_decay": 5e-4, "detector": args.detector}
        assert_no_test_split(state, where="supervisor run state")
        return state

    chash = config_hash(OmegaConf.to_container(scfg, resolve=True))

    if args.once:
        history = sup.fetch_history()
        state = load_state(ckpt)
        state, patch, reason = sup.step(
            history, state, run_state(), seed=args.seed, config_hash=chash, wandb_run=args.wandb_run
        )
        print(json.dumps({"reason": reason, "state": state.to_checkpoint_extra(),
                          "patch": patch.as_dict() if patch else None}, indent=2, default=str))
    else:
        sup.watch(lambda: load_state(ckpt), run_state, seed=args.seed,
                  config_hash=chash, poll_seconds=args.poll_seconds)

    print("\n" + ilog.method_altering_diff_summary())


if __name__ == "__main__":
    main()
