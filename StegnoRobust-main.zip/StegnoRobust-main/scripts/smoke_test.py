"""End-to-end pipeline check on synthetic data, CPU, under two minutes.

Run this before committing to a GPU run, and run it from a clean runtime before
submission. It exercises: determinism, group splits, paired batching, all three
detectors, the full attack suite, polarity-safe metrics, the convergence gate,
the guarded transferability gap, LaTeX tables and vector figures.

It does NOT check that the science is right -- it checks that every path a
reviewer might exercise actually executes.

    python scripts/smoke_test.py
    python scripts/smoke_test.py --out /tmp/smoke
"""
import _bootstrap  # noqa: F401

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from src.attacks.base import AttackConfig
from src.attacks.common import format_psnr, psnr_empirical, psnr_worst_case
from src.attacks.registry import ATTACK_CITATIONS, build_attack
from src.data.covers import deterministic_group_split, list_source_images, make_crops
from src.data.pair_dataset import PairDataset, PairedBatchSampler, build_pairs, split_pairs
from src.evaluation.imperceptibility import cover_stego_quality
from src.evaluation.metrics import (
    ConvergenceGate,
    canonical_score,
    committee_summary,
    detection_report,
)
from src.evaluation.plots import configure, plot_auc_vs_budget, plot_convergence, plot_transfer_gap
from src.evaluation.profiling import profile_model
from src.evaluation.tables import table_clean_detection, table_evasion_sweep
from src.evaluation.transferability import transferability_gap
from src.models.registry import build_detector, count_parameters
from src.training.optim import OptimRecipe
from src.training.trainer import evaluate_logits, train_detector
from src.utils.determinism import Provenance, set_seed
from src.utils.execution import assert_timing_reportable, configure as configure_env

SIZE = 48          # small crops keep the smoke test honest but fast
N_SOURCES = 40
SEED = 0


def make_synthetic_sources(root: Path, n: int = N_SOURCES) -> Path:
    """Textured cover images. Pure noise would make embedding trivially
    detectable and pure gradients trivially undetectable; a mixture of both
    exercises the adaptive cost models."""
    src = root / "sources"
    src.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    for i in range(n):
        yy, xx = np.mgrid[0:128, 0:128].astype(np.float32)
        base = 90 + 45 * np.sin(xx / (6 + i % 7)) * np.cos(yy / (9 + i % 5))
        texture = rng.normal(0, 9, (128, 128))
        img = np.clip(base + texture, 0, 255).astype(np.uint8)
        Image.fromarray(img).convert("RGB").save(src / f"synthetic{i:03d}.png")
    return src


def make_stego(cover_dir: Path, stego_dir: Path, strength: float = 1.0, amplitude: int = 2) -> None:
    """A learnable, low-amplitude, content-adaptive residual.

    Stands in for SteganoGAN so the smoke test needs no pretrained weights.
    """
    stego_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED + 1)
    for p in sorted(cover_dir.glob("*.png")):
        a = np.asarray(Image.open(p).convert("L"), dtype=np.int16)
        gx = np.abs(np.gradient(a.astype(np.float32))[1])
        prob = np.clip(gx / (gx.max() + 1e-6), 0.02, 0.5) * strength
        change = (rng.random(a.shape) < prob).astype(np.int16) * rng.choice([-1, 1], a.shape) * amplitude
        Image.fromarray(np.clip(a + change, 0, 255).astype(np.uint8)).save(stego_dir / p.name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=Path("outputs/smoke"))
    ap.add_argument("--epochs", type=int, default=6)
    args = ap.parse_args()

    set_seed(SEED, deterministic=True)
    # The smoke test runs multithreaded for speed, so its timings are explicitly
    # NOT reportable. That is the point: a fast sanity run must not be able to
    # contribute a number to a table.
    fp = configure_env("local", threads=2, thread_mode="exploration")
    prov = Provenance.capture(SEED, fingerprint=fp)
    out = args.out
    if out.exists():
        shutil.rmtree(out)
    (out / "data").mkdir(parents=True, exist_ok=True)
    device = "cpu"

    print("=" * 74)
    print("This verifies that every code path executes and that the guards fire.")
    print("It does NOT train detectors to convergence -- six epochs on 63 synthetic")
    print("pairs cannot, and the gate is expected to reject all three. That")
    print("rejection is the behaviour under test: see STEP 3 and STEP 5.")
    print("=" * 74)
    print("STEP 1  data preparation and group-aware splitting")
    src = make_synthetic_sources(out / "data")
    covers = make_crops(list_source_images(src), out / "data/cover", size=SIZE,
                        crops_per_image=3, seed=SEED)
    make_stego(out / "data/cover", out / "data/stego")
    pairs = build_pairs(out / "data/cover", out / "data/stego")
    assign = deterministic_group_split([p.group for p in pairs], (0.6, 0.2, 0.2))
    tr, va, te = split_pairs(pairs, assign)
    print(f"  {len(covers)} crops from {len(list(src.glob('*.png')))} sources")
    print(f"  train/val/test pairs: {len(tr)}/{len(va)}/{len(te)}  (source-disjoint: asserted)")

    q = cover_stego_quality(
        torch.stack([torch.from_numpy(np.asarray(Image.open(p.cover).convert("L"), np.float32) / 255).unsqueeze(0) for p in te]),
        torch.stack([torch.from_numpy(np.asarray(Image.open(p.stego).convert("L"), np.float32) / 255).unsqueeze(0) for p in te]),
    )
    print(f"  embedding quality: PSNR {q.psnr_mean:.2f} dB (min {q.psnr_min:.2f}), SSIM {q.ssim_mean:.4f}")

    def loader(ps, shuffle, augment=False):
        from torch.utils.data import DataLoader

        return DataLoader(
            PairDataset(ps, augment=augment, seed=SEED),
            batch_sampler=PairedBatchSampler(len(ps), 8, shuffle=shuffle, seed=SEED),
            num_workers=0,
        )

    print("\nSTEP 2  detector training with per-detector recipes and best-val selection")
    gate = ConvergenceGate(min_auc=0.60, require_ci_above_chance=True)
    models, reports, histories = {}, {}, {}
    # SRNet is narrowed for the smoke test only (width 8 instead of 16): the full
    # network is 2.4M parameters and dominates CPU runtime without exercising any
    # additional code path.
    smoke_arch = {"srnet": {"width": 8}}
    for name in ("xunet", "yenet", "srnet"):
        m = build_detector(name, in_channels=1, num_classes=2, **smoke_arch.get(name, {}))
        rec = OptimRecipe(optimizer="adam", lr=1e-3, epochs=args.epochs, scheduler="cosine",
                          warmup_epochs=1, grad_clip=5.0, early_stop_patience=None)
        res = train_detector(m, loader(tr, True, True), loader(va, False), rec,
                             detector_name=name, device=device,
                             ckpt_dir=out / "ckpt", gate=gate, amp=False, resume=False)
        logits, labels = evaluate_logits(m, loader(te, False), device)
        rep = detection_report(name, labels, logits)
        models[name], reports[name], histories[name] = m, rep, res.history
        p = count_parameters(m)
        print(f"  {name:<6} params {p['total']/1e6:6.3f}M | best val AUC {res.best_val_auc:.3f} "
              f"@ep{res.best_epoch} | test AUC {rep.auc:.3f} [{rep.auc_lo:.3f},{rep.auc_hi:.3f}] "
              f"| converged={res.converged}")
        if not res.converged:
            print(f"           gate: {res.convergence_reason}")

    print("\nSTEP 3  committee rule (mean suppressed if any member fails the gate)")
    summ = committee_summary([reports["xunet"], reports["yenet"]], gate)
    print(f"  admitted: {summ.admitted}  rejected: {list(summ.rejected)}")
    print(f"  committee mean AUC: {summ.mean_auc if summ.mean_auc is not None else 'n/a'}")
    if summ.mean_auc is None:
        print(f"  reason: {summ.reason[:150]}...")

    print("\nSTEP 4  attack suite at matched budget")
    committee = [models["xunet"], models["yenet"]]
    held = models["srnet"]
    x = torch.stack([
        torch.from_numpy(np.asarray(Image.open(p.stego).convert("L"), np.float32) / 255).unsqueeze(0)
        for p in te[:16]
    ]).repeat(1, 3, 1, 1)
    y_target = torch.zeros(len(x), dtype=torch.long)

    suite = ["fgsm", "pgd", "mifgsm", "difgsm", "tifgsm", "vmifgsm", "sinifgsm", "nifgsm", "fia", "naa"]
    attack_rows = []
    for name in suite:
        cfg = AttackConfig(name=name, eps_level=8, alpha_level=1.0, steps=4,
                           extra={"vmi_samples": 2, "fia_ensemble": 3, "naa_ig_steps": 3, "si_copies": 2})
        atk = build_attack(cfg, committee, **({"layers": None} if name in {"fia", "naa"} else {}))
        xa = atk(x, y_target)
        luma = (0.299 * xa[:, 0] + 0.587 * xa[:, 1] + 0.114 * xa[:, 2]).unsqueeze(1)
        with torch.no_grad():
            z_c = models["yenet"](luma * 255).numpy()
            z_h = held(luma * 255).numpy()
        ps = psnr_empirical(x, xa)
        linf = (xa - x).abs().max().item() * 255
        attack_rows.append({"attack": name, "psnr": ps, "linf": linf})
        print(f"  {name:<9} PSNR {format_psnr(ps):>5} dB (floor {psnr_worst_case(8):.1f}) "
              f"| Linf {linf:5.2f}/255 | committee score {canonical_score(z_c).mean():+7.3f} "
              f"| held-out {canonical_score(z_h).mean():+7.3f}  [{ATTACK_CITATIONS[name].split(' -- ')[0]}]")
        assert linf <= 8.0 + 1e-3, f"{name} violated the L_inf budget"

    print("\nSTEP 5  evasion sweep with a guarded transferability gap")
    sweep, gaps, defined, budgets = [], [], [], [0, 2, 4, 8]
    for eps in budgets:
        cfg = AttackConfig(name="pgd", eps_level=eps, alpha_level=1.0, steps=5)
        atk = build_attack(cfg, committee)
        xa = atk(x, y_target) if eps > 0 else x
        luma = (0.299 * xa[:, 0] + 0.587 * xa[:, 1] + 0.114 * xa[:, 2]).unsqueeze(1)
        labels = np.ones(len(x), dtype=int)
        cov = torch.stack([
            torch.from_numpy(np.asarray(Image.open(p.cover).convert("L"), np.float32) / 255).unsqueeze(0)
            for p in te[:16]
        ])
        allx = torch.cat([cov, luma])
        alllab = np.concatenate([np.zeros(len(cov), int), labels])
        with torch.no_grad():
            att = {n: detection_report(n, alllab, models[n](allx * 255).numpy()) for n in models}
        if eps == 0:
            clean = att
        tr_res = transferability_gap(eps / 255, [clean[n] for n in ("xunet", "yenet")],
                                     [att[n] for n in ("xunet", "yenet")],
                                     clean["srnet"], att["srnet"], gate)
        ps = psnr_empirical(x, xa) if eps > 0 else float("inf")
        row = {"eps_level": eps, "psnr": ps if np.isfinite(ps) else None,
               "gap": tr_res.gap, "gap_defined": tr_res.defined}
        for n in models:
            row[f"auc_{n}"] = att[n].auc
        sweep.append(row)
        gaps.append(tr_res.gap)
        defined.append(tr_res.defined)
        print(f"  eps={eps}/255  " + "  ".join(f"{n}={att[n].auc:.3f}" for n in models)
              + (f"  gap={tr_res.gap:.3f}" if tr_res.gap is not None else "  gap=n/a (guarded)"))

    print("\nSTEP 6  deliverables")
    configure()
    figs, tabs = out / "figures", out / "tables"
    plot_convergence(histories, figs / "fig_convergence")
    plot_auc_vs_budget(budgets, {n: [r[f"auc_{n}"] for r in sweep] for n in models},
                       out=figs / "fig_auc_vs_budget", heldout="srnet")
    plot_transfer_gap(budgets, gaps, defined, figs / "fig_transfer_gap")
    rows = [{"detector": n, "role": ("held_out" if n == "srnet" else "committee"),
             **reports[n].as_row(), "converged": gate.admits(reports[n])[0]} for n in models]
    table_clean_detection(rows, {"mean_auc": summ.mean_auc, "reason": summ.reason},
                          tabs / "table2_clean_detection.tex")
    table_evasion_sweep(sweep, tabs / "table3_evasion.tex")
    cost = [profile_model(n, models[n], (1, 1, SIZE, SIZE), "cpu", fingerprint=fp).as_row()
            for n in models]
    from src.evaluation.tables import table_profiling

    table_profiling(cost, tabs / "table6_cost.tex")
    for f in sorted(figs.glob("*")) + sorted(tabs.glob("*")):
        print(f"  {f.relative_to(out)}  ({f.stat().st_size} bytes)")

    print("\nSTEP 7  execution target and timing validity")
    print(f"  target {fp.target} | device {fp.device} | hardware {fp.label()}")
    print(f"  threads {fp.threads} ({fp.thread_mode}) | RAM {fp.total_ram_gb:.1f} GB")
    try:
        assert_timing_reportable(fp, "smoke-test latency")
        print("  timings reportable: yes")
    except Exception as e:
        print(f"  timings reportable: NO (correct) -- {str(e)[:88]}")
    assert not fp.timing_reportable, "an exploration-mode run must not be reportable"
    assert "n/r" in (tabs / "table6_cost.tex").read_text(), "cost table must print n/r, not a number"

    print("\nSTEP 8  determinism check")
    set_seed(SEED, deterministic=True)
    a = build_detector("xunet")(torch.zeros(2, 1, SIZE, SIZE))
    set_seed(SEED, deterministic=True)
    b = build_detector("xunet")(torch.zeros(2, 1, SIZE, SIZE))
    same = torch.allclose(a, b)
    print(f"  two identically seeded initialisations agree: {same}")
    assert same, "determinism check failed"

    (out / "smoke_report.json").write_text(json.dumps(
        {"provenance": prov.as_dict(), "hardware": fp.as_dict(), "sweep": sweep,
         "attacks": attack_rows, "cost": cost,
         "committee": {"mean_auc": summ.mean_auc, "reason": summ.reason}},
        indent=2, default=str))
    print("\n" + "=" * 74)
    print(f"SMOKE TEST PASSED -> {out}")


if __name__ == "__main__":
    main()
