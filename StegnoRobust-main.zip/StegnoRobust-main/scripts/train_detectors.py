"""Train XuNet, YeNet and SRNet with per-detector recipes and a convergence gate.

    python scripts/train_detectors.py seed=0
    python scripts/train_detectors.py -m seed=0,1,2,3,4 dataset=bsds500,bossbase

Answers, concretely:
  R1-8, R2-3, R2-4  per-detector schedules, SRNet curriculum, paired batching
  R1-8(i)           selection on best validation AUC, written to *_best.pt
  R2-6              every setting comes from Hydra and is logged with the run
  R2-4              a detector that fails the gate is EXCLUDED, and the exclusion
                    is recorded in convergence.json for the response letter
"""
import _bootstrap  # noqa: F401

import json
from pathlib import Path

import hydra
import numpy as np
from omegaconf import DictConfig, OmegaConf

from src.data.covers import deterministic_group_split
from src.data.pair_dataset import PairDataset, PairedBatchSampler, build_pairs, split_pairs
from src.evaluation.metrics import ConvergenceGate, detection_report
from src.models.registry import build_detector
from src.supervision.supervisor import assert_no_test_split
from src.training.optim import OptimRecipe
from src.training.trainer import GitPolicy, SupervisionPolicy, evaluate_logits, train_detector
from src.utils.determinism import Provenance, make_generator, seed_worker, set_seed
from src.utils.execution import configure as configure_env
from src.utils.git_provenance import (
    CommitProvenance,
    commit_evaluation_artifacts,
    config_hash,
    ensure_repo,
)


def _loaders(cfg, pairs, seed, shuffle, augment):
    from torch.utils.data import DataLoader

    ds = PairDataset(pairs, augment=augment, seed=seed)
    sampler = PairedBatchSampler(len(pairs), cfg.detector.batch_size, shuffle=shuffle, seed=seed)
    return DataLoader(
        ds,
        batch_sampler=sampler,
        num_workers=cfg.hparams.num_workers,
        pin_memory=cfg.hparams.pin_memory,
        worker_init_fn=seed_worker,
        generator=make_generator(seed),
    )


@hydra.main(version_base=None, config_path="../configs", config_name="main")
def main(cfg: DictConfig) -> None:
    set_seed(cfg.seed, deterministic=cfg.deterministic)  # FIRST, before any CUDA
    # Declare the execution target and pin the machine to match it. Threads are
    # pinned before any tensor exists, because BLAS reduction order is part of
    # the reproducibility contract (§13).
    fp = configure_env(
        cfg.env.target, threads=cfg.env.threads, thread_mode=cfg.env.thread_mode,
        allow_mps=cfg.env.allow_mps,
    )
    prov = Provenance.capture(cfg.seed, fingerprint=fp)
    print(f"[env] target={fp.target} device={fp.device} hardware={fp.label()} "
          f"timings_reportable={fp.timing_reportable}")

    # Ablations are configuration, not code branches: each file changes exactly one
    # field, applied here so the resolved config recorded with the run shows the
    # ablated value rather than the default.
    abl = cfg.get("ablation")
    if abl and abl.get("overrides"):
        for key, value in abl.overrides.items():
            OmegaConf.update(cfg, key, value, merge=True)
        print(f"[ablation] {abl.name}: " + ", ".join(f"{k}={v}" for k, v in abl.overrides.items()))

    out = Path(cfg.paths.metrics)
    out.mkdir(parents=True, exist_ok=True)
    (out / "resolved_config.yaml").write_text(OmegaConf.to_yaml(cfg, resolve=True))

    run = None
    if cfg.tracking.wandb.enabled:
        try:
            import wandb

            run = wandb.init(
                project=cfg.tracking.wandb.project,
                entity=cfg.tracking.wandb.entity,
                mode=cfg.tracking.wandb.mode,
                tags=list(cfg.tracking.wandb.tags),
                config=OmegaConf.to_container(cfg, resolve=True) | prov.as_dict(),
            )
            # The supervisor addresses this run as "<entity>/<project>/<run_id>".
            # Print it: hunting for it in the W&B UI mid-run is the friction that
            # stops people using the watcher at all.
            print(f"[wandb] run path: {run.entity}/{run.project}/{run.id}")
            print(f"[wandb] url     : {run.url}")
            print(f"[wandb] supervise with:\n"
                  f"        python scripts/run_supervisor.py "
                  f"--wandb-run {run.entity}/{run.project}/{run.id} "
                  f"--repo . --detector srnet --once --dry-run")
        except Exception as e:
            print(f"[wandb] disabled ({e})")

    cover_dir = Path(cfg.dataset.root) / "cover"
    stego_dir = Path(cfg.dataset.root) / f"stego_{cfg.embed.name}"
    pairs = build_pairs(cover_dir, stego_dir)
    assign = deterministic_group_split(
        [p.group for p in pairs], tuple(cfg.split.fractions), salt=f"{cfg.split.salt}:{cfg.seed}"
    )
    tr, va, te = split_pairs(pairs, assign)
    print(f"pairs: train={len(tr)} val={len(va)} test={len(te)} "
          f"(groups disjoint by construction; see split_pairs assertion)")

    gate = ConvergenceGate(**OmegaConf.to_container(cfg.convergence_gate))
    results, convergence = {}, {}

    chash = config_hash(cfg)
    git_policy = GitPolicy(
        enabled=bool(cfg.git.enabled), repo=str(cfg.git.repo), branch=str(cfg.git.branch),
        push=bool(cfg.git.push), seed=int(cfg.seed), config_hash=chash,
        wandb_run=(run.id if run else None),
    )
    if git_policy.enabled:
        ensure_repo(git_policy.repo, remote=cfg.git.remote, branch=git_policy.branch)
    supervision = SupervisionPolicy(
        enabled=bool(cfg.supervisor.enabled), repo=str(cfg.supervisor.repo),
        max_rounds=int(cfg.supervisor.triggers.max_rounds),
    )

    # An ablation may name the detectors it actually affects. Running
    # `frozen_srm` on SRNet or `no_curriculum` on XuNet costs GPU hours and
    # explains nothing -- the field is not there to save time, it is there so a
    # row of the ablation table isolates the component it claims to isolate.
    only = list(abl.get("only_detectors") or []) if abl else []
    for name in ["xunet", "yenet", "srnet"]:
        dcfg = cfg.detector[name]
        if not dcfg.enabled:
            continue
        if only and name not in only:
            print(f"[ablation] {abl.name}: skipping {name} (affects {only})")
            continue
        model = build_detector(
            name, in_channels=cfg.detector.input_channels,
            num_classes=cfg.detector.num_classes, **OmegaConf.to_container(dcfg.arch),
        )
        recipe = OptimRecipe(**OmegaConf.to_container(dcfg.optim))

        # SRNet curriculum: warm-start from an easier payload stage if present.
        # `.get(key, {})` returns a PLAIN dict when the key is absent, and
        # to_container rejects plain dicts -- so the default must never be handed
        # to it. XuNet and YeNet have no curriculum block, and XuNet trains first,
        # so this failed on the very first detector.
        curr_node = dcfg.get("curriculum", None)
        curr = OmegaConf.to_container(curr_node, resolve=True) if curr_node is not None else {}
        if curr.get("enabled") and hasattr(model, "init_from"):
            warm = Path(cfg.paths.checkpoints) / f"{name}_curriculum_best.pt"
            if warm.exists():
                model.init_from(str(warm))
                print(f"[{name}] warm-started from curriculum checkpoint {warm}")

        # The supervisor operates on this run only through the two objects below.
        # The test loader is constructed AFTER training returns, so it cannot be
        # reached from any scope the supervisor sees.
        assert_no_test_split(
            {"train_loader": True, "val_loader": True, "recipe": recipe.__dict__},
            where=f"{name} training scope",
        )
        res = train_detector(
            model,
            _loaders(cfg, tr, cfg.seed, shuffle=True, augment=cfg.hparams.augment),
            _loaders(cfg, va, cfg.seed, shuffle=False, augment=False),
            recipe,
            detector_name=name,
            device=fp.device,
            # The ablation name MUST be in the checkpoint path. Without it every
            # ablation reads the full_model checkpoint, sees start_epoch >= its
            # epoch budget, trains nothing, and re-evaluates the unmodified
            # weights -- producing a full ablation table in which every row is
            # the baseline wearing a different label. That failed silently and
            # looked plausible, which is the worst way for it to fail.
            ckpt_dir=(Path(cfg.env.checkpoint_root) / f"seed{cfg.seed}"
                      if cfg.ablation.name == "full_model"
                      else Path(cfg.env.checkpoint_root) / cfg.ablation.name / f"seed{cfg.seed}"),
            gate=gate,
            amp=bool(cfg.env.amp),
            log_fn=(run.log if run else None),
            git_policy=git_policy,
            supervision=supervision,
            cfg=cfg,
            save_every_epochs=int(cfg.hparams.checkpoint.save_every_epochs),
        )

        # Test set touched ONCE, after selection is complete.
        logits, labels = evaluate_logits(model, _loaders(cfg, te, cfg.seed, False, False), fp.device)
        rep = detection_report(name, labels, logits)

        # A run that trained nothing is not a result. This fires when a stale
        # checkpoint satisfies the epoch budget -- the exact failure above.
        if res.epochs_this_session == 0 and cfg.ablation.name != "full_model":
            raise RuntimeError(
                f"[{name}] ablation '{cfg.ablation.name}' trained 0 epochs: it resumed from "
                f"epoch {res.resumed_from_epoch} of a {recipe.epochs}-epoch budget and only "
                f"re-evaluated existing weights. Delete "
                f"{Path(cfg.env.checkpoint_root) / cfg.ablation.name / f'seed{cfg.seed}'} "
                f"and re-run, or the ablation table will repeat the baseline."
            )

        results[name] = {
            "train": res.__dict__ | {"history": res.history[-1:] if res.history else []},
            "test": rep.as_row(),
            "role": dcfg.role,
        }
        convergence[name] = {
            "converged": res.converged,
            "reason": res.convergence_reason,
            "best_val_auc": res.best_val_auc,
            "best_epoch": res.best_epoch,
            "role": dcfg.role,
        }
        (out / f"history_{name}_seed{cfg.seed}.json").write_text(json.dumps(res.history, indent=2))
        print(f"[{name}] best val AUC {res.best_val_auc:.4f} @ epoch {res.best_epoch} | "
              f"test AUC {rep.auc:.4f} [{rep.auc_lo:.3f},{rep.auc_hi:.3f}] | "
              f"converged={res.converged} ({res.convergence_reason})")
        if res.commits:
            print(f"        {len(res.commits)} provenance commit(s), latest {res.commits[-1][:7]}")
        if res.supervisor and res.supervisor.get("round"):
            print(f"        agent revisions applied: {res.supervisor['round']}/"
                  f"{res.supervisor['max_rounds']}")

    (out / f"detectors_{cfg.ablation.name}_seed{cfg.seed}.json").write_text(
        json.dumps({"provenance": prov.as_dict(), "results": results}, indent=2, default=str)
    )
    (out / f"convergence_{cfg.ablation.name}_seed{cfg.seed}.json").write_text(json.dumps(convergence, indent=2))

    failed = [k for k, v in convergence.items() if not v["converged"]]
    if failed:
        print(
            "\nCONVERGENCE GUARD: " + ", ".join(failed) + " did not pass the gate.\n"
            "These detectors are excluded from the committee and from the held-out role.\n"
            "Downstream scripts will refuse to report a committee mean or a transferability\n"
            "gap that depends on them -- this is the guard Reviewer 1 comment 8(iv) asked for."
        )
    # One end-of-run commit for artifacts produced after training stops; the
    # commit-on-new-best rule would never capture these.
    if git_policy.enabled and cfg.git.commit_policy.end_of_run_artifacts:
        best = max((v["best_val_auc"] for v in convergence.values()), default=float("nan"))
        commit_evaluation_artifacts(
            git_policy.repo,
            CommitProvenance(
                metric_name="val_auc", metric_value=best, previous_best=None, epoch=-1,
                seed=int(cfg.seed), config_hash=chash, wandb_run=(run.id if run else None),
                trigger="end_of_run",
            ),
        )

    from src.supervision.log import method_altering_diff_summary

    summary = method_altering_diff_summary()
    if "No method-altering" not in summary:
        print("\n" + "=" * 72 + "\nMETHODS SECTION WARNING\n" + "=" * 72)
        print(summary)

    if run:
        run.finish()


if __name__ == "__main__":
    main()
