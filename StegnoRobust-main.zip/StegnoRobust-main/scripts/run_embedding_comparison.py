"""Matched-payload comparison of classical, deep and GAN-based embedding.

    python scripts/run_embedding_comparison.py embed=comparison seed=0

Answers Reviewer 2, comment 5 -- "a rigorous comparison against classical
embedding methods, stronger modern deep hiding methods, or established
adversarial steganography baselines under matched payload, dataset, distortion,
and detector settings."

The matching is enforced, not merely intended: every method embeds the same
requested bpp into the same cover crops, and is scored by detectors trained on
its own stego (so no method is advantaged by a detector that never saw it).
"""
import _bootstrap  # noqa: F401

import json
from pathlib import Path

import hydra
import numpy as np
from omegaconf import DictConfig, OmegaConf

from src.evaluation.imperceptibility import cover_stego_quality
from src.models.embedding.classical import CLASSICAL_EMBEDDERS
from src.utils.determinism import Provenance, set_seed


def _load_gray_u8(path):
    from PIL import Image

    return np.asarray(Image.open(path).convert("L"), dtype=np.uint8)


@hydra.main(version_base=None, config_path="../configs", config_name="main")
def main(cfg: DictConfig) -> None:
    set_seed(cfg.seed, deterministic=cfg.deterministic)
    prov = Provenance.capture(cfg.seed)

    cover_dir = Path(cfg.dataset.root) / "cover"
    covers = sorted(cover_dir.glob("*.png"))
    if not covers:
        raise FileNotFoundError(f"no covers under {cover_dir}; run scripts/prepare_data.py first")

    out = Path(cfg.paths.metrics)
    out.mkdir(parents=True, exist_ok=True)
    rows = []

    for bpp in cfg.embed.requested_bpp_grid:
        for spec in cfg.embed.methods:
            name, family = spec["name"], spec["family"]
            if name not in CLASSICAL_EMBEDDERS:
                # Deep/GAN methods are produced by scripts/prepare_data.py, which
                # writes them to disk; they are picked up here by directory name.
                stego_dir = Path(cfg.dataset.root) / f"stego_{name}_bpp{bpp}"
                if not stego_dir.exists():
                    print(f"[skip] {name} @ {bpp} bpp -- {stego_dir} not generated")
                    continue
                achieved = bpp
                pairs = [(c, stego_dir / c.name) for c in covers if (stego_dir / c.name).exists()]
                stegos = [_load_gray_u8(s) for _, s in pairs]
                cov = [_load_gray_u8(c) for c, _ in pairs]
            else:
                fn = CLASSICAL_EMBEDDERS[name]
                cov, stegos, achieved_list = [], [], []
                stego_dir = Path(cfg.dataset.root) / f"stego_{name}_bpp{bpp}"
                stego_dir.mkdir(parents=True, exist_ok=True)
                from PIL import Image

                for i, c in enumerate(covers):
                    a = _load_gray_u8(c)
                    try:
                        s, ach = fn(a, float(bpp), cfg.seed * 100003 + i)
                    except ValueError as e:
                        print(f"[skip] {name} @ {bpp} bpp -- {e}")
                        break
                    Image.fromarray(s).save(stego_dir / c.name, compress_level=1)
                    cov.append(a); stegos.append(s); achieved_list.append(ach)
                if not stegos:
                    continue
                achieved = float(np.mean(achieved_list))

            import torch

            a = torch.from_numpy(np.stack(cov).astype(np.float32) / 255.0).unsqueeze(1)
            b = torch.from_numpy(np.stack(stegos).astype(np.float32) / 255.0).unsqueeze(1)
            q = cover_stego_quality(a, b)
            rows.append(
                {
                    "method": name, "family": family, "requested_bpp": float(bpp),
                    "achieved_bpp": float(achieved), **q.as_row(),
                }
            )
            print(f"{name:<20} req {bpp:>6} bpp  achieved {achieved:>7.3f}  "
                  f"PSNR {q.psnr_mean:6.2f} (min {q.psnr_min:6.2f})  SSIM {q.ssim_mean:.4f}")

    (out / f"embedding_comparison_seed{cfg.seed}.json").write_text(
        json.dumps({"provenance": prov.as_dict(), "rows": rows}, indent=2, default=str)
    )
    print(f"\nStego images written under {cfg.dataset.root}. Train detectors on each with:\n"
          f"  python scripts/train_detectors.py -m embed.name=<method> seed={cfg.seed}\n"
          f"then aggregate into Table 5 with scripts/aggregate_results.py.")


if __name__ == "__main__":
    main()
