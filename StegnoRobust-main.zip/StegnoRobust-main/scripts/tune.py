"""Optuna hyperparameter search. Validation only, pruned, resumable.

    python scripts/tune.py --detector srnet --trials 40
    python scripts/tune.py --detector xunet --trials 25 --timeout-hours 6

Three properties matter more than the search itself.

**The test set is never visible.** The objective is best validation AUC, and the
test split is not even constructed in this file. Selecting hyperparameters on
test is leakage wearing a respectable hat, and it is the failure reviewers look
for hardest -- so it is prevented structurally, and asserted via
`assert_no_test_split` on the objective's scope.

**Trials are pruned, and exit cleanly.** A hopeless trial dies at the epoch it
becomes hopeless. Pruning is delivered through the trainer's `epoch_callback`, so
`TrialPruned` propagates out of the training loop rather than crashing it.

**The study is persisted to Drive.** An interrupted search resumes instead of
restarting -- which on a 450-epoch SRNet schedule is the difference between a
lost afternoon and a lost week.

What is searched is deliberately narrow. This is a revision, not a new method:
the recipes in configs/detector/all.yaml are the published ones, and the search
exists to answer "is SRNet's non-convergence a hyperparameter problem?" rather
than to squeeze out decimal places. A wide search here would also be dangerous --
the more the configuration is tuned on validation, the more the validation AUC
overstates what a reviewer will reproduce.
"""
import _bootstrap  # noqa: F401

import argparse
import json
from pathlib import Path

import numpy as np


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--detector", required=True, choices=["xunet", "yenet", "srnet"])
    ap.add_argument("--trials", type=int, default=40)
    ap.add_argument("--timeout-hours", type=float, default=None)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=None, help="override for a faster search")
    ap.add_argument("--study-db", type=Path, default=None)
    ap.add_argument("--config-dir", type=Path, default=Path("configs"))
    ap.add_argument("--wandb", default="offline")
    args = ap.parse_args()

    import optuna
    from omegaconf import OmegaConf
    from optuna.pruners import MedianPruner
    from optuna.samplers import TPESampler
    from torch.utils.data import DataLoader

    from src.data.covers import deterministic_group_split
    from src.data.pair_dataset import PairDataset, PairedBatchSampler, build_pairs, split_pairs
    from src.evaluation.metrics import ConvergenceGate
    from src.models.registry import build_detector
    from src.supervision.supervisor import assert_no_test_split
    from src.training.optim import OptimRecipe
    from src.training.trainer import train_detector
    from src.utils.determinism import make_generator, seed_worker, set_seed
    from src.utils.execution import configure as configure_env

    set_seed(args.seed)
    cfg = OmegaConf.load(args.config_dir / "main.yaml")
    for grp, default in (("dataset", "bsds500"), ("detector", "all"), ("embed", "steganogan_dense"),
                         ("hparams", "default"), ("env", "colab_gpu")):
        cfg[grp] = OmegaConf.load(args.config_dir / grp / f"{default}.yaml")
    fp = configure_env(cfg.env.target, threads=cfg.env.threads, thread_mode=cfg.env.thread_mode)

    pairs = build_pairs(Path(str(cfg.dataset.root)) / "cover",
                        Path(str(cfg.dataset.root)) / f"stego_{cfg.embed.name}")
    assign = deterministic_group_split([p.group for p in pairs], (0.7, 0.15, 0.15),
                                       salt=f"tune:{args.seed}")
    train_pairs, val_pairs, _test_pairs_unused = split_pairs(pairs, assign)
    del _test_pairs_unused    # not a comment: the test split leaves this scope immediately

    def loader(ps, shuffle, augment):
        return DataLoader(
            PairDataset(ps, augment=augment, seed=args.seed),
            batch_sampler=PairedBatchSampler(len(ps), cfg.detector.batch_size, shuffle, args.seed),
            num_workers=cfg.hparams.num_workers, worker_init_fn=seed_worker,
            generator=make_generator(args.seed),
        )

    base = OmegaConf.to_container(cfg.detector[args.detector].optim, resolve=True)
    gate = ConvergenceGate(**OmegaConf.to_container(cfg.convergence_gate, resolve=True))

    def objective(trial: "optuna.Trial") -> float:
        # Narrow, published-recipe-anchored search space.
        params = dict(base)
        params["lr"] = trial.suggest_float("lr", base["lr"] / 10, base["lr"] * 3, log=True)
        params["weight_decay"] = trial.suggest_float("weight_decay", 1e-5, 1e-2, log=True)
        params["warmup_epochs"] = trial.suggest_int("warmup_epochs", 0, 10)
        if args.detector == "srnet":
            params["optimizer"] = trial.suggest_categorical("optimizer", ["adamax", "adam", "sgd"])
        if args.epochs:
            params["epochs"] = args.epochs
        params["early_stop_patience"] = params.get("early_stop_patience") or 20

        recipe = OptimRecipe(**params)
        arch = OmegaConf.to_container(cfg.detector[args.detector].arch, resolve=True)
        model = build_detector(args.detector, in_channels=1, num_classes=2, **arch)

        scope = {"train_loader": True, "val_loader": True, "params": params}
        assert_no_test_split(scope, where=f"optuna objective for {args.detector}")

        def on_epoch(epoch: int, val_auc: float) -> None:
            trial.report(val_auc, epoch)
            if trial.should_prune():
                raise optuna.TrialPruned(
                    f"pruned at epoch {epoch} with val AUC {val_auc:.4f}"
                )

        res = train_detector(
            model, loader(train_pairs, True, cfg.hparams.augment), loader(val_pairs, False, False),
            recipe, detector_name=f"{args.detector}_t{trial.number}", device=fp.device,
            ckpt_dir=Path(cfg.env.checkpoint_root) / "tuning" / f"trial{trial.number}",
            gate=gate, amp=bool(cfg.env.amp), resume=False, epoch_callback=on_epoch,
        )
        trial.set_user_attr("converged", res.converged)
        trial.set_user_attr("convergence_reason", res.convergence_reason)
        trial.set_user_attr("best_epoch", res.best_epoch)
        return res.best_val_auc

    db = args.study_db or (Path(str(cfg.paths.drive_root)) / "optuna" / f"{args.detector}.db")
    db.parent.mkdir(parents=True, exist_ok=True)
    study = optuna.create_study(
        study_name=f"{args.detector}-val-auc",
        storage=f"sqlite:///{db}",
        direction="maximize",
        load_if_exists=True,     # an interrupted search resumes rather than restarting
        sampler=TPESampler(seed=args.seed),
        pruner=MedianPruner(n_startup_trials=5, n_warmup_steps=10),
    )

    callbacks = []
    if args.wandb == "online":
        try:
            # Optuna 3.6 moved the integrations into a separate distribution and
            # deprecated the in-tree path. Try the new location first so a fresh
            # Colab install works, then fall back for older pins.
            try:
                from optuna_integration.wandb import WeightsAndBiasesCallback
            except ImportError:
                from optuna.integration.wandb import WeightsAndBiasesCallback

            callbacks.append(WeightsAndBiasesCallback(
                metric_name="val_auc",
                wandb_kwargs={"project": str(cfg.tracking.wandb.project),
                              "tags": ["optuna", args.detector]},
            ))
        except Exception as e:
            print(f"[optuna] W&B callback unavailable ({e}); continuing without it")

    study.optimize(
        objective, n_trials=args.trials,
        timeout=(args.timeout_hours * 3600 if args.timeout_hours else None),
        callbacks=callbacks, gc_after_trial=True,
    )

    print("\n" + "=" * 74)
    print(f"best val AUC {study.best_value:.4f}  (trial {study.best_trial.number})")
    for k, v in study.best_params.items():
        print(f"  {k:<18} {v}")
    print(f"  converged        {study.best_trial.user_attrs.get('converged')}")
    print(f"  reason           {study.best_trial.user_attrs.get('convergence_reason')}")
    n_pruned = len([t for t in study.trials if t.state == optuna.trial.TrialState.PRUNED])
    print(f"\n{n_pruned}/{len(study.trials)} trials pruned")
    print("=" * 74)
    print(
        "\nThese are VALIDATION numbers from a search. Paste the winning values into\n"
        "configs/detector/all.yaml, then re-run scripts/train_detectors.py so the reported\n"
        "result comes from a clean run against an untouched test split -- a tuned number\n"
        "read straight off the study is a validation number wearing a test number's clothes."
    )

    out = Path(str(cfg.paths.metrics)) / f"optuna_{args.detector}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "best_value": study.best_value, "best_params": study.best_params,
        "n_trials": len(study.trials), "n_pruned": n_pruned,
        "user_attrs": study.best_trial.user_attrs, "study_db": str(db),
    }, indent=2, default=str))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
