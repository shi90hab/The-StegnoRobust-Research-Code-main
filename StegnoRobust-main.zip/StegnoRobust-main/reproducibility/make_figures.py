"""Regenerate the result figures from the same ledger the numeric gate checks.

Deriving the figures from results/per_seed_transfer.json rather than importing
the pipeline's own plots means a figure cannot disagree with the table beside
it -- both are the same numbers.

Figure 7 is drawn from the trainer's own per-epoch records in
results/history/. Figure 6 is not the submitted ROC plot: redrawing that needs
per-sample detector scores, which the artifacts do not contain, so the slot
carries the operating-point error rates instead. See CHANGES.md.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
FIGS = HERE / "figures"
FIGS.mkdir(exist_ok=True)
R = json.loads((HERE / "results" / "per_seed_transfer.json").read_text())

EPS = R["_eps_levels"]
SEEDS = ["seed0", "seed1", "seed2", "seed3"]
M = R["evasion_pgd_4seed_mean"]
DPI = 600

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 8,
    "axes.linewidth": 0.6,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.constrained_layout.use": True,
})

BLUE, GREEN, ORANGE, GREY = "#2c6fbb", "#4c9a2a", "#d9772b", "#666666"


def save(fig, name):
    p = FIGS / f"{name}.png"
    fig.savefig(p, dpi=DPI, bbox_inches="tight")
    fig.savefig(FIGS / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)
    print(f"  {p.name}  ({p.stat().st_size // 1024} KB)")
    return p


# ---- Figure 5: clean AUC per detector, with DeLong CIs --------------------
c = R["clean_detection_4seed_mean"]
fig, ax = plt.subplots(figsize=(3.4, 2.3))
names = ["XuNet\n(committee)", "YeNet\n(committee)", "SRNet\n(held-out)"]
vals = [c["xunet"]["auc"], c["yenet"]["auc"], c["srnet"]["auc"]]
# The DeLong interval prints unclipped in the artifact; an AUC cannot exceed 1.
los = [min(c[d]["ci"][0], 1.0) for d in ("xunet", "yenet", "srnet")]
his = [min(c[d]["ci"][1], 1.0) for d in ("xunet", "yenet", "srnet")]
err = [[v - lo for v, lo in zip(vals, los)], [hi - v for v, hi in zip(vals, his)]]
bars = ax.bar(names, vals, color=[BLUE, BLUE, GREEN], width=0.6,
              yerr=err, capsize=3, error_kw={"lw": 0.8, "ecolor": "#333333"})
ax.axhline(0.5, ls="--", lw=0.8, color=GREY, label="chance")
for b, v in zip(bars, vals):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.012, f"{v:.3f}",
            ha="center", va="bottom", fontsize=7)
ax.set_ylim(0.4, 1.06)
ax.set_ylabel("ROC-AUC (clean stego)")
ax.legend(frameon=False, loc="lower right", fontsize=7)
save(fig, "fig5_clean_auc")

# ---- Figure 8: AUC against budget ----------------------------------------
fig, ax = plt.subplots(figsize=(3.4, 2.4))
ax.plot(EPS, M["xunet"], "o-", color=BLUE, ms=3, lw=1.2, label="XuNet (attacked)")
ax.plot(EPS, M["yenet"], "s-", color=ORANGE, ms=3, lw=1.2, label="YeNet (attacked)")
ax.plot(EPS, M["srnet"], "^-", color=GREEN, ms=3.5, lw=1.4, label="SRNet (held-out)")
for s in SEEDS:  # per-seed held-out, to show the spread is small
    ax.plot(EPS, R["pgd"][s]["heldout_attacked"], color=GREEN, lw=0.4, alpha=0.35)
ax.axhline(0.5, ls="--", lw=0.8, color=GREY)
ax.set_xlabel(r"perturbation budget $\varepsilon$ ($\times$1/255)")
ax.set_ylabel("ROC-AUC")
ax.set_ylim(0.35, 1.04)
ax.legend(frameon=False, fontsize=6.5, loc="lower left")
save(fig, "fig8_auc_vs_budget")

# ---- Figure 9: Pareto, AUC against distortion ----------------------------
fig, ax = plt.subplots(figsize=(3.4, 2.4))
ax.plot(M["psnr"], M["xunet"], "o-", color=BLUE, ms=3, lw=1.2, label="XuNet (attacked)")
ax.plot(M["psnr"], M["yenet"], "s-", color=ORANGE, ms=3, lw=1.2, label="YeNet (attacked)")
ax.plot(M["psnr"], M["srnet"], "^-", color=GREEN, ms=3.5, lw=1.4, label="SRNet (held-out)")
for x, y, e in zip(M["psnr"], M["xunet"], EPS):
    if e in (0, 4, 8):
        ax.annotate(rf"$\varepsilon$={e}", (x, y), textcoords="offset points",
                    xytext=(4, -9), fontsize=6, color=GREY)
ax.invert_xaxis()
ax.axhline(0.5, ls="--", lw=0.8, color=GREY)
ax.set_xlabel("perturbation PSNR (dB), decreasing")
ax.set_ylabel("ROC-AUC")
ax.set_ylim(0.35, 1.04)
ax.legend(frameon=False, fontsize=6.5, loc="lower left")
save(fig, "fig9_pareto")

# ---- Figure 11: transferability gap, per seed ----------------------------
fig, ax = plt.subplots(figsize=(3.4, 2.4))
for s, mk in zip(SEEDS, ["o", "s", "^", "D"]):
    ax.plot(EPS, R["pgd"][s]["gap"], mk + "-", ms=2.8, lw=0.8, alpha=0.75,
            label=f"seed {s[-1]}")
ax.plot(EPS, M["gap"], "k-", lw=1.8, label="mean")
ax.axhline(0.0, ls="--", lw=0.8, color=GREY)
ax.set_xlabel(r"perturbation budget $\varepsilon$ ($\times$1/255)")
ax.set_ylabel("transferability gap")
ax.legend(frameon=False, fontsize=6.5, ncol=2, loc="upper left")
save(fig, "fig11_transfer_gap")

# ---- Figure 6: error rates at the operating threshold --------------------
# The submitted Figure 6 was an ROC plot. Redrawing it needs per-sample
# detector scores, which the released artifacts do not contain, and the old
# image contradicts the revised Table 2 (its legend reads AUC=0.489). The slot
# is given a figure the artifacts do support: the operating-point error rates.
fig, ax = plt.subplots(figsize=(3.4, 2.3))
dets = ["xunet", "yenet", "srnet"]
labels = ["XuNet", "YeNet", "SRNet"]
metrics = [("fpr", "false-positive rate"), ("fnr", "false-negative rate"),
           ("md_at_5pct_fa", "missed detection @ 5% FA")]
width, xs = 0.26, range(len(dets))
for k, (key, lab) in enumerate(metrics):
    vals = [c[d][key] for d in dets]
    off = (k - 1) * width
    b = ax.bar([x + off for x in xs], vals, width, label=lab,
               color=[BLUE, ORANGE, GREEN][k])
    for rect, v in zip(b, vals):
        ax.text(rect.get_x() + rect.get_width() / 2, v + 0.0012, f"{v:.3f}",
                ha="center", va="bottom", fontsize=5.5, rotation=90)
ax.set_xticks(list(xs))
ax.set_xticklabels(labels)
ax.set_ylabel("rate")
ax.set_ylim(0, 0.052)
ax.legend(frameon=False, fontsize=6, loc="upper left")
save(fig, "fig6_error_rates")

# ---- Figure 7: convergence, from the recorded per-epoch history ----------
# results/history/history_<detector>_seed0.json, as written by the trainer:
# one record per epoch with train_loss, val_auc and lr.
HIST = HERE / "results" / "history"
hist = {d: json.loads((HIST / f"history_{d}_seed0.json").read_text())
        for d in ("xunet", "yenet", "srnet")}
COLOURS = {"xunet": BLUE, "yenet": ORANGE, "srnet": GREEN}
LABELS = {"xunet": "XuNet", "yenet": "YeNet", "srnet": "SRNet"}

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(3.4, 3.1), sharex=True,
                               gridspec_kw={"height_ratios": [1.15, 1]})
for d, h in hist.items():
    ep = [r["epoch"] for r in h]
    auc = [r["val_auc"] for r in h]
    ax1.plot(ep, auc, lw=0.9, color=COLOURS[d], label=f"{LABELS[d]} ({len(h)} epochs)")
    best = auc.index(max(auc))
    ax1.plot([best], [auc[best]], "o", ms=4.5, color=COLOURS[d],
             mec="white", mew=0.6, zorder=5)
    ax2.plot(ep, [r["train_loss"] for r in h], lw=0.9, color=COLOURS[d])
ax1.axhline(0.5, ls=":", lw=0.8, color=GREY)
for ax in (ax1, ax2):
    ax.axvline(30, ls="--", lw=0.9, color="#c0392b")
ax1.annotate("30-epoch\nshared budget", xy=(30, 0.30), xytext=(72, 0.20),
             fontsize=7, color="#c0392b",
             arrowprops=dict(arrowstyle="->", lw=0.7, color="#c0392b"))
ax1.annotate("SRNet best @ 175", xy=(175, 1.0), xytext=(196, 0.72), fontsize=7,
             arrowprops=dict(arrowstyle="->", lw=0.7, color=GREY))
ax1.set_ylabel("validation AUC")
ax1.set_ylim(0.08, 1.06)
ax1.legend(frameon=False, fontsize=7, loc="lower right")
ax2.set_yscale("log")
ax2.set_ylabel("training loss")
ax2.set_xlabel("epoch")
ax2.set_xlim(-8, 458)
save(fig, "fig7_convergence")

print("\nregenerated 6 figures from the ledger")
