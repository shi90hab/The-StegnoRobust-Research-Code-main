"""Numeric gate: re-derive every headline figure in the revision from the run
artifacts and fail loudly on a mismatch.

Run:  python3 verify_numbers.py

The difference between "we checked" and "you can check". Every number the
revised manuscript states about detection, evasion or transfer must appear
below with the file and field it came from.
"""

from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
R = json.loads((HERE / "results" / "per_seed_transfer.json").read_text())

SEEDS = ["seed0", "seed1", "seed2", "seed3"]
EPS = R["_eps_levels"]
I8 = EPS.index(8)

failures: list[str] = []
checks = 0


def check(label: str, got, want, tol=5e-4):
    global checks
    checks += 1
    if want is None:
        print(f"  .. {label}: {got}  (recorded, not asserted)")
        return
    ok = abs(got - want) <= tol
    print(f"  {'OK ' if ok else 'FAIL'} {label}: {got:.4f} (expected {want:.4f})")
    if not ok:
        failures.append(f"{label}: got {got:.6f}, manuscript states {want:.6f}")


def check_eq(label: str, got, want):
    global checks
    checks += 1
    ok = got == want
    print(f"  {'OK ' if ok else 'FAIL'} {label}: {got!r} (expected {want!r})")
    if not ok:
        failures.append(f"{label}: got {got!r}, manuscript states {want!r}")


print("=" * 74)
print("NUMERIC GATE -- IJIES 20264187 revision")
print("=" * 74)

# ---------------------------------------------------------------- Table 2
print("\n[Table 2] Clean detection, 4-seed means (table2_clean_detection.tex)")
c = R["clean_detection_4seed_mean"]
check("XuNet clean AUC", c["xunet"]["auc"], 0.999)
check("YeNet clean AUC", c["yenet"]["auc"], 1.000)
check("SRNet clean AUC (held-out)", c["srnet"]["auc"], 0.999)
check("Committee mean AUC", c["committee_mean_auc"], 0.999)
for d in ("xunet", "yenet", "srnet"):
    check_eq(f"{d} converged", c[d]["converged"], "yes")
    check_eq(f"{d} inverted", c[d]["inverted"], "no")

# The defect the manuscript must not reproduce.
print("\n[Defect] DeLong CI upper bound must be clipped at 1.000")
raw_hi = c["xunet"]["ci"][1]
checks += 1
if raw_hi > 1.0:
    print(f"  OK  artifact prints {raw_hi} (> 1); manuscript prints 1.000 -- clipping is required and recorded")
else:
    failures.append("expected the unclipped 1.001 defect in the artifact; not found")

# ---------------------------------- what the submitted manuscript claimed
print("\n[Submitted] The figures the reviewers objected to")
s = R["submitted_manuscript"]
check("submitted XuNet AUC", s["table2"]["xunet_auc"], 0.489)
check("submitted SRNet AUC", s["table2"]["srnet_auc"], 0.498)
check("submitted committee mean", s["table2"]["committee_mean"], 0.745)
print("  -> XuNet 0.489 -> 0.999 and SRNet 0.498 -> 0.999 after the protocol fix")

# ---------------------------------------------------------------- Table 3
print("\n[Table 3] PGD sweep, 4-seed means (table3_evasion_pgd.tex)")
m = R["evasion_pgd_4seed_mean"]
check("XuNet AUC at eps=8/255", m["xunet"][I8], 0.451)
check("YeNet AUC at eps=8/255", m["yenet"][I8], 0.527)
check("SRNet AUC at eps=8/255 (held-out)", m["srnet"][I8], 0.993)
check("gap at eps=8/255", m["gap"][I8], 0.505)
check("minimum PSNR over the sweep", min(m["psnr"]), 33.9)

print("\n[Table 3] the 4-seed mean gap must equal the mean of the per-seed gaps")
per_seed_gap8 = [R["pgd"][s_]["gap"][I8] for s_ in SEEDS]
check("mean of per-seed gaps at eps=8", statistics.fmean(per_seed_gap8), m["gap"][I8], tol=1e-3)

# ------------------------------------------------------- transferability
print("\n[Transferability] PGD, per seed, at eps=8/255")
held8 = [R["pgd"][s_]["heldout_attacked"][I8] for s_ in SEEDS]
comm8 = [R["pgd"][s_]["committee_attacked"][I8] for s_ in SEEDS]
for s_, h, k, g in zip(SEEDS, held8, comm8, per_seed_gap8):
    print(f"  {s_}: committee {k:.4f}   held-out {h:.4f}   gap {g:+.4f}")
check("minimum held-out AUC across seeds", min(held8), 0.979, tol=1e-3)
check("maximum held-out AUC across seeds", max(held8), 1.000, tol=1e-3)
check("minimum committee AUC across seeds", min(comm8), 0.261, tol=1e-3)
check("maximum committee AUC across seeds", max(comm8), 0.688, tol=1e-3)

checks += 1
if all(g > 0 for g in per_seed_gap8):
    print("  OK  gap is positive in all 4 seeds at eps=8/255")
else:
    failures.append("gap is not positive in every seed at eps=8/255")

checks += 1
monotone = all(
    all(R["pgd"][s_]["gap"][i] <= R["pgd"][s_]["gap"][i + 1] + 1e-9 for i in range(len(EPS) - 1))
    for s_ in SEEDS
)
if monotone:
    print("  OK  gap is non-decreasing in epsilon in every seed")
else:
    failures.append("gap is not monotone in epsilon in every seed")

print("\n[Transferability] held-out drop significance (paired DeLong, per seed)")
p8 = [R["pgd"][s_]["heldout_p_value"][I8] for s_ in SEEDS]
sig = [p for p in p8 if p is not None and p < 0.05]
for s_, p in zip(SEEDS, p8):
    print(f"  {s_}: p = {p}")
check_eq("seeds with a significant held-out drop at eps=8", len(sig), 1)

# ------------------------------------------------------------ statistics
print("\n[Statistics] Wilcoxon floor at n=4")
n = len(SEEDS)
floor = 2 ** (-(n - 1))
check("two-sided exact Wilcoxon floor", floor, 0.125)
checks += 1
if floor > 0.05:
    print("  OK  no across-seed rank test can reach p<0.05 at n=4; per-seed DeLong is primary")
else:
    failures.append("Wilcoxon floor unexpectedly below 0.05")

# ------------------------------------------------------------------- NAA
print("\n[NAA] Not reported as a result -- the disclosure must match the data")
naa8 = [R["naa"][s_]["committee_attacked"][I8] for s_ in SEEDS]
for s_, v in zip(SEEDS, naa8):
    print(f"  {s_}: committee under NAA at eps=8/255 = {v:.4f}")
failed = [v for v in naa8 if v > 0.99]
check_eq("seeds in which NAA left the committee above 0.99", len(failed), 3)
check("worst-case NAA committee AUC (the one seed that worked)", min(naa8), 0.193, tol=1e-3)
check_eq("PGD committee weighting", R["pgd"]["committee_weighting"], "mean")
check_eq("NAA committee weighting", R["naa"]["committee_weighting"], "logit")
checks += 1
if R["pgd"]["committee_weighting"] != R["naa"]["committee_weighting"]:
    print("  OK  the two attacks differ on committee weighting -- disclosed, not presented as matched")
else:
    failures.append("expected the mean/logit mismatch between PGD and NAA")

# ----------------------------------------------------- convergence history
print("\n[Figure 7] Per-epoch history (results/history/, seed 0)")
HIST = HERE / "results" / "history"
hist = {d: json.loads((HIST / f"history_{d}_seed0.json").read_text())
        for d in ("xunet", "yenet", "srnet")}

for d, n in (("xunet", 150), ("yenet", 120), ("srnet", 450)):
    check_eq(f"{d} history length", len(hist[d]), n)

# The recorded best_epoch must be reproducible from the history itself. This is
# the independent check that the history files are the ones behind Table 2.
for d, want in (("xunet", 4), ("yenet", 1), ("srnet", 175)):
    aucs = [r["val_auc"] for r in hist[d]]
    check_eq(f"{d} first epoch at max val AUC", aucs.index(max(aucs)), want)

srnet_auc = [r["val_auc"] for r in hist["srnet"]]
below = [i for i, a in enumerate(srnet_auc) if a < 0.95]
check_eq("SRNet last epoch below 0.95 val AUC", below[-1], 297)
check("SRNet minimum val AUC", min(srnet_auc), 0.466, tol=1e-3)
lr = [r["lr"] for r in hist["srnet"]]
drops = [i for i in range(1, len(lr)) if lr[i] != lr[i - 1]]
check_eq("SRNet learning-rate drop epochs", drops, [299, 399])

yenet_auc = [r["val_auc"] for r in hist["yenet"]]
check("YeNet minimum val AUC", min(yenet_auc), 0.179, tol=1e-3)
check_eq("YeNet epoch of minimum val AUC", yenet_auc.index(min(yenet_auc)), 24)

# Bookkeeping discrepancy, recorded rather than smoothed over.
print("\n[Defect] YeNet epoch count disagrees between artifacts")
checks += 1
if len(hist["yenet"]) == 120:
    print("  OK  history holds 120 epochs; detectors_full_model_seed0.json reports "
          "epochs_run=116 (91 resumed + 25 this session). The manuscript states 120, "
          "which is the per-epoch record. Noted in CHANGES.md.")
else:
    failures.append("expected the 116/120 YeNet discrepancy")

print("\n[Defect] YeNet training loss is discontinuous at the resume boundary")
yl = [r["train_loss"] for r in hist["yenet"]]
ratios = [(yl[i + 1] / max(yl[i], 1e-12), i + 1) for i in range(len(yl) - 1)]
worst, at = max(ratios)
checks += 1
if worst > 10:
    print(f"  OK  loss jumps {worst:.0f}x at epoch {at}; recorded as a checkpoint-resume "
          f"artefact in CHANGES.md, not presented as training behaviour")
else:
    failures.append("expected a large YeNet loss discontinuity at the resume boundary")

# --------------------------------------------------------------- summary
print("\n" + "=" * 74)
if failures:
    print(f"{len(failures)} MISMATCH(ES) out of {checks} checks:\n")
    for f in failures:
        print("  -", f)
    sys.exit(1)
print(f"All {checks} checks passed. Every headline figure traces to a run artifact.")
print("=" * 74)
